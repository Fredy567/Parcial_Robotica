# Predicciones Pregunta 1 (escribir y hacer commit ANTES de medir)

Fecha/hora: ____  ·  timeout_s elegido: ____ s  ·  ROS_DOMAIN_ID: ____

Medida	Calma (predicho)	Calma (medido)	Carga (predicho)	Carga (medido)
Servicio mediana (ms)	130 � 200		200 � 400	
Servicio P95 (ms)	200 � 300		500 � 1000	
C�lculo servidor mediana (ms)	100 � 180		150 � 250	
Red + cola mediana (ms)	10 � 30		20 � 150	
Respuestas degradadas	0 de 50		0 � 5 de 50	
Exactitud LAYA (frase completa, %)	10 � 25		igual que en calma	
Exactitud palabras clave (frase completa, %)	40 � 60		igual que en calma

