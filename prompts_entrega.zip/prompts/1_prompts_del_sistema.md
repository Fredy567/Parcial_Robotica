# Prompts del sistema (lo que nuestro código le pregunta a los modelos)

Estos son los prompts que el sistema envía en tiempo de ejecución. Están en el código; aquí se copian textualmente.

## Pregunta 1 — Decisión con LAYA (`/v1/systemone`)

El nodo `interprete_ordenes` envía la frase del operador como `state.message` y hace **5 preguntas** al servidor LAYA.
Archivo: `src/paquetes_parcial/pkg/examen_nodos/examen_nodos/laya_cliente.py`.

### Petición HTTP

```json
POST {LAYA_URL}/v1/systemone
{
  "state": {"message": "<frase del operador>"},
  "questions": { ...las 5 preguntas de abajo... }
}
```

### Preguntas usadas en las mediciones y en la demostración (`p1/preguntas_laya.json`, afinadas con `afinar_laya`)

```json
{
  "accion": {
    "type": "choice",
    "instructions": "Que accion le pide el operador al brazo robotico en `message`?",
    "criteria": {
      "agarrar": "agarrar, tomar, coger, recoger, levantar, traer, buscar, pasar o llevar un objeto",
      "soltar": "soltar, dejar, poner, colocar o depositar el objeto en un lugar",
      "mover": "mover o girar el brazo a una posicion, sin tomar ni soltar objetos",
      "detener": "parar, detener, frenar, alto o quedarse quieto",
      "otra": "saludo, pregunta u otra cosa que no es una orden para el brazo"
    }
  },
  "objeto": {
    "type": "choice",
    "instructions": "Que objeto menciona `message`?",
    "criteria": {
      "cubo": "un cubo o caja",
      "esfera": "una esfera, bola o pelota",
      "cilindro": "un cilindro, lata o vaso",
      "otro": "un objeto distinto que no esta en la mesa",
      "ninguno": "la orden no menciona ningun objeto"
    }
  },
  "color": {
    "type": "choice",
    "instructions": "Que color se nombra en `message`?",
    "criteria": {
      "rojo": "rojo",
      "azul": "azul",
      "verde": "verde",
      "amarillo": "amarillo",
      "otro": "otro color distinto",
      "ninguno": "no menciona color"
    }
  },
  "prioridad": {
    "type": "choice",
    "instructions": "Con que urgencia pide el operador la orden de `message`?",
    "criteria": {
      "sin_prisa": "sin prisa, con calma, cuando se pueda",
      "normal": "orden comun, no dice nada de urgencia",
      "urgente": "urgente, rapido, ya, ahora, lo antes posible",
      "emergencia": "emergencia, inmediatamente, alto total"
    }
  },
  "permitido": {
    "type": "noul",
    "instructions": "Es `message` una orden segura y permitida para un brazo robotico?",
    "criteria": {
      "true": "orden segura: agarrar, mover, soltar o detener objetos de la mesa",
      "false": "orden peligrosa: lanzar, golpear, romper, tocar personas o ignorar limites"
    }
  }
}
```

Interpretación de las respuestas (en `laya_cliente.py`):
- `prioridad` (choice) → `sin_prisa`=1, `normal`=2, `urgente`=3, `emergencia`=4 (mayor = más urgente).
- `permitido` (noul con criterios) → `true` si la probabilidad de «orden segura» es ≥ 0,5.
- Un `noul` **sin** criterios responde casi siempre «no» (comportamiento documentado de LAYA, issue #156); por eso
  `permitido` lleva criterios explícitos.

### Versión inicial (antes de afinar)

La versión inicial era la misma estructura, pero `prioridad` era una pregunta de tipo `score` («¿Qué tan urgente es la
orden de `message`?») y los criterios eran más cortos. Con ella la exactitud de frase completa fue 6 %; con las
preguntas afinadas, 16 % (ver `p1/tablas_p1.md`).

### Respaldo sin modelo (modo degradado)

Si LAYA no responde dentro de `timeout_s`, la decisión la toma `clasificar_palabras_clave()` (listas de palabras clave
en `laya_cliente.py`, sin prompt) y la respuesta se marca `degradado = true`.

## Pregunta 2

La P2 no usa prompts propios: la decisión de cada orden escrita es la de la P1 (mismas preguntas a LAYA). El broker
aplica además reglas fijas de admisión (no permitido, acción distinta de agarrar, objeto que no es cubo, color que no
está en la mesa, cola llena).

## Pregunta 3 — Transcripción con Google AI Studio (Gemini)

Archivo: `src/paquetes_parcial/pkg/examen_nodos/examen_nodos/transcriptor_voz.py`. Modelo usado en la corrida oficial:
`gemini-3.1-flash-lite` (respaldo: `gemini-flash-lite-latest`, `gemini-3.5-flash`).

### Prompt

```
Transcribe literalmente este audio en espanol. Es una orden para un brazo robotico.
Responde SOLO con la transcripcion, sin comillas, sin explicaciones.
Si no se entiende nada, responde exactamente: [inaudible]
```

### Petición HTTP

```json
POST https://generativelanguage.googleapis.com/v1beta/models/<modelo>:generateContent
Header: x-goog-api-key: <GEMINI_API_KEY, leída de una variable de entorno>
{
  "contents": [{"parts": [
      {"text": "<prompt de arriba>"},
      {"inline_data": {"mime_type": "audio/mp3", "data": "<audio en base64>"}}
  ]}],
  "generationConfig": {"temperature": 0.0}
}
```

El texto transcrito se entrega tal cual a `/interpretar_orden` (P1), que vuelve a hacer las 5 preguntas a LAYA.
