# Prompts

| Archivo | Contenido |
|---|---|
| `1_prompts_del_sistema.md` | Prompts que **nuestro sistema** envía a los modelos: las 5 preguntas a LAYA (P1, también usadas en P2 y P3) y el prompt de transcripción a Google AI Studio (P3) |
| `2_asistente_ia.md` | Prompts que **el equipo** envió al asistente de IA (Claude) durante el desarrollo, por pregunta |
