# Uso de asistente de IA

Durante el desarrollo usamos **Claude** (Anthropic) como asistente: para escribir y corregir el código de los nodos,
diagnosticar errores a partir de las salidas de la terminal, preparar los comandos de instalación y armar las tablas y
los README a partir de **nuestros** datos medidos (CSV, bag, registros). Las mediciones, la calibración, la operación
del robot y las decisiones (por ejemplo, la disposición de los cubos o dónde correr el broker) fueron del equipo.

Abajo están los prompts que le enviamos, por pregunta y en orden. Las horas son de Lima (UTC-5). Cuando pegamos
salidas largas de la terminal se muestra solo la primera línea; las claves de API se redactaron.

## Pregunta 1

Esta parte del trabajo se hizo en una sesión anterior cuya transcripción textual ya no está disponible; los
prompts se listan **resumidos** (no textuales), en el orden en que se hicieron.

- Pedimos ayuda para terminar el parcial empezando por la Pregunta 1: revisar el zip del grupo, terminar la parte de
  LAYA, qué descargar y qué código usar, con el JetCobot y una PC conectados por IP; pedimos comandos paso a paso
  para no cometer errores.
- Preguntamos si la instalación en la Jetson era correcta, dónde estaban los archivos, cómo conseguir `LAYA_URL`.
- El docente indicó que debíamos levantar nosotros el servidor LAYA: pedimos cómo hacerlo (se instaló en una PC
  Windows del laboratorio con `pip install "laya[serve]"`).
- Pegamos salidas del servidor y de las pruebas (`laya_cliente`, `medir_latencia`, `afinar_laya`) y preguntamos qué
  hacer después de cada paso.
- Pedimos ayuda con los entregables de la P1 (informe en Word) y con las tablas de latencia y exactitud.
- Preguntamos cómo guardar todo y no dejar información en la computadora del laboratorio.

## Pregunta 2

Inicio de la P2 (sesión anterior, prompts **resumidos**):

- Verificación de la tabla DH del RB-2 contra el robot, dónde colocar los cubos, cómo enseñar las posiciones con
  el brazo (calibración), problemas con la cámara ocupada por un notebook de Yahboom, detección de colores.
- Pedimos acercar los cubos, que la pinza cerrara más y bajara más; decidimos que los cubos formen un cuadrado.
- Reportamos fallos (verde rechazado como «otro», azul no detectado, el brazo iba al cubo equivocado) pegando las
  salidas de la terminal.

Desde aquí, prompts **textuales** (se omiten las salidas largas de terminal que pegamos; las claves están redactadas):

- **09/10 18:14** — `jetson@yahboom:~/examen_ws$  source ~/env_examen.sh`  
  *[salida de terminal / comandos pegados: 7 lineas]*
- **09/10 18:15** — `jetson@yahboom:~/examen_ws$ ros2 run examen_nodos enviar_orden --id prueba --frase "agarra el cubo azul"`  
  *[salida de terminal / comandos pegados: 6 lineas]*
- **09/10 18:16** — `jetson@yahboom:~/examen_ws$ source ~/env_examen.sh`  
  *[salida de terminal / comandos pegados: 25 lineas]*
- **09/10 18:20** — `jetson@yahboom:~/examen_ws$ ros2 run examen_nodos enviar_orden --id prueba --frase "agarra el cubo amarillo"`  
  *[salida de terminal / comandos pegados: 10 lineas]*
- **09/10 18:24** — ahora si , ya estan los 4 colores
- **09/10 18:26** — un momento y que hay de las 4 ordenes que debemos mandar desde las raspberrys
- **09/10 18:34** — oks no debe faltar mucho no?
- **09/10 18:35** — me ayudas a guardar todo , ya nos tenemos que retirar
- **09/10 18:36** — `cd ~`  
  *[salida de terminal / comandos pegados: 5 lineas]*
- **12/10 14:39** — listo , es otro día y no tengo la computadora disonible , estoy en raspberry , para empezar a trabajar que necesito , ojo seguimos con la pregunta 2
- **12/10 14:41** — como te dije previamente no tengo acceso a esa computador ahora , alguna idea?
- **12/10 15:27** — en 30 minutos nos daran la compu , mejor espero o seguimos ?
- **12/10 15:29** — cuando le indique a la jetson la nueva ip , o afectara algo cuando lo haga ahora en la nueva compu?
- **12/10 15:33** — sed -i 's#LAYA_URL=.*#LAYA_URL=http://IP_DE_LA_RASPBERRY:8000#' ~/env_examen.sh  
  source ~/env_examen.sh  
  ros2 launch examen_nodos sistema_p2.launch.py timeout_s:=3.0 politica:=prioridad, coloca la ip : 172.51.9.25
- **12/10 15:38** — mir , mejor como no falta mucho para que nos den la compu , ayudame a configurar la raspberry para mandar las ordenes desde la terminal
- **12/10 15:39** — estas usando la ip y todo de la compu del viernes no?
- **12/10 15:56** — esto tiene que ser en la jetson del viernes no?
- **12/10 15:57** — ros2 service list | grep interpretar  
  ros2 action list | grep recoger, esto me refiero
- **12/10 16:20** — el profe nos da la opcion de trabajr en una computadora que él tiene ya que todas estan ocupadas , pero no tiene el laya instalado y será otra ip distinta , cuanto tardare en añadir todo eso incluido los archivos del jetson y configurar las raspberrys con esa nueva ip
- **12/10 16:39** — ya esta el laya instalado
- **12/10 16:40** — `PS C:\Users\laboratorioesan> ipconfig`  
  *[salida de terminal / comandos pegados: 36 lineas]*
- **12/10 16:49** — sshh en jetson , te refieres que lo ejecute en una terminal?
- **12/10 16:52** — psea en la raspberry entro a la sshh y ejjecuto el codigo : sed -i 's#LAYA_URL=.*#LAYA_URL=http://172.51.1.27:8000#' ~/env_examen.sh
- **12/10 16:56** — `alumno01@rpi-03:~$ scp ~/Downloads/p2_entrega_v11.zip jetson@IP_JETSON:~`  
  *[salida de terminal / comandos pegados: 6 lineas]*
- **12/10 16:59** — 172.51.1.18
- **12/10 17:04** — home/jetson/examen_ws/install/arm_broker  
  LISTO. En cada terminal nueva:  source ~/env_examen.sh  
  http://172.51.1.27:8000  
  LAYA responde  
  jetson@yahboom:~$
- **12/10 17:06** — segun el profee la calibracion debe ser la misma en cualquier brazo , porque debemos recalibrar devuelta
- **12/10 17:11** — a verdad , no se si tenga que ver pero el profe dijo que las 4 ordenes es desde la terminales del berazo pero el broker si desde la raspberry
- **12/10 17:17** — oks , hare eso , asi usa la misma calibracion del viernes , todo esta bien
- **12/10 17:21** — esto va en el jupyterlab :    cd ~ && unzip -o p2_entrega_v12.zip && bash ~/p2_entrega_v12/instalar_jetson.sh  
     sed -i 's#LAYA_URL=.*#LAYA_URL=http://172.51.1.27:8000#' ~/env_examen.sh  
     source ~/env_examen.sh  
     ros2 launch examen_nodos sistema_p2.launch.py timeout_s:=1.0 politica:=prioridad broker:=false
- **12/10 17:22** — ros2 launch examen_nodos sistema_p2.launch.py timeout_s:=1.0 politica:=prioridad, esto va en la raspberry¡
- **12/10 17:32** — source ~/env_rpi.sh  
     ros2 run arm_broker broker --ros-args -p politica:=prioridad . esto va en raspberry no?
- **12/10 17:44** — alumno01@rpi-03:~$ ros2 topic info /joint_states -v | grep -E "Publisher count|Node name"  
  Unknown topic '/joint_states'  
  alumno01@rpi-03:~$
- **12/10 17:47** — `alumno01@rpi-03:~$ source ~/env_rpi.sh`  
  *[salida de terminal / comandos pegados: 9 lineas]*
- **12/10 17:51** — `jetson@yahboom:~$ source ~/env_examen.sh`  
  *[salida de terminal / comandos pegados: 31 lineas]*
- **12/10 17:52** — dime que es el ultimo cambio , ya vamos casi 2 horas
- **12/10 17:55** — osea , las terminales del jupyter las detnego y coloco esto : pkill -f "examen_nodos|arm_broker|move_group|robot_state_publisher" ; sleep 3  
  source ~/env_examen.sh  
  ros2 node list
- **12/10 18:07** — `jetson@yahboom:~$ pkill -f "examen_nodos|arm_broker|move_group|robot_state_publisher" ; sleep 3`  
  *[salida de terminal / comandos pegados: 7 lineas]*
- **12/10 18:08** — jetson@yahboom:~$ pgrep -af "interprete_ordenes|move_group|moveit" || echo "no hay procesos vivos"  
  357226 /usr/bin/python3 /home/jetson/logistica_integrada/install/laya_ordenes/lib/laya_ordenes/interprete_ordenes --ros-args --params-file /tmp/launch_params__aba9jfw  
  jetson@yahboom:~$
- **12/10 18:09** — `jetson@yahboom:~$ ros2 node info /interprete_ordenes 2>/dev/null | grep -A5 "Service Servers"`  
  *[salida de terminal / comandos pegados: 10 lineas]*
- **12/10 18:13** — luego de eso que sigue
- **12/10 18:15** — jetson@yahboom:~$ ros2 service list -t | grep interpretar  
  /interpretar_orden [interfaces_examen/srv/InterpretarOrden]  
  jetson@yahboom:~$
- **12/10 18:17** — `jetson@yahboom:~$ source ~/env_examen.sh`  
  *[salida de terminal / comandos pegados: 10 lineas]*
- **12/10 18:18** — `jetson@yahboom:~$ fuser -v /dev/video0`  
  *[salida de terminal / comandos pegados: 11 lineas]*
- **12/10 18:25** — el robot no esta en la pose que le desiganmos el viwrnes , como la colocamos
- **12/10 18:27** — `^Cjetson@yahboom:~ls /dev/ttyUSB* /dev/ttyACM* 2>/dev/nullll`  
  *[salida de terminal / comandos pegados: 11 lineas]*
- **12/10 18:28** — te digo que la psoe es distinta , si quieres te lo mando los 4 cubos en ok pero esta cerca uno de otro , nomas te asviso
- **12/10 18:31** — ya tods salen ok+
- **12/10 18:35** — `alumno01@rpi-03:~$ source ~/env_rpi.sh`  
  *[salida de terminal / comandos pegados: 8 lineas]*
- **12/10 18:37** — `alumno01@rpi-03:~$ source ~/env_rpi.sh`  
  *[salida de terminal / comandos pegados: 11 lineas]*
- **12/10 18:43** — ya funciona , QUE SIGUE
- **12/10 18:44** — recurda que las ordenes lasa haremos en el mismo jetcobot , en sus terminales
- **12/10 18:46** — ros2 bag info ~/examen_ws/p2/demo_p2  
  cat ~/examen_ws/p2/intentos.csv , esto es en una terminal del raspberry?
- **12/10 18:50** — jetson@yahboom:~$ ros2 run examen_nodos enviar_orden --id prueba --frase "lanza el cubo rojo contra la pared"  
  Package 'examen_nodos' not found
- **12/10 18:55** — una pregunta , que pasara cuando ejecute las 4 ordenes
- **12/10 19:06** — FUNCIONO YTODO , GRACIASSSSS
- **12/10 19:09** — `jetson@yahboom:~$ cd ~/examen_ws/p2 && zip -r ~/evidencia_p2.zip demo_p2 intentos*.csv predicciones_p2.md`  
  *[salida de terminal / comandos pegados: 8 lineas]*
- **13/10 09:25** — ls ~/examen_ws/p2/ , esto lo coloco en cualquier terminal?
- **13/10 09:28** — alumno01@rpi-03:~$ ls ~/examen_ws/p2/  
  find ~ -maxdepth 4 -type d -name "demo_p2*" 2>/dev/null  
  intentos.csv  mesa.yaml  ordenes_TU_NOMBRE.csv
- **13/10 09:30** — me puedes dar el codigo para correr las ordenes en las terminales del jetson
- **13/10 09:32** — me das el codigo para el ros2 del jetson?
- **13/10 09:33** — `PS C:\Users\laboratorioesan> sed -i 's#LAYA_URL=.*#LAYA_URL=http://172.51.1.27:8000#' ~/env_examen.sh`  
  *[salida de terminal / comandos pegados: 21 lineas]*
- **13/10 09:35** — `Copyright (C) Microsoft Corporation. Todos los derechos reservados.`  
  *[salida de terminal / comandos pegados: 40 lineas]*
- **13/10 09:55** — laya responde
- **13/10 10:01** — listo ya esta
- **13/10 10:02** — me das las ordenes necesarias para ese entregable
- **13/10 10:06** — ahorita mi compañera coloca eso en las terminales y seguir con la pregunta 3 , ya deben haber vuelto los cr{editos no?
- **13/10 10:10** — al ejecutar la de la prediiccion debeerria salir algo?
- **13/10 10:10** — puedes darme las predicciones
- **13/10 10:24** — ya hice las 3 rondas
- **13/10 10:26** — `alumno01@rpi-03:~$ cd ~/examen_ws/p2 && ls demo_p2`  
  *[salida de terminal / comandos pegados: 13 lineas]*
- **13/10 10:28** — `jetson@yahboom:~$ find ~ -maxdepth 4 \( -name "demo_p2*" -o -name "predicciones_p2.md" -o -name "intentos_dia1.csv" \) 2>/dev/null`  
  *[salida de terminal / comandos pegados: 10 lineas]*
- **13/10 10:33** — listo ya esta
- **13/10 10:35** — [archivo adjunto: evidencia_p2_dia2_b.zip] [archivo adjunto: evidencia_p2.zip]

## Pregunta 3

- **12/10 19:13** — YA ESTA guardado
- **12/10 19:13** — verdad , que tan dificl  sera hacer la pregunta 3 ahora
- **12/10 19:17** — microfono será la de la misma computadora , googgle ai si yaa tenemos , raspberry si tiene internet
- **12/10 19:18** — sera archivo de audio , googgle ai si yaa tenemos , raspberry si tiene internet
- **12/10 19:23** — haber con que iniciamos
- **12/10 19:29** — los 5 audios de las ordenes ya estan
- **12/10 19:30** — como los muevo a la CARPETA DE LA p3
- **12/10 19:31** — [archivo adjunto: WhatsApp_Audio_2026-10-12_at_7.23.18_PM.mpeg] [archivo adjunto: WhatsApp_Audio_2026-10-12_at_7.22.57_PM.mpeg] [archivo adjunto: WhatsApp_Audio_2026-10-12_at_7.22.46_PM.mpeg] [archivo adjunto: WhatsApp_Audio_2026-10-12_at_7.22.36_PM.mpeg] [archivo adjunto: WhatsApp_Audio_2026-10-12_at_7.22.04_PM.mpeg] Estos son los 5 audios
- **12/10 19:36** — [WARN] [1791851733.891540031] [arm_broker]: RECHAZADA [voz] "Lanza el cubo contra la pared" -> orden NO PERMITIDA por el modelo (permitido=False)
- **12/10 19:38** — `numero o ruta del audio (ENTER = el mas nuevo, t = escribir orden, Ctrl+C sale)> 2`  
  *[salida de terminal / comandos pegados: 9 lineas]*
- **12/10 19:41** — alumno01@rpi-cut -d, -f1,3,5,6 ~/examen_ws/p3/registro_p3.csv  
  n,audio,transcripcion,modo  
  1,01_193526_orden5_7h23.18.mp3,Lanza el cubo contra la pared,voz
- **12/10 19:44** — una duda , los audios tengo que cambiar su nombre manuialmente?
- **12/10 19:44** — `alumno01@rpi-03:~/examen_ws/p3/audios$ ros2 run examen_nodos transcriptor_voz --id voz --timeout-s 15 --archivo ~/examen_ws/p3/audios/orden1_7h22.04.mp3`  
  *[salida de terminal / comandos pegados: 13 lineas]*
- **12/10 19:53** — funciona ya la orden 1 que fallaba , dame las 5 ordenes seguidas para mostrarlo para el video
- **12/10 19:58** — jetson@yahboom:~$ cd ~/examen_ws/p3 && mv registro_p3.csv registro_ensayo_$(date +%H%M).csv 2>/dev/null; source ~/env_rpi.sh  
  -bash: cd: /home/jetson/examen_ws/p3: No such file or directory  
  -bash: /home/jetson/env_rpi.sh: No such file or directory
- **12/10 20:04** — orden 3, 4,5 las interpreto como vaciaS
- **12/10 20:05** — `alumno01@rpi-03:~/examen_ws/p3$ cut -d, -f1,5,6,7 ~/examen_ws/p3/registro_p3.csv`  
  *[salida de terminal / comandos pegados: 7 lineas]*
- **13/10 02:14** — mañana continuaremos hasta que vuelvan los creditos
- **13/10 10:37** — dame los pSOS PARA LA P3
- **13/10 10:38** — `source ~/env_rpi.sh`  
  *[salida de terminal / comandos pegados: 5 lineas]*
- **13/10 10:40** — `alumno01@rpi-03:~$ source ~/env_rpi.sh`  
  *[salida de terminal / comandos pegados: 7 lineas]*
- **13/10 10:42** — alumno01@rpi-03:~$ curl -s -H "x-goog-api-key: $GEMINI_API_KEY" "https://generativelanguage.googleapis.com/v1beta/models?pageSize=200" | grep -oE '"name": *"models/gemini[^"]*flash[^"]*"'  
  alumno01@rpi-03:~$
- **13/10 10:44** — `alumno01@rpi-03:~$ echo "largo de la clave: ${#GEMINI_API_KEY}"`  
  *[salida de terminal / comandos pegados: 12 lineas]*
- **13/10 10:46** — `alumno01@rpi-03:~$ ls -la ~/.config/examen/gemini.env`  
  *[salida de terminal / comandos pegados: 5 lineas]*
- **13/10 10:51** — `alumno01@rpi-03:~$ source ~/.config/examen/gemini.env; echo "largo: ${#GEMINI_API_KEY}"`  
  *[salida de terminal / comandos pegados: 5 lineas]*
- **13/10 10:53** — `alumno01@rpi-03:~$ curl -s -H "x-goog-api-key: $GEMINI_API_KEY" "https://generativelanguage.googleapis.com/v1beta/models?pageSize=200" | grep -oE '"name": *"mod`  
  *[salida de terminal / comandos pegados: 28 lineas]*
- **13/10 10:55** — `alumno01@rpi-03:~$ curl -s -m 20 -H "x-goog-api-key: $GEMINI_API_KEY" -H "Content-Type: application/json" \`  
  *[salida de terminal / comandos pegados: 5 lineas]*
- **13/10 10:57** — `alumno01@rpi-03:~$ for m in gemini-flash-lite-latest gemini-flash-latest gemini-3.5-flash-lite gemini-3.1-flash-lite gemini-3.5-flash gemini-2.5-flash; do`  
  *[salida de terminal / comandos pegados: 13 lineas]*
- **13/10 11:00** — alumno01@rpi-03:~/examen_rpi$ ls -t ~/Downloads/transcriptor_voz*  
  /home/alumno01/Downloads/transcriptor_voz.py  
  alumno01@rpi-03:~/examen_rpi$
- **13/10 11:05** — alumno01@rpi-03:~/examen_rpi$ grep -c "gemini-3.1-flash-lite" ~/examen_rpi/src/examen_nodos/examen_nodos/transcriptor_voz.py  
  0  
  alumno01@rpi-03:~/examen_rpi$
- **13/10 11:05** — pero borre el anterior y coloque el nuevo manualmente
- **13/10 11:07** — `alumno01@rpi-03:~/examen_rpi$ F=~/examen_rpi/src/examen_nodos/examen_nodos/transcriptor_voz.py`  
  *[salida de terminal / comandos pegados: 21 lineas]*
- **13/10 11:08** — `alumno01@rpi-03:~/examen_rpi$ cd ~/examen_ws/p3 && head -3 registro_p3.csv > tmp.csv && mv tmp.csv registro_p3.csv && cut -d, -f1,5,6 registro_p3.csv`  
  *[salida de terminal / comandos pegados: 5 lineas]*
- **13/10 11:09** — algo que deba ejecutar aparte , porque nose cuantos intentos tendr{e , solo es eso y ya estaría todo o flara algo mas
- **13/10 11:11** — da igual que ahora hagamos la 3,4,5 sin la 1 y 2?
- **13/10 11:12** — `cd ~/examen_ws/p3 && mv registro_p3.csv registro_dia1.csv`  
  *[salida de terminal / comandos pegados: 8 lineas]*
- **13/10 11:18** — [archivo adjunto: attachment.txt]
- **13/10 11:27** — de que sirve si todas me piden escribir, minimo una o dos no debo esacribir la orden
- **13/10 11:29** — `alumno01@rpi-03:~/examen_rpi$ source ~/env_rpi.sh && source ~/.config/examen/gemini.env`  
  *[salida de terminal / comandos pegados: 52 lineas]*
- **13/10 11:35** — `alumno01@rpi-03:~/examen_rpi$ rm ~/.config/examen/gemini.env`  
  *[salida de terminal / comandos pegados: 8 lineas]*
- **13/10 11:38** — `alumno01@rpi-03:~/examen_rpi$ python3 - <<'EOF'`  
  *[salida de terminal / comandos pegados: 18 lineas]*
- **13/10 11:39** — `alumno01@rpi-03:~/examen_rpi$ F=~/examen_rpi/src/examen_nodos/examen_nodos/transcriptor_voz.py`  
  *[salida de terminal / comandos pegados: 10 lineas]*
- **13/10 11:43** — `alumno01@rpi-03:~/examen_rpi$ cd ~/examen_ws/p3 && mv registro_p3.csv registro_intento3.csv 2>/dev/null`  
  *[salida de terminal / comandos pegados: 29 lineas]*
- **13/10 11:44** — espero que sea el ultimo cambio eh
- **13/10 11:50** — [archivo adjunto: attachment.txt]
- **13/10 11:53** — sudo sh -c 'echo "0.0.0.0 generativelanguage.googleapis.com" >> /etc/hosts'  
  ros2 run examen_nodos transcriptor_voz --id voz --archivo ~/examen_ws/p3/audios/orden1_7h22.04.mp3 , osea ejecuto eso , entrara en modo sin internet y luego escribo agarra el cubo rojo  , eso es?}
- **13/10 11:56** — `alumno01@rpi-03:~/examen_ws/p3$ sudo sh -c 'echo "0.0.0.0 generativelanguage.googleapis.com" >> /etc/hosts'`  
  *[salida de terminal / comandos pegados: 18 lineas]*
- **13/10 11:59** — [archivo adjunto: evidencia_p3.zip]

## Repositorio y entregables

- **13/10 02:17** — asi pero quiero avanzar con los entregables : que debe estar en un repositorio github , más archivos de evidencia
- **13/10 02:37** — me refiero al de la pregunta 1 y 2 , esos si ya estan listos
- **13/10 02:39** — [archivo adjunto: evidencia_jetson.zip] [archivo adjunto: evidencia_p2.zip]
- **13/10 02:48** — pero tendre que hacer la pregunta devuelta desde 0?
- **13/10 02:59** — como se sube a github esto sabes?
- **13/10 12:01** — entonces eso es odo , ya no falta nada más?
- **13/10 12:02** — eso si lo avanzare en casa , gracias por la ayuda , nos ayudaste un monton a acabar , más tarde te pediire ayuda para ver que no falte nigun entregable por subir
- **13/10 12:04** — asi mañana haremos un testeo que todo funcione bien , aunque si será con otra ip de computadora ya que esta que uso no la podre usar el dia de la presentación , será con la sdel  viernes
- **13/10 12:11** — el profe me dio permiso de usar esta compu para la expo
- **13/10 12:20** — me das llos entreggables para subir al github de la pregunta 2
- **13/10 12:21** — ahora de p3
- **13/10 12:23** — asi el profe quiere los prompts de todo lo que usamos en cada pregunta y que lo subamos al github
