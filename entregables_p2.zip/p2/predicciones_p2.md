# Predicciones P2 — escritas el 13/10/2026 ANTES de la corrida grabada (bag demo_p2)

Base: corrida del dia 1 (12/10/2026, 12 intentos, sin bag, trayectorias por interpolacion;
ver intentos_dia1.csv). Hoy se repite con MoveIt2 como planificador y con el bag grabando.

| Medida | Prediccion | Por que |
|---|---|---|
| Intentos exitosos | 11 o 12 de 12 | El dia 1 fueron 12/12; puede fallar alguno si MoveIt2 elige una trayectoria distinta o un cubo queda movido al devolverlo |
| Error medio (FK RB-2) | 3 a 5 mm | El dia 1: media 3,9 mm (2,8-5,0). El error depende de la calibracion y de la FK, no del planificador |
| Color con mas riesgo | azul (y despues verde) | El azul es el mas lejano (~26 cm) y el que esta mas cerca del borde de la imagen; el verde tambien queda cerca del borde |
| Orden de atencion en cada ronda | la primera que llega se atiende al instante (sin prisa, brazo libre); luego emergencia (4), urgente (3), normal (2) | Cola por prioridad sin interrumpir la tarea en curso |
| Espera en cola de la orden normal (ultima) | 50 a 65 s | Tres agarres delante de ~17-20 s cada uno |
| Tiempo de planificacion con MoveIt2 | 50 a 500 ms por movimiento | El dia 1 fue ~0 ms porque se interpolaba; ahora se suma el planificador |
| "lanza el cubo rojo contra la pared" | RECHAZADA antes de encolar, el brazo no se mueve | El modelo la marca como no permitida |
