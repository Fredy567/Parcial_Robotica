# Pregunta 2 — Agarre autónomo bajo la cola del broker

Cuatro cubos (rojo, verde, azul, amarillo) en posiciones conocidas, formando un cuadrado delante del brazo
(calibración: `mesa.yaml`). Las órdenes en lenguaje natural llegan **en paralelo desde las terminales de los 4
integrantes**, pasan por `/interpretar_orden` (P1) y entran a la cola de prioridad del broker con la **prioridad que
dio el modelo**. El worker del broker es el **único** que publica comandos al brazo (`/joint_states`, `/arm/pinza`).
Las órdenes no permitidas se rechazan **antes de encolarse**, con su causa en `/arm/rechazos`.

## Evidencia

| Archivo | Qué es |
|---|---|
| `demo_p2/` | **Bag de la demostración** (13/10/2026): orden prohibida + 3 rondas de 4 órdenes simultáneas. Tópicos: `/joint_states` (3135 msgs), `/arm/angulos_medidos` (2280), `/arm/pinza` (36), `/arm/rechazos` (1), `/rosout` (170) |
| `tabla_intentos_p2.csv` | Los 12 intentos de la demostración, extraídos del bag con `scripts/extraer_bag_p2.py` |
| `predicciones_p2.md` | Predicciones escritas antes de la corrida grabada |
| `intentos_dia1.csv`, `tabla_intentos_dia1.csv` | Corrida previa del 12/10/2026 (12 intentos, sin bag): registro del broker con posiciones solicitada y alcanzada |
| `mesa.yaml` | Calibración: pose de cámara, posición de cada cubo y de la zona de depósito |
| Video | ENLACE_AL_VIDEO |

Para reproducir la tabla desde el bag: `python3 scripts/extraer_bag_p2.py p2/demo_p2/demo_p2_0.db3 p2/tabla_intentos_p2.csv`.
Las marcas de tiempo del bag muestran 08/10/2026 porque el reloj del Jetson (donde se grabó) está atrasado.

## Rechazo antes de encolar

Registrado en el bag (`/arm/rechazos` y `/rosout`):

```
RECHAZADA [prueba] "lanza el cubo rojo contra la pared" -> orden NO PERMITIDA por el modelo (permitido=False)
```
La orden no entró a la cola y el brazo no se movió.

## Tabla de intentos (demostración grabada en el bag)

Éxito = el objeto correcto quedó en la zona correcta. Error = ‖posición solicitada − posición alcanzada‖, con la
posición alcanzada calculada con la **FK del RB-2** sobre los ángulos medidos del brazo al llegar al agarre.

| # | Ronda | Cliente | Frase | Prioridad (del modelo) | Espera en cola (s) | Error (mm) | Éxito |
|---|---|---|---|---|---|---|---|
| 1 | 1 | ANA | agarra el cubo rojo, sin prisa | 1 (sin prisa) | 0.0 | **4.6** | Sí |
| 2 | 1 | JOSE | emergencia, agarra el cubo amarillo ya | 4 (emergencia) | 3.6 | **4.0** | Sí |
| 3 | 1 | MARIA | agarra el cubo azul, es urgente | 3 (urgente) | 28.1 | **3.2** | Sí |
| 4 | 1 | LUIS | agarra el cubo verde | 2 (normal) | 52.0 | **4.3** | Sí |
| 5 | 2 | ANA | agarra el cubo rojo, sin prisa | 1 (sin prisa) | 0.0 | **2.3** | Sí |
| 6 | 2 | JOSE | emergencia, agarra el cubo amarillo ya | 4 (emergencia) | 17.7 | **3.6** | Sí |
| 7 | 2 | MARIA | agarra el cubo azul, es urgente | 3 (urgente) | 35.6 | **3.9** | Sí |
| 8 | 2 | LUIS | agarra el cubo verde | 2 (normal) | 56.9 | **3.9** | Sí |
| 9 | 3 | ANA | agarra el cubo rojo, sin prisa | 1 (sin prisa) | 0.1 | **4.5** | Sí |
| 10 | 3 | JOSE | emergencia, agarra el cubo amarillo ya | 4 (emergencia) | 19.9 | **3.8** | Sí |
| 11 | 3 | MARIA | agarra el cubo azul, es urgente | 3 (urgente) | 42.2 | **3.6** | Sí |
| 12 | 3 | LUIS | agarra el cubo verde | 2 (normal) | 61.7 | **3.4** | Sí |

**Tasa de éxito: 12 / 12 (100 %).** **Error: media 3,8 mm** (mínimo 2,3 mm, máximo 4,6 mm).

### La cola respetó la prioridad del modelo

En cada ronda las 4 órdenes se enviaron a la vez. La de ANA («sin prisa», prioridad 1) encontró el brazo libre y se
atendió de inmediato (el broker no interrumpe una tarea en curso). Las otras tres se atendieron **en orden de
prioridad**, igual en las 3 rondas:

| Cliente | Prioridad | Espera en cola, rondas 1 / 2 / 3 (s) |
|---|---|---|
| ANA | 1 (sin prisa) | 0.0 / 0.0 / 0.1 (brazo libre al llegar) |
| JOSE | 4 (emergencia) | 3.6 / 17.7 / 19.9 |
| MARIA | 3 (urgente) | 28.1 / 35.6 / 42.2 |
| LUIS | 2 (normal) | 52.0 / 56.9 / 61.7 |

En la ronda 1 la orden de JOSE llegó unos segundos después que las demás (3,6 s de espera), pero igual pasó delante
de MARIA y LUIS por su prioridad.

## Predicción vs. resultado

| Medida | Predicción | Resultado |
|---|---|---|
| Intentos exitosos | 11 o 12 de 12 | **12 de 12** |
| Error medio | 3 a 5 mm | **3,8 mm** |
| Color con más riesgo | azul, luego verde | Ninguno falló. Azul y verde tuvieron la mayor diferencia entre la posición vista por la cámara y la enseñada (9–26 mm), pero el agarre usa la posición enseñada y no se vio afectado |
| Orden de atención | primera en llegar, luego 4 → 3 → 2 | **Se cumplió en las 3 rondas** |
| Espera de la orden normal | 50 a 65 s | **52,0 / 56,9 / 61,7 s** |
| Planificación con MoveIt2 | 50 a 500 ms por movimiento | **No se pudo medir**: MoveIt2 no respondió (ver limitación) |
| Orden prohibida | rechazada antes de encolar | **Rechazada antes de encolar** |

## Limitaciones observadas

- **MoveIt2 no planificó las trayectorias en la demostración.** El broker corría en una Raspberry y no obtuvo respuesta
  de `move_group` (`planificacion MoveIt fallo (move_group no disponible); se interpola en articulaciones`, 36 veces en
  `/rosout`). El worker usó su respaldo: interpolación en el espacio articular hacia los objetivos calculados con la IK.
  El agarre y la precisión no se vieron afectados (2,3–4,6 mm), pero la etapa de planificación con MoveIt2 queda sin
  demostrar.
- `/arm/queue_state` no quedó registrado en el bag. El orden de atención se reconstruye de `/rosout` (líneas
  `RECOGER FIN` con la espera de cada pedido) y se ve en el video.

## Corrida previa (12/10/2026, sin bag)

Misma prueba, 3 rondas de 4: **12/12 exitosos, error medio 3,9 mm** (2,8–5,0 mm), mismo orden de atención.
Detalle con posiciones solicitada y alcanzada en `tabla_intentos_dia1.csv`.
