#!/usr/bin/env python3
"""Extrae del bag de la P2 (sin necesitar ROS) los intentos y rechazos registrados por el broker.

  python3 scripts/extraer_bag_p2.py p2/demo_p2/demo_p2_0.db3 p2/tabla_intentos_bag.csv

Lee /rosout (lineas 'RECOGER FIN' y 'RECHAZADA' del broker), /arm/rechazos y cuenta los mensajes de cada topico.
"""
import csv
import re
import sqlite3
import sys

PRIO = {"ANA": 1, "LUIS": 2, "MARIA": 3, "JOSE": 4}   # prioridad que dio el modelo a cada frase
FRASE = {"ANA": "agarra el cubo rojo, sin prisa", "LUIS": "agarra el cubo verde",
         "MARIA": "agarra el cubo azul, es urgente", "JOSE": "emergencia, agarra el cubo amarillo ya"}


def textos(blob):
    return re.findall(r"[ -~À-ſ]{8,}", blob.decode("utf-8", "replace"))


def main(db, salida):
    c = sqlite3.connect(db)
    print("Mensajes por topico:")
    for tid, name in c.execute("select id, name from topics"):
        n = c.execute("select count(*) from messages where topic_id=?", (tid,)).fetchone()[0]
        print(f"  {name:24s} {n}")
    tid = c.execute("select id from topics where name='/rosout'").fetchone()[0]
    filas, n, interp = [], 0, 0
    for (blob,) in c.execute("select data from messages where topic_id=? order by timestamp", (tid,)):
        s = " ".join(textos(blob))
        if "se interpola en articulaciones" in s:
            interp += 1
        m = re.search(r"RECOGER FIN \[(\w+)\] (\w+): (\w+) .*?error=([\d.]+) mm espera=([\d.]+)s", s)
        if m:
            n += 1
            cli, color, est, err, esp = m.groups()
            filas.append({"intento": n, "ronda": (n - 1) // 4 + 1, "cliente": cli, "frase": FRASE.get(cli, ""),
                          "color": color, "prioridad_modelo": PRIO.get(cli, ""), "espera_cola_s": esp,
                          "error_mm": err, "resultado_broker": est, "planificador": "interpolacion"})
        r = re.search(r'RECHAZADA \[(\w+)\] "([^"]+)" -> (.+?)(?: /|$)', s)
        if r:
            print(f"Rechazo: [{r.group(1)}] \"{r.group(2)}\" -> {r.group(3)}")
    with open(salida, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(filas[0]))
        w.writeheader()
        w.writerows(filas)
    e = [float(f["error_mm"]) for f in filas]
    print(f"{len(filas)} intentos, ok={sum(f['resultado_broker'] == 'ok' for f in filas)}, "
          f"error medio {sum(e) / len(e):.2f} mm (min {min(e)}, max {max(e)}); "
          f"movimientos interpolados: {interp}  -> {salida}")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
