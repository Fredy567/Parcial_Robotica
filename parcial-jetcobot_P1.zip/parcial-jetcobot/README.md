# Parcial Gran Reto JetCobot — Robótica (08079), ESAN 2026-2

Equipo N.º __ · Integrantes: __

## Pregunta 1 — Servicio de interpretación de órdenes

Nodo ROS 2 `interprete_ordenes` que expone `/interpretar_orden`: recibe una frase en español y
devuelve una **decisión tipada** (acción, objeto, color, prioridad, permitido) consultando por HTTP
al servidor LAYA. Si LAYA no responde dentro de `timeout_s` (1,0 s), resuelve con un clasificador
propio por palabras clave y marca la respuesta como `degradado = true`.

| Entregable | Archivo |
|---|---|
| Código del nodo | `src/paquetes_parcial/pkg/examen_nodos/examen_nodos/interprete_ordenes.py` (+ `laya_cliente.py`) |
| Interfaz del servicio | `src/paquetes_parcial/pkg/interfaces_examen/srv/InterpretarOrden.srv` |
| CSV: 50 frases y decisión de cada método | `p1/calma.csv`, `p1/carga1.csv` (preguntas afinadas) · `p1/p1_ensayo_50_frases.csv`, `p1/ensayo_real.csv` (preguntas iniciales) |
| Tablas de latencia (calma y carga) y exactitud | `p1/tablas_p1.md` |
| Figuras | `p1/latencia_ensayo.png`, `p1/latencia_p1.png`, `p1/cola_carga.png` |
| Preguntas afinadas a LAYA | `p1/preguntas_laya.json` |
| Predicciones (antes de medir) | `p1/predicciones.md` |
| Informe (incluye la media página sobre fallos de cada método) | `informe/Informe_P1_JetCobot.docx` |

### Resultados principales (50 frases de ensayo, servidor LAYA en CPU, checkpoint multilingual)

| | Calma | Carga (4 clientes) |
|---|---|---|
| Servicio, mediana / P95 | 158,0 / 220,9 ms | 209,1 / 677,6 ms |
| Cálculo del servidor, mediana / P95 | 134,6 / 196,3 ms | 179,2 / 230,3 ms |
| Red + cola, mediana / P95 | 17,4 / 41,2 ms | 19,3 / 457,8 ms |
| Respuestas degradadas | 0 / 50 | 0 / 50 |
| Exactitud LAYA (frase completa) | 16 % | 16 % |
| Exactitud palabras clave (frase completa)* | 80 % | 80 % |

\* Inflada: las frases de ensayo y las palabras clave fueron escritas por el mismo equipo.

Bajo carga, los 4 clientes coincidieron en las primeras ~15 consultas: la espera en la cola del servidor
fue de 350–520 ms con ≈ 3 clientes delante, ≈ 220 ms con 1 y ≈ 15 ms sin otros clientes (`p1/cola_carga.png`).
Las decisiones fueron idénticas en calma y bajo carga.

### Servidor LAYA

Levantado por el equipo con el paquete oficial (`pip install "laya[serve]"`, v0.4.1) en una PC del
laboratorio (172.51.1.11:8000), CPU, `LAYA_MODELS=multilingual`. El Jetson lo usa con
`LAYA_URL=http://172.51.1.11:8000`. **Ninguna clave está en el repositorio**: se leen de variables de entorno.

### Cómo reproducir

```bash
source /opt/ros/humble/setup.bash
cd examen_ws && colcon build --symlink-install && source install/setup.bash
export LAYA_URL=http://172.51.1.11:8000
ros2 run examen_nodos interprete_ordenes --ros-args -p timeout_s:=1.0          # terminal 1
ros2 run examen_nodos medir_latencia p1/frases_ensayo.csv p1/calma.csv --etiqueta calma   # terminal 2
ros2 run examen_nodos resumen_p1 p1/calma.csv p1/carga1.csv --figura p1/latencia_p1.png
```

## Autoría

La estructura del broker (`arm_broker`) es la entregada por el curso en el RB-2. LAYA es el
proyecto público https://github.com/NandhaKishorM/laya (solo se usa su servidor HTTP).
