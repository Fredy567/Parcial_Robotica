# Predicciones Pregunta 1 (escribir y hacer commit ANTES de medir)

Fecha/hora: ____  ·  timeout_s elegido: ____ s  ·  ROS_DOMAIN_ID: ____

| Medida | Calma (predicho) | Calma (medido) | Carga (predicho) | Carga (medido) |
|---|---|---|---|---|
| Servicio mediana (ms) | | | | |
| Servicio P95 (ms) | | | | |
| Cálculo servidor mediana (ms) | | | | |
| Red + cola mediana (ms) | | | | |
| Respuestas degradadas | | | | |
| Exactitud LAYA (%) | | | | |
| Exactitud palabras clave (%) | | | | |

Razonamiento de la predicción:
