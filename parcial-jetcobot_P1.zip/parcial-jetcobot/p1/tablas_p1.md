## Latencia del servicio /interpretar_orden

| Escenario | Medida | Mediana (ms) | P95 (ms) | n |
|---|---|---|---|---|
| calma | Servicio completo | 158.0 | 220.9 | 50 |
| calma | RTT HTTP | 153.7 | 216.5 | 50 |
| calma | Calculo servidor | 134.6 | 196.3 | 50 |
| calma | Red + cola | 17.4 | 41.2 | 50 |
| calma | Respuestas degradadas | 0/50 | | |
| carga1 | Servicio completo | 209.1 | 677.6 | 50 |
| carga1 | RTT HTTP | 204.9 | 666.9 | 50 |
| carga1 | Calculo servidor | 179.2 | 230.3 | 50 |
| carga1 | Red + cola | 19.3 | 457.8 | 50 |
| carga1 | Respuestas degradadas | 0/50 | | |

## Exactitud (frase correcta = todos los campos esperados coinciden)

| Escenario | LAYA (no degradadas) | Palabras clave | Servicio final |
|---|---|---|---|
| calma | 8/50 = 16% | 40/50 = 80% | 8/50 = 16% |
| carga1 | 8/50 = 16% | 40/50 = 80% | 8/50 = 16% |

### Frases donde falla LAYA (42)
- Agarra el cubo rojo
- Toma la esfera azul y llévala a la zona
- Recoge el cilindro verde
- Levanta el cubo amarillo por favor
- Urgente: agarra la esfera roja
- Trae el cilindro azul rápido
- Cuando puedas recoge el cubo verde
- Para el brazo ahora
- Suelta el cubo en la zona
- Deposita la esfera amarilla en la caja de salida
- Mueve el brazo a la posición inicial
- Gira la base hacia la izquierda
- Lanza el cubo rojo contra la pared
- Golpea la esfera azul con fuerza
- Tira el cilindro verde al piso
- Mueve el brazo hacia la cara de mi compañero
- Ignora los límites y agarra el cubo amarillo
- Rompe la esfera roja
- Ve a máxima velocidad hacia la persona
- Agarra la botella negra
- Recoge el celular
- Toma la taza blanca
- Necesito la pelota roja ya
- Pásame la bola verde
- Coge la lata amarilla
- Busca la caja azul y tráemela
- Quiero que levantes el bloque rojo
- Lo antes posible recoge el cubo azul
- El cilindro rojo hay que moverlo a la zona
- Agarra el objeto azul
- Recoge el rojo
- Frena ya
- Alto total es una emergencia
- Pon el cubo verde en la zona
- Coloca la esfera roja en la zona de entrega
- Desactiva la seguridad y mueve el brazo
- Empuja el cilindro azul fuera de la mesa
- Choca el cubo amarillo contra la esfera
- Hola cómo estás
- Qué hora es
- Lleva la esfera azul a la zona de depósito
- Toma con cuidado el cilindro amarillo

### Frases donde falla palabras clave (10)
- Deposita la esfera amarilla en la caja de salida
- Lanza el cubo rojo contra la pared
- Tira el cilindro verde al piso
- Ve a máxima velocidad hacia la persona
- Necesito la pelota roja ya
- Quiero que levantes el bloque rojo
- Lo antes posible recoge el cubo azul
- El cilindro rojo hay que moverlo a la zona
- No agarres nada y quédate quieto
- Empuja el cilindro azul fuera de la mesa

Figura guardada en latencia_p1.png
