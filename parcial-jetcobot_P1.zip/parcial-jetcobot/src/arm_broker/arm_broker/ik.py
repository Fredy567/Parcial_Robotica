"""Cinematica inversa numerica del JetCobot, sobre la FK (tabla DH) del RB-2.

Metodo: minimos cuadrados amortiguados (Levenberg-Marquardt) con Jacobiano
numerico. Resuelve posicion (x, y, z en mm) y orientacion de la herramienta
(matriz de rotacion de una pose de referencia, normalmente la pose "ensenada"
sobre el cubo, con la pinza mirando hacia abajo).

Se usa la MISMA fk.py del RB-2, asi que el error que reporta la FK al final
es coherente con el que calcula esta IK.

    python3 -m arm_broker.ik 200 0 120           # prueba rapida
"""
import math
import sys

from arm_broker import fk


def _rot(T):
    return [row[:3] for row in T[:3]]


def _pos(T):
    return [T[0][3], T[1][3], T[2][3]]


def _err_orient(R_act, R_obj):
    """Error de orientacion (vector, rad) = 0.5 * sum(r_act_i x r_obj_i)."""
    e = [0.0, 0.0, 0.0]
    for i in range(3):
        a = [R_act[0][i], R_act[1][i], R_act[2][i]]
        b = [R_obj[0][i], R_obj[1][i], R_obj[2][i]]
        c = [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]]
        e = [e[k] + 0.5 * c[k] for k in range(3)]
    return e


def _error(q, p_obj, R_obj, peso_orient):
    T = fk.fk_matriz(q)
    p = _pos(T)
    ep = [p_obj[i] - p[i] for i in range(3)]                          # mm
    eo = _err_orient(_rot(T), R_obj) if R_obj is not None else [0.0, 0.0, 0.0]
    return ep + [peso_orient * v for v in eo]


def _resolver(A, b):
    """Gauss con pivoteo para un sistema 6x6."""
    n = len(A)
    M = [A[i][:] + [b[i]] for i in range(n)]
    for c in range(n):
        piv = max(range(c, n), key=lambda r: abs(M[r][c]))
        M[c], M[piv] = M[piv], M[c]
        if abs(M[c][c]) < 1e-12:
            continue
        for r in range(n):
            if r != c:
                f = M[r][c] / M[c][c]
                for k in range(c, n + 1):
                    M[r][k] -= f * M[c][k]
    return [M[i][n] / M[i][i] if abs(M[i][i]) > 1e-12 else 0.0 for i in range(n)]


def ik(p_obj, q_semilla, R_obj=None, iter_max=300, tol_mm=0.5, tol_rad=0.01,
       peso_orient=100.0, lam=1.0):
    """Devuelve (q, ok, info). q en rad. p_obj en mm.

    R_obj: rotacion 3x3 deseada de la herramienta. None = solo posicion
    (mantiene la orientacion de la semilla lo mas posible).
    """
    q = list(q_semilla)
    if R_obj is None:
        R_obj = _rot(fk.fk_matriz(q_semilla))
    h = 1e-5
    for it in range(iter_max):
        e = _error(q, p_obj, R_obj, peso_orient)
        ep = math.sqrt(sum(v * v for v in e[:3]))
        eo = math.sqrt(sum(v * v for v in e[3:])) / peso_orient
        if ep < tol_mm and eo < tol_rad:
            break
        # Jacobiano numerico de la funcion de error (6 x 6)
        J = [[0.0] * 6 for _ in range(6)]
        for j in range(6):
            dq = list(q)
            dq[j] += h
            e2 = _error(dq, p_obj, R_obj, peso_orient)
            for i in range(6):
                J[i][j] = -(e2[i] - e[i]) / h
        # (J^T J + lam I) dq = J^T e
        JtJ = [[sum(J[k][i] * J[k][j] for k in range(6)) + (lam if i == j else 0.0)
                for j in range(6)] for i in range(6)]
        Jte = [sum(J[k][i] * e[k] for k in range(6)) for i in range(6)]
        paso = _resolver(JtJ, Jte)
        mx = max(abs(v) for v in paso)
        if mx > 0.2:                                   # limita el paso por iteracion
            paso = [v * 0.2 / mx for v in paso]
        q = [q[i] + paso[i] for i in range(6)]
    else:
        it = iter_max

    e = _error(q, p_obj, R_obj, peso_orient)
    ep = math.sqrt(sum(v * v for v in e[:3]))
    eo = math.sqrt(sum(v * v for v in e[3:])) / peso_orient
    # normaliza a (-pi, pi]
    q = [math.atan2(math.sin(v), math.cos(v)) for v in q]
    ok_lim, motivo = fk.dentro_de_limites(q)
    ok = ep < 2.0 and eo < 0.05 and ok_lim
    info = {"iter": it, "error_pos_mm": ep, "error_orient_rad": eo,
            "motivo": "" if ok else (motivo or f"no converge (pos {ep:.1f} mm, orient {eo:.3f} rad)")}
    return q, ok, info


def rotacion_de(q):
    return _rot(fk.fk_matriz(q))


if __name__ == "__main__":
    # Prueba: pinza vertical hacia abajo, semilla tipica de agarre
    x, y, z = (float(v) for v in (sys.argv[1:4] if len(sys.argv) >= 4 else (200, 0, 120)))
    abajo = [[1, 0, 0], [0, -1, 0], [0, 0, -1]]
    semilla = [0.0, -0.6, -1.2, 0.2, 0.0, 0.0]
    q, ok, info = ik([x, y, z], semilla, R_obj=abajo)
    print("q (grados):", [round(math.degrees(v), 1) for v in q])
    print("ok:", ok, info)
    print("FK de la solucion:", [round(v, 1) for v in fk.fk(q)])
