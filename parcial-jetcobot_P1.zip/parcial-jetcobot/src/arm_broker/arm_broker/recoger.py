"""Secuencia de agarre que ejecuta el WORKER del broker (Pregunta 2).

Todo comando al brazo sale de aqui por broker.mover() (/joint_states) o
broker.pinza() (/arm/pinza). Ningun otro nodo mueve el brazo.

Etapas (se miden por separado para la Pregunta 3):
  percepcion  -> /localizar_objeto (la camara ya esta en la pose de reposo)
  IK          -> arm_broker.ik sobre la FK del RB-2
  planificacion -> MoveIt2 /plan_kinematic_path (solo planifica; ejecuta el worker)
  movimiento  -> el worker publica la trayectoria; la pinza agarra y deposita
"""
import math
import time

from arm_broker import fk, ik

from interfaces_examen.srv import LocalizarObjeto

try:
    from moveit_msgs.srv import GetMotionPlan
    from moveit_msgs.msg import Constraints, JointConstraint
    HAY_MOVEIT = True
except ImportError:                       # sin moveit_msgs: se interpola en articulaciones
    HAY_MOVEIT = False


def esperar_futuro(fut, timeout):
    fin = time.time() + timeout
    while not fut.done():
        if time.time() > fin:
            return None
        time.sleep(0.005)
    return fut.result()


class Planificador:
    """Pide a move_group un plan en espacio articular. No ejecuta nada."""

    def __init__(self, nodo, grupo, callback_group, usar=True):
        self.nodo, self.grupo = nodo, grupo
        self.cli = None
        if usar and HAY_MOVEIT:
            self.cli = nodo.create_client(GetMotionPlan, '/plan_kinematic_path',
                                          callback_group=callback_group)

    def disponible(self):
        return self.cli is not None and self.cli.service_is_ready()

    def planear(self, q0, q1, tiempo_s=2.0):
        """Devuelve (lista de waypoints, 'moveit') o (None, motivo)."""
        if not self.disponible():
            return None, "move_group no disponible"
        req = GetMotionPlan.Request()
        r = req.motion_plan_request
        r.group_name = self.grupo
        r.num_planning_attempts = 3
        r.allowed_planning_time = tiempo_s
        r.max_velocity_scaling_factor = 0.5
        r.max_acceleration_scaling_factor = 0.5
        r.start_state.joint_state.name = list(fk.JOINT_NAMES)
        r.start_state.joint_state.position = [float(v) for v in q0]
        c = Constraints()
        for n, v in zip(fk.JOINT_NAMES, q1):
            jc = JointConstraint()
            jc.joint_name, jc.position = n, float(v)
            jc.tolerance_above = jc.tolerance_below = 0.005
            jc.weight = 1.0
            c.joint_constraints.append(jc)
        r.goal_constraints = [c]
        res = esperar_futuro(self.cli.call_async(req), tiempo_s + 3.0)
        if res is None:
            return None, "move_group no respondio"
        mpr = res.motion_plan_response
        if mpr.error_code.val != 1:
            return None, f"MoveIt error {mpr.error_code.val}"
        jt = mpr.trajectory.joint_trajectory
        idx = [jt.joint_names.index(n) for n in fk.JOINT_NAMES]
        pts = [[p.positions[i] for i in idx] for p in jt.points]
        return (pts if len(pts) >= 2 else [list(q0), list(q1)]), "moveit"


class EjecutorRecoger:
    def __init__(self, broker, mesa_cfg, planificador, localizar_cli, log):
        self.b, self.m, self.plan, self.loc, self.log = broker, mesa_cfg, planificador, localizar_cli, log
        self.vel = float(broker.get_parameter('vel_articular_rad_s').value)
        self.hz = 25.0

    # ------------------------------------------------------------ movimiento
    def _publicar_camino(self, puntos, cancelado):
        """Recorre los waypoints a velocidad articular acotada (lo hace el worker)."""
        for a, b in zip(puntos[:-1], puntos[1:]):
            d = max(abs(y - x) for x, y in zip(a, b))
            n = max(1, int(math.ceil(d / self.vel * self.hz)))
            for k in range(1, n + 1):
                if cancelado():
                    return False
                s = k / n
                self.b.mover([x + (y - x) * s for x, y in zip(a, b)])
                time.sleep(1.0 / self.hz)
        return True

    def ir_a(self, q_obj, cancelado, usar_moveit=True, tiempos=None):
        q0 = self.b.q_inicio()
        puntos, metodo = None, "interpolacion"
        if usar_moveit:
            t = time.perf_counter()
            puntos, metodo = self.plan.planear(q0, q_obj)
            if tiempos is not None:
                tiempos["planificacion_ms"] += (time.perf_counter() - t) * 1000
            if puntos is None:
                self.log(f"planificacion MoveIt fallo ({metodo}); se interpola en articulaciones")
                metodo = "interpolacion"
        if puntos is None:
            puntos = [q0, list(q_obj)]
        if tiempos is not None and tiempos.get("t_inicio_movimiento", 0.0) == 0.0:
            tiempos["t_inicio_movimiento"] = time.time()
        ok = self._publicar_camino(puntos, cancelado)
        self.b.esperar_llegada(q_obj)
        return ok, metodo

    # ------------------------------------------------------------ secuencia
    def ejecutar(self, tarea, cancelado, feedback):
        """Devuelve dict con el resultado. Lanza RuntimeError con la causa si falla."""
        m = self.m
        tiempos = {"percepcion_ms": 0.0, "ik_ms": 0.0, "planificacion_ms": 0.0, "t_inicio_movimiento": 0.0}
        planificadores = set()
        watch = m["watch_q"]
        h = float(m["altura_aproximacion_mm"])
        color = tarea.color

        # 0) la camara tiene que estar en su pose (normalmente ya esta: es la pose de reposo)
        if fk.paso_articular(self.b.q_inicio(), watch) > math.radians(3):
            feedback("POSICIONANDO_CAMARA")
            self.b.pinza(m["pinza"]["abierta"])
            self.ir_a(watch, cancelado, usar_moveit=False)   # no cuenta como inicio de la tarea
            time.sleep(0.5)

        # 1) percepcion
        feedback("PERCEPCION")
        t = time.perf_counter()
        req = LocalizarObjeto.Request()
        req.color = color
        res = None
        if self.loc.wait_for_service(timeout_sec=1.0):
            res = esperar_futuro(self.loc.call_async(req), 6.0)
        tiempos["percepcion_ms"] = (time.perf_counter() - t) * 1000
        obj = m["objetos"].get(color)
        if res is not None and res.encontrado:
            objetivo = [res.x_mm, res.y_mm, res.z_mm]
            fuente = res.metodo
        elif (res is None or res.metodo == "sin_camara") and obj is not None \
                and self.b.get_parameter('respaldo_posicion_conocida').value:
            objetivo = list(obj["xyz"])
            fuente = "posicion_conocida (camara no disponible)"
            self.log(f"camara no disponible: se usa la posicion conocida de {color}")
        else:
            raise RuntimeError(res.mensaje if res is not None else "localizador no responde")
        self.log(f"objetivo {color}: ({objetivo[0]:.0f}, {objetivo[1]:.0f}, {objetivo[2]:.0f}) mm [{fuente}]")

        # 2) IK (semilla y orientacion = la pose ensenada del lugar mas cercano)
        feedback("IK")
        t = time.perf_counter()
        lugar = min(m["objetos"].values(), key=lambda o: math.dist(o["xyz"][:2], objetivo[:2]))
        R = ik.rotacion_de(lugar["q"])
        arriba = [objetivo[0], objetivo[1], objetivo[2] + h]
        q_arriba, ok1, i1 = ik.ik(arriba, lugar["q"], R)
        q_agarre, ok2, i2 = ik.ik(objetivo, q_arriba if ok1 else lugar["q"], R)
        zona = m["zona"]
        Rz = ik.rotacion_de(zona["q"])
        z_arriba = [zona["xyz"][0], zona["xyz"][1], zona["xyz"][2] + h]
        q_zona_arriba, ok3, i3 = ik.ik(z_arriba, zona["q"], Rz)
        tiempos["ik_ms"] = (time.perf_counter() - t) * 1000
        for ok, info, nombre in ((ok1, i1, "aproximacion"), (ok2, i2, "agarre"), (ok3, i3, "zona")):
            if not ok:
                raise RuntimeError(f"IK sin solucion para {nombre}: {info['motivo']}")

        # 3) planificacion + movimiento hasta encima del objeto
        feedback("PLANIFICANDO_Y_MOVIENDO")
        self.b.pinza(m["pinza"]["abierta"])
        ok, met = self.ir_a(q_arriba, cancelado, True, tiempos)
        planificadores.add(met)
        if not ok:
            raise InterruptedError()
        # bajada vertical corta: interpolacion articular
        ok, _ = self.ir_a(q_agarre, cancelado, usar_moveit=False)
        if not ok:
            raise InterruptedError()
        time.sleep(0.8)
        q_med = self.b.q_medido_reciente()
        if q_med is None:                     # sin angulos medidos no hay error real que reportar
            self.log("sin /arm/angulos_medidos: no se puede medir el error (¿driver_jetcobot corriendo?)")
            alcanzado, error = list(fk.fk(q_agarre)), -1.0
        else:
            alcanzado = list(fk.fk(q_med))
            error = math.dist(alcanzado, objetivo)

        # 4) agarrar, subir, llevar a la zona, soltar
        feedback("AGARRANDO")
        self.b.pinza(m["pinza"]["cerrada"])
        time.sleep(1.5)
        for q, mov in ((q_arriba, False), (q_zona_arriba, True), (zona["q"], False)):
            ok, met = self.ir_a(q, cancelado, usar_moveit=mov)
            if mov:
                planificadores.add(met)
            if not ok:
                raise InterruptedError()
        feedback("SOLTANDO")
        self.b.pinza(m["pinza"]["abierta"])
        time.sleep(1.0)
        self.ir_a(q_zona_arriba, cancelado, usar_moveit=False)
        feedback("VOLVIENDO")
        ok, met = self.ir_a(watch, cancelado, usar_moveit=True)
        planificadores.add(met)

        return {"objetivo": objetivo, "alcanzado": alcanzado, "error_mm": error,
                "planificador": "+".join(sorted(planificadores)), "fuente": fuente, **tiempos}
