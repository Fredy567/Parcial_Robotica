"""arm_broker — el único nodo que publica en /joint_states.

Pregunta 2 del parcial: se agrega la acción `recoger_objeto` (RecogerObjeto) que
usa LA MISMA cola, LA MISMA política y EL MISMO worker que `move_arm`. El worker
sigue siendo el único que comanda el brazo (/joint_states y /arm/pinza).

Andamiaje entregado por el curso. Los bloques IMPLEMENTAR son lo que evalúa el
reto; el resto es instrumentación y se usa tal cual.
"""

import threading
import time
import math #lo que nos va a permitir transformarlo a grados
import csv
import json
import os

import rclpy
from rclpy.action import ActionServer, CancelResponse, GoalResponse
from rclpy.callback_groups import MutuallyExclusiveCallbackGroup, ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node
from sensor_msgs.msg import JointState
from std_msgs.msg import Int32, String

from arm_broker_interfaces.action import MoveArm, RecogerObjeto
from interfaces_examen.srv import LocalizarObjeto
from arm_broker_interfaces.msg import QueueState

from arm_broker import fk
from arm_broker.politicas import POLITICAS, Pedido
from arm_broker import mesa as mesa_cfg
from arm_broker.recoger import EjecutorRecoger, Planificador


class ArmBroker(Node):

    def __init__(self):
        super().__init__('arm_broker')

        self.declare_parameter('politica', 'fifo')
        self.declare_parameter('tau_envejecimiento_s', 8.0)
        self.declare_parameter('cola_max', 20)
        self.declare_parameter('paso_max_rad', 1.2)
        self.declare_parameter('duracion_movimiento_s', 3.0)
        self.declare_parameter('pasos_interpolacion', 10)
        # ---- Pregunta 2
        self.declare_parameter('mesa', mesa_cfg.RUTA_DEFECTO)
        self.declare_parameter('usar_moveit', True)
        self.declare_parameter('grupo_moveit', 'arm_group')
        self.declare_parameter('vel_articular_rad_s', 0.6)
        self.declare_parameter('tol_llegada_deg', 3.0)
        self.declare_parameter('espera_llegada_s', 4.0)
        self.declare_parameter('respaldo_posicion_conocida', True)
        self.declare_parameter('log_intentos', os.path.expanduser('~/examen_ws/p2/intentos.csv'))

        nombre = self.get_parameter('politica').value
        if nombre not in POLITICAS:
            raise RuntimeError(f'política desconocida: {nombre}. Hay {list(POLITICAS)}')
        clase = POLITICAS[nombre]
        if nombre == 'prioridad':
            self.politica = clase(self.get_parameter('tau_envejecimiento_s').value)
        else:
            self.politica = clase()

        self.cola_max = int(self.get_parameter('cola_max').value)
        self.paso_max = float(self.get_parameter('paso_max_rad').value)
        self.duracion = float(self.get_parameter('duracion_movimiento_s').value)
        self.pasos = max(1, int(self.get_parameter('pasos_interpolacion').value))

        self.grupo_entrada = ReentrantCallbackGroup()
        self.grupo_worker = MutuallyExclusiveCallbackGroup()

        self.lock = threading.Lock()
        self.pendientes = []
        self.por_goal_id = {}
        self.ejecutando = None
        self.q_actual = [0.0] * 6
        self.n_aceptados = 0
        self.n_rechazados = 0
        self.n_completados = 0
        self._parar = threading.Event()

        self.pub_joint = self.create_publisher(JointState, '/joint_states', 10)
        self.pub_cola = self.create_publisher(QueueState, '/arm/queue_state', 10)
        self.pub_pinza = self.create_publisher(Int32, '/arm/pinza', 10)
        self.pub_rechazos = self.create_publisher(String, '/arm/rechazos', 10)
        self.q_medido, self.t_medido, self._sincronizado = None, 0.0, False
        self.create_subscription(JointState, '/arm/angulos_medidos', self._cb_medido, 10,
                                 callback_group=self.grupo_entrada)

        self.servidor = ActionServer(
            self,
            MoveArm,
            'move_arm',
            goal_callback=self.goal_callback,
            handle_accepted_callback=self.handle_accepted_callback,
            cancel_callback=self.cancel_callback,
            execute_callback=self.execute_callback,
            callback_group=self.grupo_entrada,
        )

        # ---- Pregunta 2: acción recoger_objeto sobre la MISMA cola
        try:
            self.mesa = mesa_cfg.cargar(self.get_parameter('mesa').value)
        except Exception as e:
            self.mesa = None
            self.get_logger().error(f'No se pudo leer la mesa ({e}). Corran calibrar_mesa.')
        self.grupo_servicios = ReentrantCallbackGroup()
        self.planificador = Planificador(self, self.get_parameter('grupo_moveit').value,
                                         self.grupo_servicios, self.get_parameter('usar_moveit').value)
        self.cli_localizar = self.create_client(LocalizarObjeto, '/localizar_objeto',
                                                callback_group=self.grupo_servicios)
        self.ejecutor = EjecutorRecoger(self, self.mesa, self.planificador, self.cli_localizar,
                                        lambda t: self.get_logger().info(t)) if self.mesa else None
        self.servidor_recoger = ActionServer(
            self,
            RecogerObjeto,
            'recoger_objeto',
            goal_callback=self.goal_callback_recoger,
            handle_accepted_callback=self.handle_accepted_recoger,
            cancel_callback=self.cancel_callback,
            execute_callback=self.execute_recoger,
            callback_group=self.grupo_entrada,
        )

        self.create_timer(0.2, self.publicar_estado_cola,
                          callback_group=self.grupo_worker)

        self.worker = threading.Thread(target=self._worker, daemon=True)
        self.worker.start()

        self.get_logger().info(
            f'arm_broker listo · política={self.politica.nombre} · '
            f'cola_max={self.cola_max} · único publicador de /joint_states')

    # ========================= IMPLEMENTAR · ítem 2 ==========================
    def goal_callback(self, goal_request):
        angulos_solicitados = list(goal_request.joint_positions)
        usuario = goal_request.client_id or 'Desconocido'

        # 1. Chequeo de límites articulares
        es_valido, razon = fk.dentro_de_limites(angulos_solicitados)
        if es_valido == False:
            with self.lock:
                self.n_rechazados += 1
            self.get_logger().warn(f'DENEGADO [{usuario}] -> Límites: {razon}')
            return GoalResponse.REJECT

        # 2. Chequeo de espacio de trabajo (workspace)
        es_valido, razon = fk.dentro_del_workspace(angulos_solicitados)
        if es_valido == False:
            with self.lock:
                self.n_rechazados += 1
            self.get_logger().warn(f'DENEGADO [{usuario}] -> Espacio: {razon}')
            return GoalResponse.REJECT

        # 3. Chequeo de movimiento brusco (paso articular)
        with self.lock:
            posicion_actual = list(self.q_actual)
            total_en_cola = len(self.pendientes)
        
        diferencia_max = fk.paso_articular(posicion_actual, angulos_solicitados)
        if diferencia_max > self.paso_max:
            with self.lock:
                self.n_rechazados += 1
            self.get_logger().warn(f'DENEGADO [{usuario}] -> Salto muy largo: {diferencia_max:.2f} rad (Tope: {self.paso_max:.2f})')
            return GoalResponse.REJECT

        # 4. Chequeo de saturación de cola
        if total_en_cola >= self.cola_max:
            with self.lock:
                self.n_rechazados += 1
            self.get_logger().warn(f'DENEGADO [{usuario}] -> Cola saturada ({total_en_cola}/{self.cola_max})')
            return GoalResponse.REJECT

        # Solicitud aprobada
        with self.lock:
            self.n_aceptados += 1
        cx, cy, cz = fk.fk(angulos_solicitados)
        self.get_logger().info(f'APROBADO [{usuario}] destino: ({cx:.0f}, {cy:.0f}, {cz:.0f}) mm')
        return GoalResponse.ACCEPT

    def handle_accepted_callback(self, goal_handle):
        req = goal_handle.request
        nuevo_pedido = Pedido(goal_handle, req.client_id, req.priority, req.joint_positions)
        
        with self.lock:
            self.pendientes.append(nuevo_pedido)
            self.por_goal_id[nuevo_pedido.goal_id] = nuevo_pedido
            lugar_en_fila = len(self.pendientes)
            
        self.get_logger().info(f'AGREGADO A COLA: {nuevo_pedido.client_id} (Turno {lugar_en_fila})')

    def _worker(self):
        while not self._parar.is_set():
            tarea_actual = None
            with self.lock:
                if self.ejecutando is None and len(self.pendientes) > 0:
                    indice_elegido = self.politica.siguiente(self.pendientes)
                    if indice_elegido is not None:
                        tarea_actual = self.pendientes.pop(indice_elegido)
                        if tarea_actual.goal_handle.is_cancel_requested:
                            self.por_goal_id.pop(tarea_actual.goal_id, None)
                            tarea_actual = None
                        else:
                            self.ejecutando = tarea_actual
                            tarea_actual.t_inicio_ejec = time.time()
            
            if tarea_actual is None:
                time.sleep(0.02)
                continue

            tarea_actual.goal_handle.execute()
            tarea_actual.fin.wait()

            with self.lock:
                self.ejecutando = None
                self.por_goal_id.pop(tarea_actual.goal_id, None)
                self.n_completados += 1
                
            self.politica.atendido(tarea_actual)

    def execute_callback(self, goal_handle):
        id_tarea = bytes(goal_handle.goal_id.uuid).hex()[:12]
        with self.lock:
            tarea = self.por_goal_id.get(id_tarea)
            
        respuesta = MoveArm.Result()

        if tarea is None:
            goal_handle.abort()
            respuesta.success = False
            return respuesta

        try:
            target_q = tarea.joint_positions
            with self.lock:
                inicio_q = list(self.q_actual)
                
            tiempo_arranque = time.time()
            retraso_paso = self.duracion / self.pasos

            for etapa in range(1, self.pasos + 1):
                if goal_handle.is_cancel_requested:
                    goal_handle.canceled()
                    respuesta.success = False
                    return respuesta

                proporcion = etapa / self.pasos
                q_intermedio = [a + (b - a) * proporcion for a, b in zip(inicio_q, target_q)]
                self.mover(q_intermedio)

                progreso = MoveArm.Feedback()
                progreso.state = 'MOVIMIENTO_EN_PROGRESO'
                progreso.elapsed_s = time.time() - tiempo_arranque
                goal_handle.publish_feedback(progreso)
                
                time.sleep(retraso_paso)

            goal_handle.succeed()
            respuesta.success = True
            respuesta.wait_time_s = tarea.espera_s
            respuesta.exec_time_s = time.time() - tiempo_arranque
            self.get_logger().info(f'MOVIMIENTO FINALIZADO para {tarea.client_id}')
            return respuesta
            
        finally:
            tarea.fin.set()
    # =========================================================================
    # =========================================================================

    # ========================= Pregunta 2 · recoger_objeto ===================
    def _rechazar_recoger(self, req, causa):
        with self.lock:
            self.n_rechazados += 1
        self.get_logger().warn(f'RECHAZADA [{req.client_id}] "{req.frase}" -> {causa}')
        msg = String()
        msg.data = json.dumps({'t': time.time(), 'client_id': req.client_id, 'frase': req.frase,
                               'causa': causa, 'accion': req.accion, 'objeto': req.objeto,
                               'color': req.color, 'permitido': req.permitido}, ensure_ascii=False)
        self.pub_rechazos.publish(msg)
        self._log_intento(req, None, False, f'RECHAZADA: {causa}', {})
        return GoalResponse.REJECT

    def goal_callback_recoger(self, req):
        """Admisión ANTES de encolar: aquí se rechazan las órdenes no permitidas."""
        if not req.permitido:
            return self._rechazar_recoger(req, 'orden NO PERMITIDA por el modelo (permitido=False)')
        if req.accion != 'agarrar':
            return self._rechazar_recoger(req, f"la acción '{req.accion}' no es un agarre")
        if self.mesa is None or self.ejecutor is None:
            return self._rechazar_recoger(req, 'falta calibrar la mesa (calibrar_mesa)')
        if req.objeto == 'otro' or req.color == 'otro':
            return self._rechazar_recoger(req, f'el objeto pedido ({req.objeto} {req.color}) no está sobre la mesa')
        if req.color not in self.mesa['objetos']:
            return self._rechazar_recoger(req, f"no hay un objeto de color '{req.color}' sobre la mesa")
        with self.lock:
            n_cola = len(self.pendientes)
        if n_cola >= self.cola_max:
            return self._rechazar_recoger(req, f'cola llena ({n_cola}/{self.cola_max})')
        with self.lock:
            self.n_aceptados += 1
        self.get_logger().info(f'APROBADO [{req.client_id}] recoger {req.color} prioridad={req.priority}')
        return GoalResponse.ACCEPT

    def handle_accepted_recoger(self, goal_handle):
        req = goal_handle.request
        pedido = Pedido(goal_handle, req.client_id, req.priority, [])
        pedido.tarea = req
        with self.lock:
            self.pendientes.append(pedido)
            self.por_goal_id[pedido.goal_id] = pedido
            turno = len(self.pendientes)
        self.get_logger().info(f'AGREGADO A COLA: {pedido.client_id} recoger {req.color} '
                               f'p={req.priority} (Turno {turno})')

    def execute_recoger(self, goal_handle):
        gid = bytes(goal_handle.goal_id.uuid).hex()[:12]
        with self.lock:
            tarea = self.por_goal_id.get(gid)
        res = RecogerObjeto.Result()
        if tarea is None:
            goal_handle.abort()
            res.success, res.message = False, 'pedido no encontrado'
            return res
        t_ini = time.time()
        datos = {}

        def feedback(estado):
            fb = RecogerObjeto.Feedback()
            fb.state, fb.queue_position, fb.elapsed_s = estado, 0, time.time() - t_ini
            goal_handle.publish_feedback(fb)

        try:
            datos = self.ejecutor.ejecutar(tarea.tarea, lambda: goal_handle.is_cancel_requested, feedback)
            goal_handle.succeed()
            res.success, res.message = True, f"ok ({datos['fuente']})"
        except InterruptedError:
            goal_handle.canceled()
            res.success, res.message = False, 'cancelado'
        except Exception as e:
            self.get_logger().error(f'fallo recoger [{tarea.client_id}]: {e}')
            try:
                goal_handle.abort()
            except Exception:
                pass
            res.success, res.message = False, str(e)
            try:                                     # deja el brazo en reposo
                self.ejecutor.ir_a(self.mesa['watch_q'], lambda: False, usar_moveit=False)
            except Exception:
                pass
        finally:
            res.wait_time_s = float(t_ini - tarea.t_llegada)
            res.exec_time_s = float(time.time() - t_ini)
            res.percepcion_ms = float(datos.get('percepcion_ms', 0.0))
            res.ik_ms = float(datos.get('ik_ms', 0.0))
            res.planificacion_ms = float(datos.get('planificacion_ms', 0.0))
            res.t_inicio_movimiento = float(datos.get('t_inicio_movimiento', 0.0))
            res.objetivo_xyz = [float(v) for v in datos.get('objetivo', [])]
            res.alcanzado_xyz = [float(v) for v in datos.get('alcanzado', [])]
            res.error_mm = float(datos.get('error_mm', -1.0))
            res.planificador = datos.get('planificador', '')
            self._log_intento(tarea.tarea, tarea, res.success, res.message, datos, res)
            self.get_logger().info(f'RECOGER FIN [{tarea.client_id}] {tarea.tarea.color}: {res.message} '
                                   f'error={res.error_mm:.1f} mm espera={res.wait_time_s:.1f}s')
            tarea.fin.set()
        return res

    # ---- utilidades que usa el ejecutor (siempre desde el hilo del worker)
    def _cb_medido(self, msg):
        d = dict(zip(msg.name, msg.position))
        if all(n in d for n in fk.JOINT_NAMES):
            q = [d[n] for n in fk.JOINT_NAMES]
            with self.lock:
                self.q_medido, self.t_medido = q, time.time()
                if not self._sincronizado and self.ejecutando is None:
                    self.q_actual = list(q)       # arranca desde donde realmente está el brazo
                    self._sincronizado = True

    def q_medido_reciente(self, max_edad_s=1.0):
        with self.lock:
            if self.q_medido is not None and time.time() - self.t_medido <= max_edad_s:
                return list(self.q_medido)
        return None

    def q_inicio(self):
        with self.lock:
            return list(self.q_actual)

    def esperar_llegada(self, q_obj):
        """Espera a que el brazo REAL llegue (según los ángulos medidos)."""
        tol = math.radians(float(self.get_parameter('tol_llegada_deg').value))
        fin = time.time() + float(self.get_parameter('espera_llegada_s').value)
        while time.time() < fin:
            q = self.q_medido_reciente(0.6)
            if q is None:
                time.sleep(0.6)            # sin mediciones: margen fijo
                return
            if fk.paso_articular(q, q_obj) <= tol:
                return
            time.sleep(0.05)

    def pinza(self, valor):
        m = Int32()
        m.data = int(valor)
        self.pub_pinza.publish(m)

    def _log_intento(self, req, pedido, ok, mensaje, datos, res=None):
        ruta = self.get_parameter('log_intentos').value
        if not ruta:
            return
        campos = ['t_unix', 'client_id', 'frase', 'accion', 'objeto', 'color', 'prioridad',
                  'permitido', 'degradado', 'decision_ms', 'espera_s', 'percepcion_ms', 'ik_ms',
                  'planificacion_ms', 't_inicio_movimiento', 'ejecucion_s', 'obj_x', 'obj_y', 'obj_z',
                  'alc_x', 'alc_y', 'alc_z', 'error_mm', 'planificador', 'success', 'mensaje',
                  'exito_visual']
        o = datos.get('objetivo', [None] * 3) or [None] * 3
        a = datos.get('alcanzado', [None] * 3) or [None] * 3
        fila = {'t_unix': f'{time.time():.3f}', 'client_id': req.client_id, 'frase': req.frase,
                'accion': req.accion, 'objeto': req.objeto, 'color': req.color,
                'prioridad': req.priority, 'permitido': req.permitido, 'degradado': req.degradado,
                'decision_ms': f'{req.decision_ms:.1f}',
                'espera_s': f'{res.wait_time_s:.2f}' if res else '',
                'percepcion_ms': f"{datos.get('percepcion_ms', 0):.1f}" if datos else '',
                'ik_ms': f"{datos.get('ik_ms', 0):.1f}" if datos else '',
                'planificacion_ms': f"{datos.get('planificacion_ms', 0):.1f}" if datos else '',
                't_inicio_movimiento': f"{datos.get('t_inicio_movimiento', 0):.3f}" if datos else '',
                'ejecucion_s': f'{res.exec_time_s:.2f}' if res else '',
                'obj_x': o[0], 'obj_y': o[1], 'obj_z': o[2], 'alc_x': a[0], 'alc_y': a[1], 'alc_z': a[2],
                'error_mm': f"{datos['error_mm']:.1f}" if 'error_mm' in datos else '',
                'planificador': datos.get('planificador', ''), 'success': ok, 'mensaje': mensaje,
                'exito_visual': ''}
        try:
            os.makedirs(os.path.dirname(ruta), exist_ok=True)
            nuevo = not os.path.exists(ruta)
            with open(ruta, 'a', newline='', encoding='utf-8') as fh:
                w = csv.DictWriter(fh, fieldnames=campos)
                if nuevo:
                    w.writeheader()
                w.writerow(fila)
        except Exception as e:
            self.get_logger().warn(f'no se pudo escribir {ruta}: {e}')

    def cancel_callback(self, goal_handle):
        return CancelResponse.ACCEPT

    # ----------------------------------------------------------- publicar
    def mover(self, q):
        msg = JointState()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.header.frame_id = 'base_link'
        msg.name = fk.JOINT_NAMES
        msg.position = [float(v) for v in q]
        self.pub_joint.publish(msg)
        with self.lock:
            self.q_actual = list(q)

    def publicar_estado_cola(self):
        msg = QueueState()
        msg.stamp = self.get_clock().now().to_msg()
        with self.lock:
            ej = self.ejecutando
            msg.executing_client = ej.client_id if ej else ''
            msg.executing_goal_id = ej.goal_id if ej else ''
            msg.executing_elapsed_s = (time.time() - ej.t_inicio_ejec) if ej and ej.t_inicio_ejec else 0.0
            msg.queue_length = len(self.pendientes)
            msg.queued_goal_ids = [p.goal_id for p in self.pendientes]
            msg.queued_clients = [p.client_id for p in self.pendientes]
            msg.queued_priorities = [min(255, max(0, p.priority)) for p in self.pendientes]
            msg.queued_wait_s = [p.espera_s for p in self.pendientes]
            msg.total_accepted = self.n_aceptados
            msg.total_rejected = self.n_rechazados
            msg.total_completed = self.n_completados
            cola = list(self.pendientes)
        self.pub_cola.publish(msg)

        for posicion, p in enumerate(cola, start=1):
            try:
                fb = RecogerObjeto.Feedback() if hasattr(p, 'tarea') else MoveArm.Feedback()
                fb.state = 'QUEUED'
                fb.queue_position = posicion
                fb.elapsed_s = p.espera_s
                p.goal_handle.publish_feedback(fb)
            except Exception:
                pass

    def destroy_node(self):
        self._parar.set()
        return super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    nodo = ArmBroker()
    executor = MultiThreadedExecutor(num_threads=8)
    executor.add_node(nodo)
    try:
        executor.spin()
    except KeyboardInterrupt:
        pass
    finally:
        nodo.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
