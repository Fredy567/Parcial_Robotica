#!/usr/bin/env python3
"""Compara la FK del RB-2 (tabla original y corregida) contra get_coords() del robot.

Se corre con el puerto serie LIBRE (driver apagado).
    ros2 run arm_broker verificar_dh               # mueve a 4 poses y compara
    ros2 run arm_broker verificar_dh --solo-leer   # no mueve; compara donde esta
Criterio del RB-2: error <= 10 mm.
"""
import argparse
import math
import time

from arm_broker import fk

try:
    from pymycobot.mycobot import MyCobot
except ImportError:
    from pymycobot import MyCobot

POSES = {'cero': [0, 0, 0, 0, 0, 0], 'ready': [0, -0.5, 0.5, 0, 0.5, 0],
         'girada': [0.6, -0.4, 0.4, 0, 0.3, 0], 'baja': [0, -1.2, 1.2, 0, 0, 0]}


def fk_con(tabla, q):
    T = [[1.0 if i == j else 0.0 for j in range(4)] for i in range(4)]
    for (al, a, d, off), th in zip(tabla, q):
        T = fk._mul(T, fk._t(al, a, d, th + off))
    return T[0][3], T[1][3], T[2][3]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--puerto', default='/dev/ttyUSB0')
    ap.add_argument('--baud', type=int, default=1000000)
    ap.add_argument('--solo-leer', action='store_true')
    a = ap.parse_args()
    mc = MyCobot(a.puerto, a.baud)
    time.sleep(0.5)
    tablas = {'RB-2 original': fk.DH_RB2_ORIGINAL, 'corregida': fk.DH_CORREGIDA}
    err = {k: [] for k in tablas}
    poses = {'donde esta': None} if a.solo_leer else POSES
    for nombre, q in poses.items():
        if q is not None:
            mc.send_angles([math.degrees(v) for v in q], 30)
            time.sleep(5)
        ang, c = mc.get_angles(), mc.get_coords()
        if not (isinstance(ang, list) and len(ang) == 6 and isinstance(c, list) and len(c) >= 3):
            print(f'{nombre}: el brazo no respondio, repitan')
            continue
        qr = [math.radians(v) for v in ang]
        print(f'\n{nombre}: robot get_coords = ({c[0]:.1f}, {c[1]:.1f}, {c[2]:.1f})')
        for k, t in tablas.items():
            p = fk_con(t, qr)
            e = math.dist(p, c[:3])
            err[k].append(e)
            print(f'   {k:14} FK = ({p[0]:7.1f}, {p[1]:7.1f}, {p[2]:7.1f})  error {e:6.1f} mm')
    print('\nResumen (criterio <= 10 mm):')
    for k, v in err.items():
        if v:
            print(f'   {k:14} error medio {sum(v)/len(v):6.1f} mm   maximo {max(v):6.1f} mm')


if __name__ == '__main__':
    main()
