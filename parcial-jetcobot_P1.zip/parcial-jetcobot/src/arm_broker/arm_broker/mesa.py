"""Configuracion de la mesa: posiciones ensenadas, zona de deposito y camara.

Se genera con  ros2 run examen_nodos calibrar_mesa  y se guarda en YAML.
Todas las posiciones xyz se calculan con la FK del RB-2 sobre los angulos
ensenados, asi la IK y el error usan exactamente el mismo modelo.
"""
import math
import os

import yaml

RUTA_DEFECTO = os.path.expanduser("~/examen_ws/p2/mesa.yaml")
COLORES = ["rojo", "verde", "azul", "amarillo"]


def cargar(ruta=RUTA_DEFECTO):
    with open(os.path.expanduser(ruta)) as fh:
        m = yaml.safe_load(fh) or {}
    m.setdefault("altura_aproximacion_mm", 60.0)
    m.setdefault("pinza", {"abierta": 100, "cerrada": 20})
    m.setdefault("objetos", {})
    m.setdefault("homografia", None)
    m.setdefault("ajuste_slot_mm", 35.0)
    return m


def guardar(m, ruta=RUTA_DEFECTO):
    ruta = os.path.expanduser(ruta)
    os.makedirs(os.path.dirname(ruta), exist_ok=True)
    with open(ruta, "w") as fh:
        yaml.safe_dump(m, fh, sort_keys=False, allow_unicode=True)
    return ruta


def grados(q):
    return [round(math.degrees(v), 2) for v in q]
