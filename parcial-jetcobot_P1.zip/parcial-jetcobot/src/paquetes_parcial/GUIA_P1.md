# Pregunta 1 — Guía paso a paso (LAYA + servicio /interpretar_orden)

> Hagan los pasos **en orden**. Cada paso tiene un "✅ Debe salir" para confirmar antes de seguir.
> `$` = comando en la terminal del **Jetson** (entren por SSH desde la PC: `ssh usuario@IP_JETSON`).

## 0. Qué corre dónde

| Máquina | Qué corre | Ustedes instalan algo |
|---|---|---|
| PC Windows del docente | Servidor LAYA (HTTP, puerto que da el docente) | **NO.** Prohibido instalar o entrenar modelos |
| Jetson (JetCobot) | `interprete_ordenes`, broker del RB-2, medición | Solo `python3-requests` y `matplotlib` |
| Su PC | Terminal SSH al Jetson, editar código, subir a GitHub | Nada extra |

LAYA **no es un nodo ROS 2**: se le habla por HTTP. El único nodo que le habla es `interprete_ordenes`.

---

## 1. Qué hay que descargar / instalar (una sola vez, en el Jetson)

```bash
$ sudo apt update
$ sudo apt install -y python3-requests python3-matplotlib curl
$ python3 -c "import requests, matplotlib; print('OK', requests.__version__)"
```
✅ Debe salir: `OK 2.x.x`

Del repositorio de LAYA **no se descarga nada** para el examen: solo se usa como documentación del formato HTTP (ya lo verifiqué contra `laya/serve.py`: `POST /v1/systemone`, respuesta `answers`, cabecera `X-Inference-Time-Ms`).

---

## 2. Copiar el código corregido al workspace

Su build anterior estaba en `/home/alumno01/ros2_ws`. Reemplacen la carpeta `paquetes_parcial`:

```bash
# desde su PC, copiar el zip al Jetson (o usen USB)
scp p1_entrega.zip usuario@IP_JETSON:~/

# en el Jetson
$ cd ~ && unzip -o p1_entrega.zip -d p1_entrega
$ rm -rf ~/ros2_ws/src/paquetes_parcial
$ cp -r ~/p1_entrega/paquetes_parcial ~/ros2_ws/src/
$ mkdir -p ~/ros2_ws/p1 && cp ~/p1_entrega/p1/* ~/ros2_ws/p1/

$ cd ~/ros2_ws
$ rm -rf build/examen_nodos install/examen_nodos build/interfaces_examen install/interfaces_examen
$ source /opt/ros/humble/setup.bash
$ colcon build --symlink-install --packages-select interfaces_examen examen_nodos
$ source install/setup.bash
$ ros2 interface show interfaces_examen/srv/InterpretarOrden
```
✅ Debe salir: `Summary: 2 packages finished` y la definición con `frase` / `accion objeto color prioridad permitido degradado rtt_ms servidor_ms`.

`--symlink-install` permite editar los `.py` (palabras clave, objetos, colores) **sin volver a compilar**.

---

## 3. Variables de entorno (en CADA terminal nueva)

Creen un archivo **fuera del repositorio** `~/env_examen.sh`:

```bash
$ cat > ~/env_examen.sh <<'EOF'
source /opt/ros/humble/setup.bash
source ~/ros2_ws/install/setup.bash
export ROS_DOMAIN_ID=XX                       # el de su equipo
export LAYA_URL=http://IP_DOCENTE:PUERTO      # lo da el docente al inicio
# export LAYA_MODEL=multilingual              # SOLO si el "preset" del docente es un checkpoint
# export LAYA_API_KEY=...                     # SOLO si el docente puso clave al servidor
EOF
$ source ~/env_examen.sh
$ echo "dominio=$ROS_DOMAIN_ID  laya=$LAYA_URL"
```

Sobre el **"preset"** que entrega el docente: si es un nombre de modelo (`english`, `multilingual`, `typed-decisions`), pónganlo en `LAYA_MODEL`. Para frases en español conviene `multilingual` (es lo que el servidor elige solo). Si es otra cosa, pregúntenle al inicio a qué campo de la petición corresponde.

---

## 4. Verificar que llegan al servidor LAYA (antes de tocar ROS)

```bash
$ ping -c 3 IP_DOCENTE
$ curl -s $LAYA_URL/health
$ curl -s -i $LAYA_URL/v1/systemone -H 'content-type: application/json' -d '{
  "state": {"message": "agarra el cubo rojo"},
  "questions": {"accion": {"type": "choice", "instructions": "Que accion pide `message`?",
                "criteria": {"agarrar": "tomar un objeto", "detener": "parar el brazo"}}}}'
```
✅ Debe salir: `{"status":"ok"...}` y luego `HTTP/1.1 200`, una línea `x-inference-time-ms: ...` y `"choice":"agarrar"`.

Si `ping` responde pero `curl` no → firewall de Windows o puerto equivocado: avisen al docente.

---

## 5. Probar el cliente LAYA solo (sin ROS)

```bash
$ python3 -m examen_nodos.laya_cliente "urgente agarra la esfera roja"
$ python3 -m examen_nodos.laya_cliente "lanza el cubo contra la pared"
```
✅ Debe salir: una línea `Palabras clave: {...}`, otra `LAYA: {...}` con los 5 campos y `Medidas:` con `rtt_ms`, `servidor_ms`, `red_ms`.
Revisen que la segunda frase dé `permitido: False` en LAYA (`p_permitido` < 0.5). Si LAYA da siempre lo mismo en algún campo, ajusten las descripciones del bloque CONFIGURACION en `laya_cliente.py`.

**Antes de seguir: editen el bloque CONFIGURACION** (`~/ros2_ws/src/paquetes_parcial/pkg/examen_nodos/examen_nodos/laya_cliente.py`) con los objetos y colores **reales** de la mesa, tanto en `OBJETOS`/`COLORES` (LAYA) como en `KW_OBJETOS`/`KW_COLORES` (palabras clave). Las claves deben coincidir con las del CSV del docente.

---

## 6. Lanzar el nodo `interprete_ordenes` (Terminal 1)

```bash
$ source ~/env_examen.sh
$ ros2 run examen_nodos interprete_ordenes --ros-args \
    -p timeout_s:=1.5 -p log_csv:=$HOME/ros2_ws/p1/log_servicio.csv
```
✅ Debe salir: `interprete_ordenes listo · timeout_s=1.5 · laya_url=http://...`

## 7. Probar el servicio (Terminal 2)

```bash
$ source ~/env_examen.sh
$ ros2 service list | grep interpretar
$ ros2 service call /interpretar_orden interfaces_examen/srv/InterpretarOrden "{frase: 'agarra el cubo rojo'}"
```
✅ Debe salir: `response: ... accion='agarrar', objeto='cubo', color='rojo', prioridad=2, permitido=True, degradado=False, rtt_ms=..., servidor_ms=...`

## 8. Probar el modo degradado (requisito 2) — guárdenlo como evidencia

Con el nodo corriendo, cambien la URL a una IP que no existe (se lee en cada petición, no hace falta reiniciar):

```bash
$ ros2 param set /interprete_ordenes laya_url http://10.255.255.1:8000
$ time ros2 service call /interpretar_orden interfaces_examen/srv/InterpretarOrden "{frase: 'agarra el cubo rojo'}"
$ ros2 param set /interprete_ordenes laya_url $LAYA_URL   # volver al normal
```
✅ Debe salir: `degradado=True`, `rtt_ms=-1.0`, y en Terminal 1 `WARN LAYA no respondio (TimeoutError...)`. La respuesta llega en ~1.5 s (= `timeout_s`), nunca se queda colgado. Graben la pantalla o guarden `log_servicio.csv`.

---

## 9. Preparar las 50 frases del docente

El script necesita un CSV con columna `frase` y, para la exactitud, las columnas esperadas:

```
frase,accion,objeto,color,prioridad,permitido
Agarra el cubo rojo,agarrar,cubo,rojo,2,true
```
- Si el docente lo entrega en otro formato, conviértanlo a este (Excel → "Guardar como CSV UTF-8").
- Si no trae las respuestas esperadas, etiquétenlas ustedes **antes** de medir (es la "verdad").
- Si no evalúan `prioridad`, borren esa columna: solo se comparan las columnas que existan.
- Para practicar ya tienen `~/ros2_ws/p1/frases_ensayo.csv` (50 frases de ejemplo).

## 10. Escribir la PREDICCIÓN antes de medir (se califica)

Creen `p1/predicciones.md` **antes** de cada corrida, por ejemplo:
```
Calma: espero mediana servicio ≈ __ ms, P95 ≈ __ ms; cálculo servidor ≈ __ ms; red ≈ __ ms
Carga: espero mediana ≈ __ ms (porque el servidor atiende una inferencia a la vez) y __ degradadas
Exactitud: LAYA ≈ __ %, palabras clave ≈ __ %
```
Hagan commit de este archivo antes de medir (la hora del commit prueba que fue antes).

## 11. Elegir el `timeout_s`

Hagan una corrida rápida en calma con el nodo en `timeout_s:=10` (sin cortes) y miren el P95. Un buen límite es ≈ 2–3 × el P95 en calma (ej. P95 = 120 ms → `timeout_s:=0.4`… pero nunca menos de ~0.3 s). Justifiquen el número en el informe: más bajo = más respuestas degradadas bajo carga; más alto = el brazo espera más.

## 12. Medición EN CALMA (requisito 3)

Terminal 1 con el nodo corriendo (paso 6, con su `timeout_s` elegido). Terminal 2:
```bash
$ cd ~/ros2_ws/p1
$ ros2 run examen_nodos medir_latencia frases_docente.csv calma.csv --etiqueta calma
```
✅ Debe salir: 50 líneas `[01] 85.3 ms deg=0 {...}`, luego la tabla de latencia (servicio, RTT, cálculo del servidor, red + cola) y la de exactitud.

## 13. Medición BAJO CARGA (requisito 4)

Cuando el docente indique que **todos los equipos consultan a la vez**, repitan exactamente igual:
```bash
$ ros2 run examen_nodos medir_latencia frases_docente.csv carga.csv --etiqueta carga
```
(Para aumentar la carga, los 4 integrantes pueden correrlo al mismo tiempo desde su terminal, cada uno con un archivo de salida distinto; reporten el de uno.)

## 14. Exactitud "pura" de LAYA (requisito 5)

La columna "LAYA" solo cuenta respuestas no degradadas. Para comparar las 50 frases completas, hagan una corrida extra en calma con `timeout_s:=10`:
```bash
# Terminal 1: Ctrl+C y relanzar con -p timeout_s:=10.0
$ ros2 run examen_nodos medir_latencia frases_docente.csv exactitud.csv --etiqueta exactitud
```

## 15. Tablas y figura para el informe

```bash
$ ros2 run examen_nodos resumen_p1 calma.csv carga.csv --figura latencia_p1.png > tablas_p1.md
$ cat tablas_p1.md
```
✅ Debe salir: tabla de latencia (calma y carga, mediana y P95, separando red y servidor), tabla de exactitud, y la lista de frases donde falla cada método (para la media página de comentario). La figura `latencia_p1.png` muestra la mediana descompuesta en cálculo vs red + cola.

## 16. Subir a GitHub

```bash
$ cd ~/ros2_ws
$ cp ~/p1_entrega/.gitignore .        # ignora build/, install/, log/, .env, claves
$ git add src/paquetes_parcial p1 .gitignore
$ git status        # REVISEN que no aparezca ninguna clave ni env_examen.sh
$ git commit -m "P1: servicio interpretar_orden, mediciones calma/carga"
$ git push
```

---

## Ensayo en casa sin el laboratorio (servidor LAYA simulado)

Incluí `laya_simulado`, que imita el contrato HTTP real (misma ruta, mismas cabeceras, 503 si se satura, y atiende **una inferencia a la vez** igual que el real). **No sirve como evidencia**, solo para ensayar.

```bash
# Terminal A
$ ros2 run examen_nodos laya_simulado --puerto 8000 --calculo-ms 40
# Terminal B
$ export LAYA_URL=http://127.0.0.1:8000 && ros2 run examen_nodos interprete_ordenes
# Terminal C
$ ros2 run examen_nodos medir_latencia ~/ros2_ws/p1/frases_ensayo.csv calma.csv --etiqueta calma
```
Para probar el respaldo: `ros2 run examen_nodos laya_simulado --puerto 8000 --caido`.

En mi prueba con el simulado: en calma, mediana ≈ 43 ms (cálculo 40 + red 3); con 6 clientes en paralelo, mediana ≈ 286 ms con el **mismo** cálculo (≈ 42 ms): todo el aumento es cola. Eso es lo que deberían ver en el laboratorio.

---

## Problemas frecuentes

| Síntoma | Causa | Solución |
|---|---|---|
| `Package 'examen_nodos' not found` | No hicieron `source` | `source ~/env_examen.sh` |
| `No encuentro /interpretar_orden` | Nodo apagado o distinto `ROS_DOMAIN_ID` | Revisar `echo $ROS_DOMAIN_ID` en ambas terminales |
| Todo sale `degradado=True` | `LAYA_URL` mal, firewall, o `timeout_s` muy bajo | Paso 4; subir `timeout_s` |
| `permitido` siempre `False` | Pregunta `noul` sin `criteria` (código viejo) | Usar este código (ya trae `criteria`) |
| `401` | El servidor tiene clave | `export LAYA_API_KEY=...` |
| `503 server busy` | Servidor saturado (>16 peticiones) | Es normal bajo carga: el nodo responde degradado |
| `422` | Pregunta mal formada | No cambien `type`; en `score` la lista va de menos a más urgente |
| `ModuleNotFoundError: requests` | Falta paquete | `sudo apt install python3-requests` |

---

## Textos base para el informe (adapten con sus números)

**Por qué la salida debe ser una decisión tipada (req. 1).** El brazo solo puede ejecutar un conjunto cerrado de acciones sobre objetos conocidos. Si el modelo redactara texto, habría que interpretar ese texto con otro paso frágil; podría inventar un objeto o una acción que no existe, o devolver un formato inesperado que rompa el nodo. Con `choice`, `score` y `noul` la respuesta siempre pertenece a un conjunto finito que el código valida, el tiempo de cálculo es acotado (no hay generación token a token: `output_tokens = 0`) y cada respuesta trae una probabilidad que permite decidir cuándo desconfiar. En robótica eso significa comportamiento verificable, latencia predecible y que ninguna salida del modelo se convierte directamente en un movimiento no previsto.

**Calma vs carga (req. 4).** El servidor LAYA procesa una inferencia a la vez (en `serve.py` las peticiones pasan por un candado `gate`) y rechaza con 503 cuando hay más de 16 peticiones admitidas. Por eso, bajo carga, el tiempo de cálculo que informa el servidor (`X-Inference-Time-Ms`) casi no cambia, pero el RTT crece: la diferencia RTT − cálculo incluye la red **y el tiempo esperando turno en el servidor**. Con N equipos consultando, la espera crece aproximadamente con N × tiempo de cálculo. Si el RTT supera `timeout_s`, el nodo responde degradado: el sistema sigue operando, pero con la exactitud del clasificador por palabras clave.

**Qué frases falla cada método.** Palabras clave: sinónimos no listados ("necesito", "quiero que levantes"), negaciones ("no agarres nada"), frases donde aparecen dos objetos o el verbo no está en la lista, y urgencia expresada sin las palabras exactas ("lo antes posible"). LAYA: (completar con la lista que da `resumen_p1`) — típicamente urgencia (el `score` es el tipo de pregunta más débil y el modelo multilingüe casi nunca elige el primer nivel) y órdenes peligrosas formuladas con verbos neutros.
