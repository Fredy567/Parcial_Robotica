# Pregunta 2: agarre autónomo bajo la cola del broker (guía paso a paso)

> Todo se ejecuta en la **terminal de la Jetson** (JupyterLab `http://172.51.1.18:8888` → Terminal).
> Hagan los pasos **en orden**. Cada uno tiene un "✅ Debe salir".

## 0. Cómo queda el sistema

```
integrante 1..4: enviar_orden ──frase──► interprete_ordenes ──HTTP──► LAYA (PC docente)
        │  (decisión: acción, color, PRIORIDAD, permitido)
        ▼
  broker (TU broker del RB-2) ── admisión: ¿permitido? ¿está en la mesa? → si no, RECHAZA con causa
        │  misma cola · misma política "prioridad" · mismo worker
        ▼  (al desencolar, el WORKER hace todo esto)
  1. percepción   → localizador_objetos (cámara)    /localizar_objeto
  2. IK           → arm_broker/ik.py (FK del RB-2)
  3. planificación → MoveIt2 move_group              /plan_kinematic_path  (solo planifica)
  4. movimiento   → el worker publica /joint_states y /arm/pinza
        ▼
  driver_jetcobot (puerto serie) → JetCobot
```

**Regla del publicador único:** solo el broker publica `/joint_states` y `/arm/pinza`. Los demás nodos solo miran (cámara), calculan (IK) o planifican (MoveIt). **Nunca** corran a la vez los ejemplos de Yahboom (`jetcobot_grasp`, notebooks), porque mueven el brazo directamente.

### Dos correcciones que encontré en su código (explíquenlas en el informe)
1. **La tabla DH del RB-2 estaba en la convención equivocada.** La función `_t` del kit usa DH *modificada* (Craig), pero la tabla estaba escrita en DH *estándar*. Con el brazo recto hacia arriba (q = 0), la FK daba z = −29 mm (debajo de la base). Corregida da (45.6, −63.4, 412.7) mm, que es lo esperado para el MyCobot 280. La tabla original se conserva en `fk.py` como `DH_RB2_ORIGINAL`. **Paso 4: se verifica contra el robot.**
2. **El amarillo de `HSV_config.txt` tiene el tono máximo en 255.** Así atrapa todos los colores. El localizador lo detecta y usa el rango de fábrica.

---

## 1. Subir e instalar el código

Suban `p2_entrega.zip` a la Jetson con el botón ⬆ de JupyterLab (a `/home/jetson`). Luego:

```bash
cd ~ && unzip -o p2_entrega.zip -d p2_entrega
cp -r ~/examen_ws/src ~/respaldo_src_p1          # respaldo por si acaso
rsync -a --exclude 'laya_cliente.py' ~/p2_entrega/src/ ~/examen_ws/src/
mkdir -p ~/examen_ws/p2 && cp ~/p2_entrega/p2/* ~/examen_ws/p2/
ls ~/examen_ws/src
```
✅ Debe salir: `arm_broker  arm_broker_interfaces  paquetes_parcial`

(Se excluye `laya_cliente.py` para no perder los objetos y colores que editaron en la Pregunta 1. Si no tienen `rsync`, usen `cp -r ~/p2_entrega/src/* ~/examen_ws/src/` y vuelvan a editar `laya_cliente.py`).

## 2. Actualizar el archivo de entorno (ahora también carga MoveIt)

```bash
cat > ~/env_examen.sh <<'EOF'
source /opt/ros/humble/setup.bash
source ~/jetcobot_colcon_ws/install/setup.bash
source ~/examen_ws/install/setup.bash
export ROS_DOMAIN_ID=72
export LAYA_URL=http://IP_DOCENTE:PUERTO
EOF
```
(Si ya tienen la IP de LAYA, pónganla. Para ensayar sin LAYA real usen `http://127.0.0.1:8000` con `laya_simulado`).

## 3. Compilar

```bash
cd ~/examen_ws
source /opt/ros/humble/setup.bash
source ~/jetcobot_colcon_ws/install/setup.bash
colcon build --symlink-install
source ~/env_examen.sh
ros2 pkg prefix arm_broker
ros2 interface show arm_broker_interfaces/action/RecogerObjeto | head -5
```
✅ Debe salir: `Summary: 4 packages finished` y `/home/jetson/examen_ws/install/arm_broker` (no `rb2_ws`).

## 4. Verificar la tabla DH contra el robot (evidencia del cambio)

Primero liberen el puerto serie: **nada** puede estar usando el brazo.
```bash
pgrep -af "sync_plan|grasp|driver_jetcobot" || echo "puerto libre"
# si aparece algo:  pkill -f sync_plan_nx   (o el nombre que salga)
ros2 run arm_broker verificar_dh
```
El brazo irá a 4 poses. **Despejen la mesa alrededor.**
✅ Debe salir: un resumen con `corregida  error medio ...` **≤ 10 mm** y `RB-2 original` con un error mucho mayor. Guarden la salida (`... | tee verificacion_dh.txt`).

> Si la tabla corregida diera más de 10 mm, avísenme con la salida completa antes de seguir.

## 5. Arreglar los límites de MoveIt2 (una sola vez)

Su `joint_limits.yaml` tiene `has_velocity_limits: false` y la URDF `velocity="0"`. Con eso MoveIt no puede asignar tiempos a la trayectoria y el plan falla.
```bash
cp ~/jetcobot_colcon_ws/src/jetcobot_moveit/config/joint_limits.yaml ~/joint_limits_ORIGINAL.yaml
cp ~/p2_entrega/moveit_fix/joint_limits.yaml ~/jetcobot_colcon_ws/src/jetcobot_moveit/config/
cd ~/jetcobot_colcon_ws && colcon build --packages-select jetcobot_moveit
```
✅ Debe salir: `Summary: 1 package finished`

## 6. Calibrar la mesa (antes de cada sesión o si mueven algo)

Coloquen los 4 cubos **en sus posiciones conocidas** y definan la zona de depósito.
```bash
source ~/env_examen.sh
ros2 run examen_nodos calibrar_mesa
```
El programa les pide, en orden: **pose de cámara**, **cubo rojo, verde, azul, amarillo** y **zona de depósito**. En cada uno:
1. **Sujeten el brazo con la mano** → ENTER (se liberan los motores; el brazo cae si no lo sostienen).
2. Llévenlo a mano a la posición → ENTER (guarda y vuelve a dar torque).
   - **Pose de cámara:** brazo arriba, cámara mirando la mesa y viendo **los 4 cubos**. Es también la pose de reposo.
   - **Cada cubo:** pinza **abierta y vertical** rodeando el cubo, a la altura en que lo agarraría.
   - **Zona:** pinza donde debe **soltar** el cubo.
3. Al final el brazo va a la pose de cámara, toma una foto y calcula la homografía.

✅ Debe salir: los 4 colores `pixel (...) -> mesa (...) mm`, `Homografia calculada` y `Configuracion guardada en /home/jetson/examen_ws/p2/mesa.yaml`.
Abran `examen_ws/p2/calibracion_camara.jpg` en JupyterLab: debe haber un punto rojo sobre cada cubo.

- Si un color **no se detecta**: más luz, o recalibren el HSV con la herramienta de Yahboom y luego `calibrar_mesa --solo-camara`.
- Si los cubos están en línea recta, no hay homografía. Funciona igual (elige el lugar más cercano), pero entonces la cámara no localiza fuera de esos lugares.

## 7. Escribir las predicciones (se califica)

Completen `~/examen_ws/p2/predicciones_p2.md` y hagan commit **antes** de medir.

## 8. Levantar todo el sistema (Terminal 1, déjenla abierta)

```bash
source ~/env_examen.sh
ros2 launch examen_nodos sistema_p2.launch.py timeout_s:=1.5 politica:=prioridad
```
✅ Deben aparecer, entre muchas líneas:
- `driver_jetcobot listo`
- `localizador listo · camara OK · modo homografia`
- `interprete_ordenes listo`
- `arm_broker listo · política=prioridad`
- `You can start planning now!` (MoveIt2 listo)

Si MoveIt da problemas, pueden lanzar sin él (`moveit:=false`) para avanzar, pero **el examen pide MoveIt2**: arréglenlo antes de la demo.

## 9. Primera prueba con una sola orden (Terminal 2)

**Tengan una mano cerca del interruptor del brazo.** Ctrl+C en la Terminal 1 lo detiene todo.
```bash
source ~/env_examen.sh
ros2 run examen_nodos enviar_orden --id prueba --frase "agarra el cubo rojo"
```
✅ Debe salir:
```
  decision (xx ms): accion=agarrar objeto=cubo color=rojo prioridad=2 permitido=True
  ✓ aceptada y encolada
    · PERCEPCION ... · IK ... · PLANIFICANDO_Y_MOVIENDO ... · AGARRANDO ... · SOLTANDO ... · VOLVIENDO
  ✓ HECHO: ok (homografia+lugar_rojo) | espera en cola 0.0 s | percepcion ... | plan ... [moveit] | error x.x mm
```
- Si dice `[interpolacion]` en vez de `[moveit]`, miren en la Terminal 1 la línea `planificacion MoveIt fallo (...)` y pásenme el motivo.
- Si el cubo queda **mal agarrado**, corrijan esa posición repitiendo el paso 6.

## 10. Probar los rechazos (requisito 3)

```bash
ros2 run examen_nodos enviar_orden --id prueba --frase "lanza el cubo rojo contra la pared"
ros2 run examen_nodos enviar_orden --id prueba --frase "agarra la botella negra"
```
✅ Debe salir `✗ RECHAZADA antes de encolar: orden NO PERMITIDA por el modelo` y `... no está sobre la mesa`. **El brazo no se mueve.**

## 11. Demostración con los 4 integrantes a la vez + evidencia

**Terminal 3: grabar el bag (empezar ANTES de las órdenes)**
```bash
source ~/env_examen.sh && cd ~/examen_ws/p2
ros2 bag record -o demo_p2 /arm/queue_state /joint_states /arm/pinza /arm/rechazos /arm/angulos_medidos /rosout
```
**Terminal 4: ver la cola (para el video)**
```bash
source ~/env_examen.sh && ros2 topic echo /arm/queue_state
```
**Prueba del publicador único (para el video)**
```bash
ros2 topic info /joint_states -v | grep -A2 "Publisher count"
ros2 topic info /arm/pinza -v | grep -A2 "Publisher count"
```
✅ Debe salir `Publisher count: 1` y `Node name: arm_broker` en los dos.

**Cada integrante** abre `http://172.51.1.18:8888` desde **su propia laptop** → Terminal, y corre su cliente:
```bash
source ~/env_examen.sh
ros2 run examen_nodos enviar_orden --id <su_nombre>
orden> urgente, trae el cubo azul
```
Cuenten "3, 2, 1" y envíen al mismo tiempo. En `/arm/queue_state` se verá la cola ordenada por la prioridad que dio el modelo.

## 12. Los 10 intentos y la tabla

Hagan 10 órdenes de agarre (pueden repetir colores; reacomoden los cubos en sus lugares entre intentos). Todo queda en `~/examen_ws/p2/intentos.csv`.
1. Abran `intentos.csv` en JupyterLab y llenen la columna **`exito_visual`** con `si` o `no` según el video (el broker no puede ver si el cubo quedó en la zona).
2. Generen la tabla:
```bash
ros2 run examen_nodos resumen_p2 ~/examen_ws/p2/intentos.csv > ~/examen_ws/p2/tabla_p2.md
cat ~/examen_ws/p2/tabla_p2.md
```
✅ Debe salir: la tabla de intentos (objetivo, alcanzado por la FK del RB-2, error en mm), la **tasa de éxito** y la lista de órdenes rechazadas con su causa.

## 13. Subir a GitHub

```bash
cd ~/examen_ws
git add src p2/*.md p2/*.csv p2/mesa.yaml p2/calibracion_camara.jpg
git commit -m "P2: recoger_objeto en el broker, percepcion, IK, MoveIt2"
git push
```
El bag (`demo_p2/`) puede ser grande: súbanlo al aula virtual o a Drive y pongan el enlace en el README.

---

## Qué hace cada pieza (para el informe)

| Pieza | Archivo | Requisito |
|---|---|---|
| Prioridad desde el modelo | `enviar_orden.py` copia `decision.prioridad` a `goal.priority` | 1 |
| Solo el worker comanda | `broker.py` es el único con publishers de `/joint_states` y `/arm/pinza` | 2 |
| Rechazo antes de encolar con causa | `broker.goal_callback_recoger` + `/arm/rechazos` | 3 |
| Tasa de éxito | `intentos.csv` + `resumen_p2` | 4 |
| Error con la FK del RB-2 | `recoger.py`: FK(ángulos **medidos**) vs posición pedida | 5 |
| Percepción | `localizador_objetos.py` (homografía pixel → mm) | cadena |
| IK | `arm_broker/ik.py` (Levenberg-Marquardt sobre la FK del RB-2) | cadena |
| MoveIt2 | `recoger.Planificador` → `/plan_kinematic_path` (solo planifica) | cadena |

## Problemas frecuentes

| Síntoma | Causa | Solución |
|---|---|---|
| `could not open port /dev/ttyUSB0` | Otro programa usa el brazo | `pgrep -af "sync_plan\|grasp"` y ciérrenlo |
| `camara NO SE PUDO ABRIR` | Otro programa usa la cámara | Cierren notebooks de Yahboom; `fuser /dev/video0` |
| Todo rechazado con `falta calibrar la mesa` | No existe `mesa.yaml` | Paso 6 |
| `no se ve ningun objeto <color>` | Luz/HSV o el cubo no está | Revisen `examen_ws/p2/capturas/` (foto de cada intento) |
| `IK sin solucion` | Posición fuera de alcance | Acerquen el cubo; recalibren (paso 6) |
| `[interpolacion]` en vez de `[moveit]` | move_group no responde o falla el plan | Paso 5; motivo en Terminal 1 |
| El brazo llega pero no agarra | Altura de agarre o pinza | Recalibren el cubo; en `mesa.yaml` ajusten `pinza: cerrada` (20 → 10) |
| Nodos que no se ven entre sí | Discovery Server del `~/.bashrc` | `unset ROS_DISCOVERY_SERVER FASTRTPS_DEFAULT_PROFILES_FILE` y `ros2 daemon stop` |
