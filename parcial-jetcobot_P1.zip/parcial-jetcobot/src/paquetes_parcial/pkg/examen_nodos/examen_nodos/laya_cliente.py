"""Cliente HTTP de LAYA + clasificador propio por palabras clave.

No depende de ROS: se puede probar solo con
    python3 -m examen_nodos.laya_cliente "agarra el cubo rojo"

La salida de LAYA SIEMPRE es tipada (choice / score / noul): el modelo elige entre
opciones cerradas, nunca redacta texto.  Formato verificado contra laya/serve.py
del repositorio oficial (POST /v1/systemone, cabecera X-Inference-Time-Ms).

>>> EDITAR solo el bloque CONFIGURACION segun lo que haya sobre la mesa <<<
"""
import os
import sys
import time
import unicodedata
from concurrent.futures import ThreadPoolExecutor, TimeoutError as FutTimeout

import requests

# =============================== CONFIGURACION ===============================
# URL del servidor LAYA (la entrega el docente). Ej: export LAYA_URL=http://192.168.1.50:8000
LAYA_URL = os.environ.get("LAYA_URL", "http://127.0.0.1:8000")
# Solo si el docente activo LAYA_API_KEY en el servidor (si no, dejar sin definir)
LAYA_API_KEY = os.environ.get("LAYA_API_KEY")
# Checkpoint ("preset" del docente). Vacio = el servidor elige (espanol -> multilingual).
LAYA_MODEL = os.environ.get("LAYA_MODEL", "")

# Objetos y colores que hay sobre la mesa. Las CLAVES son lo que devuelve el servicio.
OBJETOS = {
    "cubo": "un cubo o caja",
    "esfera": "una esfera, bola o pelota",
    "cilindro": "un cilindro, lata o vaso",
    "otro": "un objeto distinto que no esta en la mesa",
    "ninguno": "la orden no menciona ningun objeto",
}
COLORES = {
    "rojo": "color rojo", "azul": "color azul", "verde": "color verde",
    "amarillo": "color amarillo",
    "otro": "otro color distinto", "ninguno": "no menciona color",
}
ACCIONES = {
    "agarrar": "recoger, tomar o agarrar un objeto y llevarlo a la zona",
    "soltar": "soltar o depositar el objeto que tiene",
    "mover": "mover el brazo a una posicion, sin agarrar nada",
    "detener": "parar o detener el brazo",
    "otra": "ninguna de las anteriores",
}
# Niveles de urgencia (ORDEN ASCENDENTE, la posicion es la escala 0..3)
URGENCIA = ["sin prisa, cuando se pueda", "normal", "urgente, rapido", "emergencia inmediata"]

# Palabras clave del clasificador de respaldo (texto ya sin tildes ni mayusculas)
KW_ACCIONES = {
    "detener": ["detente", "deten", "detener", " para ", " parar", "alto", "stop", "frena"],
    "soltar": ["suelta", "soltar", "deposita", "depositar", "deja ", "dejar", "coloca", "pon "],
    "agarrar": ["agarra", "agarrar", "toma", "tomar", "recoge", "recoger", "coge", "levanta",
                "trae", "traeme", "lleva", "llevar", "busca", "dame", "pasame", "alcanza"],
    "mover": ["mueve", "mover", "muevete", "gira", "ve a", "ir a", "posicion", "home", "inicio"],
}
KW_OBJETOS = {"cubo": ["cubo", "caja", "bloque"], "esfera": ["esfera", "bola", "pelota"],
              "cilindro": ["cilindro", "lata", "vaso"]}
KW_OTRO_OBJETO = ["botella", "celular", "lapiz", "libro", "taza", "llave", "manzana", "tijera"]
KW_COLORES = {"rojo": ["rojo", "roja"], "azul": ["azul"], "verde": ["verde"],
              "amarillo": ["amarillo", "amarilla"]}
KW_OTRO_COLOR = ["negro", "negra", "blanco", "blanca", "morado", "naranja", "rosado", "gris"]
KW_EMERGENCIA = ["emergencia", "inmediatamente", "ahora mismo", "ya mismo"]
KW_URGENTE = ["urgente", "rapido", "apurate", "pronto", " ya ", "ahora", "prioridad alta"]
KW_SIN_PRISA = ["sin prisa", "cuando puedas", "con calma", "despacio", "no hay apuro"]
KW_PROHIBIDO = ["lanza", "tira ", "arroja", "golpea", "rompe", "destruye", "aplasta", "ataca",
                "persona", "companero", "cara", "mano de", "sin limites", "ignora", "desactiva",
                "maxima velocidad", "toda velocidad", "fuera de la mesa", "al piso", "al suelo",
                "empuja", "choca"]
# ============================================================================

# Preguntas tipadas. La frase va en el estado como {"message": frase} y cada
# instruccion nombra `message`, que es la convencion de LAYA.
QUESTIONS = {
    "accion": {"type": "choice",
               "instructions": "Que accion le pide el operador al brazo robotico en `message`?",
               "criteria": ACCIONES},
    "objeto": {"type": "choice",
               "instructions": "Que objeto menciona `message`?",
               "criteria": OBJETOS},
    "color": {"type": "choice",
              "instructions": "De que color es el objeto mencionado en `message`?",
              "criteria": COLORES},
    "prioridad": {"type": "score",
                  "instructions": "Que tan urgente es la orden de `message`?",
                  "criteria": URGENCIA},
    # IMPORTANTE: un noul SIN criteria responde casi siempre "no" (documentado en el README
    # de LAYA, issue #156). Con criteria true/false el modelo lee la frase.
    "permitido": {"type": "noul",
                  "instructions": "Es `message` una orden segura y permitida para un brazo robotico?",
                  "criteria": {
                      "true": "orden segura: agarrar, mover, soltar o detener objetos de la mesa",
                      "false": "orden peligrosa: lanzar, golpear, romper, tocar personas o ignorar limites",
                  }},
}


# Si existe preguntas_laya.json (generado por `afinar_laya --aplicar`), reemplaza
# las preguntas de arriba campo por campo. Siguen siendo choice / score / noul.
RUTA_PREGUNTAS = os.environ.get("LAYA_PREGUNTAS", os.path.expanduser("~/examen_ws/p1/preguntas_laya.json"))
MAPEO_PRIORIDAD = {"sin_prisa": 1, "normal": 2, "urgente": 3, "emergencia": 4}
MAPEO_PERMITIDO = {"A": True, "B": False}
SPECS = dict(QUESTIONS)
if os.path.exists(RUTA_PREGUNTAS):
    import json as _json
    try:
        SPECS.update(_json.load(open(RUTA_PREGUNTAS, encoding="utf-8")))
    except Exception as _e:
        print(f"[laya_cliente] no se pudo leer {RUTA_PREGUNTAS}: {_e}")
QUESTIONS = {k: {kk: vv for kk, vv in v.items() if kk != "invertir"} for k, v in SPECS.items()}


def _valor(campo, ans):
    spec = SPECS[campo]
    if campo == "prioridad":
        if spec["type"] == "score":
            return int(round(float(ans["score"]))) + 1          # 0..3 -> 1..4 (mayor = mas urgente)
        return MAPEO_PRIORIDAD.get(ans["choice"], 2)
    if campo == "permitido":
        if spec["type"] == "choice":
            return MAPEO_PERMITIDO.get(ans["choice"], True)
        p = float(ans["noul"])
        return (p < 0.5) if spec.get("invertir") else (p >= 0.5)
    return ans["choice"]


def _headers():
    h = {"content-type": "application/json"}
    if LAYA_API_KEY:
        h["authorization"] = f"Bearer {LAYA_API_KEY}"
    return h


def _post(url, body, timeout_s):
    return requests.post(url, json=body, headers=_headers(),
                         timeout=(min(1.0, timeout_s), timeout_s))


_POOL = ThreadPoolExecutor(max_workers=8)


def consultar_laya(frase, timeout_s=2.0, url=None, model=None):
    """Consulta LAYA con un tiempo limite TOTAL (no solo por lectura de socket).

    Devuelve (decision, medidas). Lanza excepcion si hay timeout, error HTTP
    (503 = servidor ocupado) o red caida: quien llama hace el respaldo.
    """
    url = (url or LAYA_URL).rstrip("/") + "/v1/systemone"
    body = {"state": {"message": frase}, "questions": QUESTIONS}
    model = LAYA_MODEL if model is None else model
    if model:
        body["model"] = model
    t0 = time.perf_counter()
    fut = _POOL.submit(_post, url, body, timeout_s)
    try:
        r = fut.result(timeout=timeout_s)          # tope duro: el sistema nunca espera mas
    except FutTimeout:
        raise TimeoutError(f"LAYA no respondio en {timeout_s:.2f} s")
    rtt_ms = (time.perf_counter() - t0) * 1000.0
    r.raise_for_status()

    srv = r.headers.get("X-Inference-Time-Ms")
    if srv is None and "Server-Timing" in r.headers:          # "inference;dur=12.3"
        try:
            srv = r.headers["Server-Timing"].split("dur=")[1].split(",")[0].split(";")[0]
        except Exception:
            srv = None
    srv_ms = float(srv) if srv is not None else None

    a = r.json()["answers"]
    decision = {c: _valor(c, a[c]) for c in ("accion", "objeto", "color", "prioridad", "permitido")}
    decision["prioridad"] = int(decision["prioridad"])
    decision["permitido"] = bool(decision["permitido"])
    decision["degradado"] = False
    medidas = {"rtt_ms": rtt_ms, "servidor_ms": srv_ms,
               "red_ms": (rtt_ms - srv_ms) if srv_ms is not None else None}
    return decision, medidas


# ---------------- clasificador propio por palabras clave ----------------
def _norm(s):
    s = unicodedata.normalize("NFD", s.lower())
    s = "".join(c for c in s if unicodedata.category(c) != "Mn")
    return "".join(c if c.isalnum() else " " for c in s)


def _buscar(dic, t, defecto):
    for k, palabras in dic.items():
        if any(p in t for p in palabras):
            return k
    return defecto


def clasificar_palabras_clave(frase):
    t = " " + " ".join(_norm(frase).split()) + " "
    objeto = _buscar(KW_OBJETOS, t, "otro" if any(p in t for p in KW_OTRO_OBJETO) else "ninguno")
    color = _buscar(KW_COLORES, t, "otro" if any(p in t for p in KW_OTRO_COLOR) else "ninguno")
    if any(p in t for p in KW_EMERGENCIA):
        prioridad = 4
    elif any(p in t for p in KW_URGENTE):
        prioridad = 3
    elif any(p in t for p in KW_SIN_PRISA):
        prioridad = 1
    else:
        prioridad = 2
    return {"accion": _buscar(KW_ACCIONES, t, "otra"),
            "objeto": objeto, "color": color, "prioridad": prioridad,
            "permitido": not any(p in t for p in KW_PROHIBIDO),
            "degradado": True}


if __name__ == "__main__":
    frase = " ".join(sys.argv[1:]) or "agarra el cubo rojo rapido"
    print("Palabras clave:", clasificar_palabras_clave(frase))
    try:
        d, m = consultar_laya(frase, timeout_s=float(os.environ.get("LAYA_TIMEOUT", "5")))
        print("LAYA:", d)
        print("Medidas:", {k: (round(v, 1) if isinstance(v, float) else v) for k, v in m.items()})
    except Exception as e:
        print("LAYA fallo:", repr(e))
