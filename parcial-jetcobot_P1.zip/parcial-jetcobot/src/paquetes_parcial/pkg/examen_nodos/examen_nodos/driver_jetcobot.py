#!/usr/bin/env python3
"""driver_jetcobot = sync_plan_nx de jetcobot_driver + pinza + angulos medidos.

Es el UNICO proceso que abre el puerto serie. NO decide nada: solo obedece lo que
publica el worker del broker:
  /joint_states  (sensor_msgs/JointState)  -> mc.send_angles  (igual que sync_plan_nx)
  /arm/pinza     (std_msgs/Int32 0..100)   -> mc.set_gripper_value
y publica lo que mide el robot (no son comandos):
  /arm/angulos_medidos (sensor_msgs/JointState, rad)  -> para el error con la FK del RB-2

Reemplaza a sync_plan_nx: NO correr los dos a la vez (pelearian por el puerto).
"""
import math
import time

import rclpy
from rclpy.node import Node
from sensor_msgs.msg import JointState
from std_msgs.msg import Int32

try:
    from pymycobot.mycobot import MyCobot
except ImportError:
    from pymycobot import MyCobot

JOINTS = ['1_Joint', '2_Joint', '3_Joint', '4_Joint', '5_Joint', '6_Joint']


class Driver(Node):
    def __init__(self):
        super().__init__("driver_jetcobot")
        self.declare_parameter('port', '/dev/ttyUSB0')
        self.declare_parameter('baud', 1000000)
        self.declare_parameter('min_period_s', 0.05)
        self.declare_parameter('min_delta_deg', 0.5)
        self.declare_parameter('speed', 50)
        self.declare_parameter('speed_pinza', 50)
        self.declare_parameter('hz_medicion', 4.0)
        g = lambda k: self.get_parameter(k).value
        self.mc = MyCobot(g('port'), g('baud'))
        time.sleep(0.05)
        try:
            if self.mc.get_fresh_mode() == 0:
                self.mc.set_fresh_mode(1)
                time.sleep(0.05)
        except Exception as e:
            self.get_logger().warn(f"fresh_mode: {e}")
        self.min_period_s, self.min_delta_deg = g('min_period_s'), g('min_delta_deg')
        self.speed, self.speed_pinza = int(g('speed')), int(g('speed_pinza'))
        self.last_send_time, self.last_sent, self.ultima_pinza = 0.0, None, None

        self.create_subscription(JointState, 'joint_states', self.cb_joints, 10)
        self.create_subscription(Int32, '/arm/pinza', self.cb_pinza, 10)
        self.pub_med = self.create_publisher(JointState, '/arm/angulos_medidos', 10)
        self.create_timer(1.0 / float(g('hz_medicion')), self.medir)
        self.get_logger().info("driver_jetcobot listo (joint_states + pinza + angulos medidos)")

    def cb_joints(self, msg):
        d = {n: msg.position[i] for i, n in enumerate(msg.name)}
        if not all(j in d for j in JOINTS):
            return
        data = [round(math.degrees(d[j]), 3) for j in JOINTS]
        now = time.monotonic()
        if now - self.last_send_time < self.min_period_s:
            return
        if self.last_sent is not None and max(abs(a - b) for a, b in zip(data, self.last_sent)) < self.min_delta_deg:
            return
        self.mc.send_angles(data, self.speed)
        self.last_send_time, self.last_sent = now, data

    def cb_pinza(self, msg):
        v = max(0, min(100, int(msg.data)))
        self.mc.set_gripper_value(v, self.speed_pinza)
        self.ultima_pinza = v
        self.get_logger().info(f"pinza -> {v}")

    def medir(self):
        try:
            a = self.mc.get_angles()
        except Exception:
            return
        if isinstance(a, list) and len(a) == 6:
            m = JointState()
            m.header.stamp = self.get_clock().now().to_msg()
            m.name = JOINTS
            m.position = [math.radians(v) for v in a]
            self.pub_med.publish(m)


def main():
    rclpy.init()
    n = Driver()
    try:
        rclpy.spin(n)
    except KeyboardInterrupt:
        pass
    finally:
        n.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
