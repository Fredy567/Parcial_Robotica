#!/usr/bin/env python3
"""Cliente de ordenes en lenguaje natural (cada integrante corre el suyo).

  frase --> /interpretar_orden (Pregunta 1) --> decision tipada
        --> accion recoger_objeto del broker con la PRIORIDAD QUE DIO EL MODELO
            (el cliente no la escribe a mano)

Uso:
  ros2 run examen_nodos enviar_orden --id ana                          # modo interactivo
  ros2 run examen_nodos enviar_orden --id ana --frase "agarra el cubo rojo"
  ros2 run examen_nodos enviar_orden --id ana --no-esperar             # no espera a que termine

Deja un registro en ~/examen_ws/p2/ordenes_<id>.csv (para la Pregunta 3).
"""
import argparse
import csv
import json
import os
import sys
import threading
import time

import rclpy
from rclpy.action import ActionClient
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node
from std_msgs.msg import String

from arm_broker_interfaces.action import RecogerObjeto
from interfaces_examen.srv import InterpretarOrden


class Cliente(Node):
    def __init__(self, cid):
        super().__init__(f"cliente_orden_{cid}".replace("-", "_"))
        self.cid = cid
        self.srv = self.create_client(InterpretarOrden, "/interpretar_orden")
        self.act = ActionClient(self, RecogerObjeto, "recoger_objeto")
        self.rechazos = []
        self.create_subscription(String, "/arm/rechazos", self._cb_rechazo, 10)
        self.ruta = os.path.expanduser(f"~/examen_ws/p2/ordenes_{cid}.csv")
        os.makedirs(os.path.dirname(self.ruta), exist_ok=True)

    def _cb_rechazo(self, msg):
        try:
            d = json.loads(msg.data)
        except Exception:
            return
        if d.get("client_id") == self.cid:
            self.rechazos.append(d)

    def _esperar(self, fut, timeout):
        fin = time.time() + timeout
        while not fut.done() and time.time() < fin:
            time.sleep(0.01)
        return fut.result() if fut.done() else None

    def registrar(self, fila):
        nuevo = not os.path.exists(self.ruta)
        with open(self.ruta, "a", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=list(fila))
            if nuevo:
                w.writeheader()
            w.writerow(fila)

    def enviar(self, frase, esperar=True):
        t_frase = time.time()
        if not self.srv.wait_for_service(timeout_sec=5.0):
            print("  !! /interpretar_orden no esta disponible (¿interprete_ordenes corriendo?)")
            return
        req = InterpretarOrden.Request()
        req.frase = frase
        t0 = time.perf_counter()
        d = self._esperar(self.srv.call_async(req), 10.0)
        decision_ms = (time.perf_counter() - t0) * 1000
        if d is None:
            print("  !! el interprete no respondio")
            return
        print(f"  decision ({decision_ms:.0f} ms{' DEGRADADA' if d.degradado else ''}): accion={d.accion} "
              f"objeto={d.objeto} color={d.color} prioridad={d.prioridad} permitido={d.permitido}")

        if not self.act.wait_for_server(timeout_sec=5.0):
            print("  !! el broker (recoger_objeto) no esta disponible")
            return
        g = RecogerObjeto.Goal()
        g.client_id, g.frase = self.cid, frase
        g.accion, g.objeto, g.color = d.accion, d.objeto, d.color
        g.priority = max(0, min(255, int(d.prioridad)))       # viene del modelo
        g.permitido, g.degradado, g.decision_ms = d.permitido, d.degradado, decision_ms
        n_rech = len(self.rechazos)
        t_envio = time.time()
        h = self._esperar(self.act.send_goal_async(g, feedback_callback=self._fb), 10.0)
        fila = {"t_frase": f"{t_frase:.3f}", "t_envio_broker": f"{t_envio:.3f}", "frase": frase,
                "accion": d.accion, "objeto": d.objeto, "color": d.color, "prioridad": d.prioridad,
                "permitido": d.permitido, "degradado": d.degradado, "decision_ms": f"{decision_ms:.1f}",
                "aceptada": False, "causa_rechazo": "", "success": "", "mensaje": "",
                "espera_s": "", "t_inicio_movimiento": "", "error_mm": ""}
        if h is None or not h.accepted:
            time.sleep(0.5)
            causa = self.rechazos[-1]["causa"] if len(self.rechazos) > n_rech else "rechazada por el broker"
            print(f"  ✗ RECHAZADA antes de encolar: {causa}")
            fila["causa_rechazo"] = causa
            self.registrar(fila)
            return
        fila["aceptada"] = True
        print("  ✓ aceptada y encolada")
        if not esperar:
            self.registrar(fila)
            return
        r = self._esperar(h.get_result_async(), 600.0)
        if r is None:
            print("  !! sin resultado")
            return
        r = r.result
        fila.update({"success": r.success, "mensaje": r.message, "espera_s": f"{r.wait_time_s:.2f}",
                     "t_inicio_movimiento": f"{r.t_inicio_movimiento:.3f}", "error_mm": f"{r.error_mm:.1f}"})
        self.registrar(fila)
        print(f"  {'✓ HECHO' if r.success else '✗ FALLO'}: {r.message} | espera en cola {r.wait_time_s:.1f} s | "
              f"percepcion {r.percepcion_ms:.0f} ms | IK {r.ik_ms:.0f} ms | plan {r.planificacion_ms:.0f} ms "
              f"[{r.planificador}] | error {r.error_mm:.1f} mm")

    def _fb(self, msg):
        f = msg.feedback
        txt = f"cola #{f.queue_position}" if f.state == "QUEUED" else f.state
        if getattr(self, "_ult", None) != txt:
            self._ult = txt
            print(f"    · {txt} ({f.elapsed_s:.1f} s)")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--id", required=True, help="nombre del integrante")
    ap.add_argument("--frase", default="")
    ap.add_argument("--no-esperar", action="store_true")
    a = ap.parse_args(rclpy.utilities.remove_ros_args(sys.argv)[1:])
    rclpy.init()
    n = Cliente(a.id)
    ex = MultiThreadedExecutor(num_threads=4)
    ex.add_node(n)
    threading.Thread(target=ex.spin, daemon=True).start()
    try:
        if a.frase:
            n.enviar(a.frase, not a.no_esperar)
        else:
            print(f"Cliente '{a.id}'. Escribe una orden y ENTER (Ctrl+C para salir).")
            while True:
                frase = input("orden> ").strip()
                if frase:
                    n.enviar(frase, not a.no_esperar)
    except (KeyboardInterrupt, EOFError):
        pass
    finally:
        ex.shutdown()
        n.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
