#!/usr/bin/env python3
"""Arma las tablas de la Pregunta 1 a partir de los CSV de medir_latencia.

Uso:  ros2 run examen_nodos resumen_p1 calma.csv carga.csv --figura latencia_p1.png
Imprime en Markdown (para pegar en el informe/README):
  - tabla de latencia en calma y bajo carga (mediana y P95), separando red y servidor
  - tabla comparativa de exactitud LAYA vs palabras clave
  - lista de frases donde falla cada metodo
"""
import argparse
import csv
import statistics as st



def p95(x):
    x = sorted(x)
    if not x:
        return float("nan")
    k = 0.95 * (len(x) - 1)
    i = int(k)
    return x[i] if i + 1 >= len(x) else x[i] + (x[i + 1] - x[i]) * (k - i)


def leer(r):
    with open(r, encoding="utf-8") as fh:
        return list(csv.DictReader(fh))


def num(filas, col, solo_laya=False):
    v = []
    for f in filas:
        if solo_laya and f.get("degradado") == "True":
            continue
        try:
            x = float(f[col])
        except (KeyError, ValueError):
            continue
        if x >= 0:
            v.append(x)
    return v


def main_cli():
    ap = argparse.ArgumentParser()
    ap.add_argument("csvs", nargs="+", help="calma.csv carga.csv ...")
    ap.add_argument("--figura", default="")
    a = ap.parse_args()
    datos = {}
    for r in a.csvs:
        filas = leer(r)
        datos[filas[0].get("etiqueta", r) if filas else r] = filas

    print("## Latencia del servicio /interpretar_orden\n")
    print("| Escenario | Medida | Mediana (ms) | P95 (ms) | n |\n|---|---|---|---|---|")
    for et, filas in datos.items():
        deg = sum(f.get("degradado") == "True" for f in filas)
        for nom, col, sl in (("Servicio completo", "servicio_ms", False), ("RTT HTTP", "rtt_ms", True),
                             ("Calculo servidor", "servidor_ms", True), ("Red + cola", "red_ms", True)):
            v = num(filas, col, sl)
            if v:
                print(f"| {et} | {nom} | {st.median(v):.1f} | {p95(v):.1f} | {len(v)} |")
        print(f"| {et} | Respuestas degradadas | {deg}/{len(filas)} | | |")

    print("\n## Exactitud (frase correcta = todos los campos esperados coinciden)\n")
    print("| Escenario | LAYA (no degradadas) | Palabras clave | Servicio final |\n|---|---|---|---|")
    for et, filas in datos.items():
        def ex(col, filas=filas):
            v = [int(f[col]) for f in filas if f.get(col, "") != ""]
            return f"{sum(v)}/{len(v)} = {100 * sum(v) / len(v):.0f}%" if v else "-"
        print(f"| {et} | {ex('ok_laya')} | {ex('ok_kw')} | {ex('ok_servicio')} |")

    primero = next(iter(datos.values()))
    for col, nom in (("ok_laya", "LAYA"), ("ok_kw", "palabras clave")):
        fallos = [f["frase"] for f in primero if f.get(col) == "0"]
        print(f"\n### Frases donde falla {nom} ({len(fallos)})")
        for fr in fallos:
            print(f"- {fr}")

    if a.figura:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, ax = plt.subplots(1, 2, figsize=(11, 4.2))
        etq = list(datos)
        ax[0].boxplot([num(datos[e], "servicio_ms") for e in etq])
        ax[0].set_xticks(range(1, len(etq) + 1))
        ax[0].set_xticklabels(etq)
        ax[0].set_title("Tiempo del servicio /interpretar_orden")
        ax[0].set_ylabel("ms")
        ancho = 0.35
        for i, e in enumerate(etq):
            srv = st.median(num(datos[e], "servidor_ms", True) or [0])
            red = st.median(num(datos[e], "red_ms", True) or [0])
            ax[1].bar(i, srv, ancho * 2, label="calculo servidor" if i == 0 else None, color="#4C78A8")
            ax[1].bar(i, red, ancho * 2, bottom=srv, label="red + cola" if i == 0 else None, color="#F58518")
        ax[1].set_xticks(range(len(etq)))
        ax[1].set_xticklabels(etq)
        ax[1].set_title("Mediana del RTT descompuesta")
        ax[1].set_ylabel("ms")
        ax[1].legend()
        fig.tight_layout()
        fig.savefig(a.figura, dpi=150)
        print(f"\nFigura guardada en {a.figura}")


if __name__ == "__main__":
    main_cli()
