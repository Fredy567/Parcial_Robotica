#!/usr/bin/env python3
"""Nodo interprete_ordenes: servicio /interpretar_orden.

Es el UNICO nodo que habla con el servidor LAYA (HTTP). Recibe una frase y
devuelve una decision tipada. Si LAYA no responde dentro de `timeout_s`, resuelve
con el clasificador por palabras clave y marca degradado=True. Nunca se queda
esperando.

Parametros:
  timeout_s  (float)  tiempo limite total de la consulta a LAYA   [1.5]
  laya_url   (str)    URL del servidor; vacio = variable LAYA_URL [""]
  laya_model (str)    checkpoint/preset; vacio = variable LAYA_MODEL o auto [""]
  log_csv    (str)    si no esta vacio, registra cada peticion en ese CSV (evidencia) [""]
"""
import csv
import os
import threading
import time

import rclpy
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node

from interfaces_examen.srv import InterpretarOrden
from examen_nodos.laya_cliente import consultar_laya, clasificar_palabras_clave

CAMPOS_LOG = ["t_unix", "frase", "accion", "objeto", "color", "prioridad", "permitido",
              "degradado", "servicio_ms", "rtt_ms", "servidor_ms", "red_ms", "motivo"]


class InterpreteOrdenes(Node):
    def __init__(self):
        super().__init__("interprete_ordenes")
        self.declare_parameter("timeout_s", 1.5)
        self.declare_parameter("laya_url", "")
        self.declare_parameter("laya_model", "")
        self.declare_parameter("log_csv", "")
        self._lock = threading.Lock()
        # Reentrante + MultiThreadedExecutor: atiende a varios integrantes a la vez
        self.srv = self.create_service(InterpretarOrden, "/interpretar_orden", self.cb,
                                       callback_group=ReentrantCallbackGroup())
        ruta = self.get_parameter("log_csv").value
        self._log = None
        if ruta:
            nuevo = not os.path.exists(ruta)
            self._log_fh = open(ruta, "a", newline="", encoding="utf-8")
            self._log = csv.DictWriter(self._log_fh, fieldnames=CAMPOS_LOG)
            if nuevo:
                self._log.writeheader()
        self.get_logger().info(
            f"interprete_ordenes listo · timeout_s={self.get_parameter('timeout_s').value} · "
            f"laya_url={self.get_parameter('laya_url').value or os.environ.get('LAYA_URL', '(defecto)')}")

    def cb(self, req, res):
        t0 = time.perf_counter()
        t = float(self.get_parameter("timeout_s").value)
        url = self.get_parameter("laya_url").value or None
        model = self.get_parameter("laya_model").value or None
        motivo = ""
        try:
            d, m = consultar_laya(req.frase, timeout_s=t, url=url, model=model)
        except Exception as e:                      # timeout, 503 ocupado, red caida, etc.
            motivo = type(e).__name__ + ": " + str(e)[:120]
            self.get_logger().warn(f"LAYA no respondio ({motivo}) -> respaldo por palabras clave")
            d = clasificar_palabras_clave(req.frase)
            m = {"rtt_ms": None, "servidor_ms": None, "red_ms": None}

        res.accion, res.objeto, res.color = d["accion"], d["objeto"], d["color"]
        res.prioridad = int(d["prioridad"])
        res.permitido = bool(d["permitido"])
        res.degradado = bool(d["degradado"])
        res.rtt_ms = float(m["rtt_ms"]) if m["rtt_ms"] is not None else -1.0
        res.servidor_ms = float(m["servidor_ms"]) if m["servidor_ms"] is not None else -1.0
        servicio_ms = (time.perf_counter() - t0) * 1000.0

        self.get_logger().info(
            f"'{req.frase}' -> {res.accion}/{res.objeto}/{res.color} p={res.prioridad} "
            f"permitido={res.permitido} degradado={res.degradado} ({servicio_ms:.0f} ms)")
        if self._log:
            with self._lock:
                self._log.writerow({
                    "t_unix": f"{time.time():.3f}", "frase": req.frase, "accion": res.accion,
                    "objeto": res.objeto, "color": res.color, "prioridad": res.prioridad,
                    "permitido": res.permitido, "degradado": res.degradado,
                    "servicio_ms": f"{servicio_ms:.2f}", "rtt_ms": f"{res.rtt_ms:.2f}",
                    "servidor_ms": f"{res.servidor_ms:.2f}",
                    "red_ms": f"{m['red_ms']:.2f}" if m["red_ms"] is not None else "-1",
                    "motivo": motivo})
                self._log_fh.flush()
        return res


def main():
    rclpy.init()
    nodo = InterpreteOrdenes()
    ex = MultiThreadedExecutor(num_threads=8)
    ex.add_node(nodo)
    try:
        ex.spin()
    except KeyboardInterrupt:
        pass
    finally:
        nodo.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
