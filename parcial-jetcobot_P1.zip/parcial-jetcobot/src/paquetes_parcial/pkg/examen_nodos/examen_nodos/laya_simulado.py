#!/usr/bin/env python3
"""Servidor LAYA SIMULADO, solo para ensayar antes del examen (NO se usa en la evaluacion).

Imita el contrato HTTP real: POST /v1/systemone -> {"answers": {...}} con cabeceras
X-Inference-Time-Ms y Server-Timing, GET /health, y 503 cuando esta saturado.
Igual que el real, atiende UNA inferencia a la vez (cola interna): bajo carga la
latencia crece aunque el calculo cueste lo mismo.

Uso:  ros2 run examen_nodos laya_simulado --puerto 8000 --calculo-ms 40
      export LAYA_URL=http://127.0.0.1:8000
"""
import argparse
import json
import random
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from examen_nodos.laya_cliente import clasificar_palabras_clave

GATE = threading.Lock()
ADMISION = None
CFG = {}


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _json(self, code, obj, headers=None):
        b = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("content-type", "application/json")
        self.send_header("content-length", str(len(b)))
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(b)

    def _responder(self, state, questions):
        frase = state.get("message", "") if isinstance(state, dict) else str(state)
        d = clasificar_palabras_clave(frase)
        ans = {}
        for k, q in questions.items():
            campo = k.split("__")[0]
            if q["type"] == "choice":
                opciones = list(q["criteria"])
                v = d.get(campo)
                ans[k] = {"type": "choice", "choice": v if v in opciones else opciones[0]}
            elif q["type"] == "score":
                ans[k] = {"type": "score", "score": float(d.get("prioridad", 2) - 1)}
            else:
                ans[k] = {"type": "noul", "noul": 0.9 if d.get("permitido", True) else 0.1}
        return {"answers": ans}

    def do_GET(self):
        if self.path == "/health":
            self._json(200, {"status": "ok", "simulado": True})
        else:
            self._json(404, {"detail": "not found"})

    def do_POST(self):
        if self.path not in ("/v1/systemone", "/v1/systemone/batch"):
            return self._json(404, {"detail": "not found"})
        body = json.loads(self.rfile.read(int(self.headers.get("content-length", 0))) or b"{}")
        if self.path.endswith("/batch"):
            res = [self._responder(s, body["questions"]) for s in body.get("states", [])]
            return self._json(200, {"results": res})
        if "questions" not in body:
            return self._json(400, {"detail": "request body must be an object with a 'questions' field"})
        if not ADMISION.acquire(blocking=False):
            return self._json(503, {"detail": "server busy, try again later"}, {"Retry-After": "1"})
        try:
            if CFG["caido"]:
                time.sleep(3600)
            state = body.get("state")
            frase = state.get("message", "") if isinstance(state, dict) else str(state)
            with GATE:                                   # una inferencia a la vez
                t0 = time.perf_counter()
                time.sleep(max(0.0, random.gauss(CFG["calculo_ms"], CFG["calculo_ms"] * 0.15)) / 1000)
                d = clasificar_palabras_clave(frase)
                ms = (time.perf_counter() - t0) * 1000
            ans = self._responder(state, body["questions"])["answers"]
            self._json(200, {"model": "simulado", "answers": ans,
                             "usage": {"input_tokens": len(frase.split()), "output_tokens": 0}},
                       {"X-Inference-Time-Ms": f"{ms:.2f}", "Server-Timing": f"inference;dur={ms:.2f}"})
        finally:
            ADMISION.release()


def main():
    global ADMISION
    ap = argparse.ArgumentParser()
    ap.add_argument("--puerto", type=int, default=8000)
    ap.add_argument("--calculo-ms", type=float, default=40.0)
    ap.add_argument("--max-concurrentes", type=int, default=16)
    ap.add_argument("--caido", action="store_true", help="nunca responde (para probar el respaldo)")
    a, _ = ap.parse_known_args()
    CFG.update(calculo_ms=a.calculo_ms, caido=a.caido)
    ADMISION = threading.BoundedSemaphore(a.max_concurrentes)
    print(f"LAYA SIMULADO en http://0.0.0.0:{a.puerto}  calculo~{a.calculo_ms} ms  caido={a.caido}")
    ThreadingHTTPServer(("0.0.0.0", a.puerto), H).serve_forever()


if __name__ == "__main__":
    main()
