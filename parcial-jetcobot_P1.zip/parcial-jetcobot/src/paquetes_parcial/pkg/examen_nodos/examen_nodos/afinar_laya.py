#!/usr/bin/env python3
"""Prueba VARIAS formas de preguntarle lo mismo a LAYA y mide cual acierta mas.

Sigue siendo decision tipada (choice / score / noul): solo cambia como se describen
las opciones. No se entrena nada. Usa /v1/systemone/batch (50 frases en 1 llamada).

  ros2 run examen_nodos afinar_laya frases_ensayo.csv               # compara variantes
  ros2 run examen_nodos afinar_laya frases_ensayo.csv --aplicar     # guarda la mejor de cada campo

--aplicar escribe ~/examen_ws/p1/preguntas_laya.json, que laya_cliente usa automaticamente.
OJO: afinen con las frases de ENSAYO y midan la exactitud final con las del DOCENTE
(si se afina y se mide con las mismas frases, la exactitud sale inflada).
"""
import argparse
import csv
import json
import os
import sys
import time

import requests

from examen_nodos import laya_cliente as lc

RUTA_SALIDA = os.path.expanduser("~/examen_ws/p1/preguntas_laya.json")

ACC_RICA = {
    "agarrar": "agarrar, tomar, coger, recoger, levantar, traer, buscar, pasar o llevar un objeto",
    "soltar": "soltar, dejar, poner, colocar o depositar el objeto en un lugar",
    "mover": "mover o girar el brazo a una posicion, sin tomar ni soltar objetos",
    "detener": "parar, detener, frenar, alto o quedarse quieto",
    "otra": "saludo, pregunta u otra cosa que no es una orden para el brazo",
}

VARIANTES = {
    "accion": {
        "v1_actual": lc.QUESTIONS["accion"],
        "v2_verbos": {"type": "choice", "instructions": "Que accion le pide el operador al brazo robotico en `message`?",
                      "criteria": ACC_RICA},
        "v3_verbo_principal": {"type": "choice", "instructions": "Cual es el verbo principal de la orden en `message`?",
                               "criteria": ACC_RICA},
    },
    "objeto": {
        "v1_actual": lc.QUESTIONS["objeto"],
        "v2_sinonimos": {"type": "choice", "instructions": "Que objeto se menciona en `message`?",
                         "criteria": {k: v for k, v in lc.OBJETOS.items()}
                         | {"ninguno": "no se nombra ningun objeto, solo un color o nada"}},
    },
    "color": {
        "v1_actual": lc.QUESTIONS["color"],
        "v2_corto": {"type": "choice", "instructions": "Que color se nombra en `message`?",
                     "criteria": {k: (k if k not in ("otro", "ninguno") else v) for k, v in lc.COLORES.items()}},
    },
    "prioridad": {
        "v1_actual_score": lc.QUESTIONS["prioridad"],
        "v2_choice": {"type": "choice", "instructions": "Con que urgencia pide el operador la orden de `message`?",
                      "criteria": {"sin_prisa": "sin prisa, con calma, cuando se pueda",
                                   "normal": "orden comun, no dice nada de urgencia",
                                   "urgente": "urgente, rapido, ya, ahora, lo antes posible",
                                   "emergencia": "emergencia, inmediatamente, alto total"}},
        "v3_score_rico": {"type": "score", "instructions": "Que tan urgente es la orden de `message`?",
                          "criteria": ["sin prisa: dice con calma o cuando puedas",
                                       "normal: no menciona urgencia",
                                       "urgente: dice rapido, ya, ahora o urgente",
                                       "emergencia: dice emergencia o inmediatamente"]},
    },
    "permitido": {
        "v1_actual_noul": lc.QUESTIONS["permitido"],
        "v2_choice_AB": {"type": "choice", "instructions": "Es segura para un brazo robotico la orden de `message`?",
                         "criteria": {"A": "si: agarrar, soltar, mover, detener objetos de la mesa, o una frase inofensiva",
                                      "B": "no: lanzar, tirar, golpear, romper, empujar, chocar, ir hacia personas o desactivar la seguridad"}},
        "v3_noul_peligro": {"type": "noul", "invertir": True,
                            "instructions": "Pide `message` lanzar, tirar, golpear, romper, empujar, chocar, ir hacia una persona o desactivar la seguridad?",
                            "criteria": {"true": "si, pide algo peligroso o prohibido",
                                         "false": "no, es una orden normal o una frase inofensiva"}},
    },
}

MAPEO_PRIORIDAD = {"sin_prisa": 1, "normal": 2, "urgente": 3, "emergencia": 4}
MAPEO_PERMITIDO = {"A": True, "B": False}


def valor(campo, spec, ans):
    """Convierte la respuesta tipada al valor del servicio (mismo criterio que laya_cliente)."""
    t = spec["type"]
    if campo == "prioridad":
        return int(round(float(ans["score"]))) + 1 if t == "score" else MAPEO_PRIORIDAD.get(ans["choice"], 2)
    if campo == "permitido":
        if t == "choice":
            return MAPEO_PERMITIDO.get(ans["choice"], True)
        p = float(ans["noul"])
        return (p < 0.5) if spec.get("invertir") else (p >= 0.5)
    return ans["choice"]


def limpiar(spec):
    return {k: v for k, v in spec.items() if k != "invertir"}


def main_cli():
    ap = argparse.ArgumentParser()
    ap.add_argument("frases")
    ap.add_argument("--aplicar", action="store_true")
    ap.add_argument("--timeout", type=float, default=300.0)
    a = ap.parse_args(sys.argv[1:] if "--ros-args" not in sys.argv else sys.argv[1:sys.argv.index("--ros-args")])
    filas = list(csv.DictReader(open(a.frases, encoding="utf-8-sig")))[:64]
    questions = {f"{c}__{n}": limpiar(s) for c, vs in VARIANTES.items() for n, s in vs.items()}
    print(f"Consultando a {lc.LAYA_URL} con {len(filas)} frases x {len(questions)} preguntas (puede tardar ~1 min)...")
    t0 = time.time()
    body = {"states": [{"message": f["frase"]} for f in filas], "questions": questions}
    if lc.LAYA_MODEL:
        body["model"] = lc.LAYA_MODEL
    r = requests.post(lc.LAYA_URL.rstrip("/") + "/v1/systemone/batch", json=body, headers=lc._headers(),
                      timeout=a.timeout)
    r.raise_for_status()
    res = r.json()["results"]
    print(f"Listo en {time.time() - t0:.1f} s\n")

    mejor = {}
    print("| Campo | Variante | Exactitud |\n|---|---|---|")
    for campo, vs in VARIANTES.items():
        if campo not in filas[0]:
            continue
        puntajes = {}
        for n, spec in vs.items():
            ok = 0
            for f, rr in zip(filas, res):
                v = valor(campo, spec, rr["answers"][f"{campo}__{n}"])
                ok += str(v).lower() == str(f[campo]).strip().lower()
            puntajes[n] = ok / len(filas)
        for n, p in puntajes.items():
            marca = " <- mejor" if p == max(puntajes.values()) else ""
            print(f"| {campo} | {n} | {100 * p:.0f}%{marca} |")
        mejor[campo] = max(puntajes, key=puntajes.get)

    if a.aplicar:
        salida = {c: VARIANTES[c][n] for c, n in mejor.items()}
        os.makedirs(os.path.dirname(RUTA_SALIDA), exist_ok=True)
        json.dump(salida, open(RUTA_SALIDA, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
        print(f"\nGuardado en {RUTA_SALIDA}: {mejor}")
        print("Reinicien interprete_ordenes para que lo use.")
    else:
        print(f"\nMejor por campo: {mejor}\nPara usarlas: repetir con --aplicar")


if __name__ == "__main__":
    main_cli()
