#!/usr/bin/env python3
"""Mide el SERVICIO /interpretar_orden sobre las 50 frases del docente.

Llama al servicio (con el nodo interprete_ordenes corriendo), y por cada frase guarda:
  tiempo total del servicio, RTT HTTP, tiempo de calculo del servidor, red = RTT - servidor,
  si la respuesta fue degradada, la decision del servicio y la del clasificador por palabras clave.

Uso:
  ros2 run examen_nodos medir_latencia frases.csv calma.csv --etiqueta calma
  ros2 run examen_nodos medir_latencia frases.csv carga.csv --etiqueta carga

frases.csv: columna obligatoria `frase`; columnas esperadas opcionales
            accion, objeto, color, prioridad, permitido  (solo se comparan las que existan)
"""
import argparse
import csv
import statistics as st
import sys
import time

import rclpy
from rclpy.node import Node

from interfaces_examen.srv import InterpretarOrden
from examen_nodos.laya_cliente import clasificar_palabras_clave

CAMPOS = ["accion", "objeto", "color", "prioridad", "permitido"]


def norm(campo, v):
    v = str(v).strip().lower()
    if campo == "permitido":
        return "true" if v in ("true", "1", "si", "sí", "yes", "permitido", "verdadero") else "false"
    if campo == "prioridad":
        try:
            return str(int(float(v)))
        except ValueError:
            return v
    return v


def p95(x):
    x = sorted(x)
    if not x:
        return float("nan")
    k = 0.95 * (len(x) - 1)                 # percentil con interpolacion lineal
    i = int(k)
    return x[i] if i + 1 >= len(x) else x[i] + (x[i + 1] - x[i]) * (k - i)


def leer_frases(ruta):
    with open(ruta, encoding="utf-8-sig") as fh:
        filas = list(csv.DictReader(fh))
    if not filas or "frase" not in filas[0]:
        sys.exit(f"{ruta}: necesita una columna 'frase'")
    return filas


def main_cli():
    ap = argparse.ArgumentParser()
    ap.add_argument("entrada")
    ap.add_argument("salida")
    ap.add_argument("--etiqueta", default="calma")
    ap.add_argument("--pausa", type=float, default=0.0, help="segundos entre frases")
    ap.add_argument("--espera-servicio", type=float, default=10.0,
                    help="tope del cliente; el limite real es timeout_s del nodo")
    a = ap.parse_args(rclpy.utilities.remove_ros_args(sys.argv)[1:])

    filas_in = leer_frases(a.entrada)
    esp_campos = [c for c in CAMPOS if c in filas_in[0]]

    rclpy.init()
    nodo = Node("medidor_latencia")
    cli = nodo.create_client(InterpretarOrden, "/interpretar_orden")
    if not cli.wait_for_service(timeout_sec=10.0):
        sys.exit("No encuentro /interpretar_orden. ¿Esta corriendo interprete_ordenes en el mismo ROS_DOMAIN_ID?")

    salida, svc, rtt, srv, red = [], [], [], [], []
    ok = {"servicio": 0, "laya": 0, "kw": 0}
    ok_campo = {m: {c: 0 for c in esp_campos} for m in ok}
    n_laya = n_deg = 0

    for i, r in enumerate(filas_in, 1):
        req = InterpretarOrden.Request()
        req.frase = r["frase"]
        t0 = time.perf_counter()
        fut = cli.call_async(req)
        rclpy.spin_until_future_complete(nodo, fut, timeout_sec=a.espera_servicio)
        t_svc = (time.perf_counter() - t0) * 1000.0
        res = fut.result()
        kw = clasificar_palabras_clave(r["frase"])
        if res is None:
            print(f"[{i}] sin respuesta del servicio")
            continue

        dec = {"accion": res.accion, "objeto": res.objeto, "color": res.color,
               "prioridad": res.prioridad, "permitido": res.permitido}
        svc.append(t_svc)
        if res.degradado:
            n_deg += 1
        else:
            n_laya += 1
            rtt.append(res.rtt_ms)
            if res.servidor_ms >= 0:
                srv.append(res.servidor_ms)
                red.append(res.rtt_ms - res.servidor_ms)

        esp = {c: norm(c, r[c]) for c in esp_campos if str(r.get(c, "")).strip() != ""}
        aciertos = {}
        for metodo, d in (("servicio", dec), ("laya", None if res.degradado else dec), ("kw", kw)):
            if d is None:
                aciertos[metodo] = ""
                continue
            bien = {c: norm(c, d[c]) == v for c, v in esp.items()}
            for c, b in bien.items():
                ok_campo[metodo][c] += b
            todo = all(bien.values()) if bien else False
            ok[metodo] += todo
            aciertos[metodo] = int(todo)

        fila = {"n": i, "frase": r["frase"], "etiqueta": a.etiqueta}
        fila.update({f"esp_{c}": v for c, v in esp.items()})
        fila.update({f"svc_{c}": norm(c, dec[c]) for c in CAMPOS})
        fila.update({f"kw_{c}": norm(c, kw[c]) for c in CAMPOS})
        fila.update({"degradado": res.degradado, "servicio_ms": round(t_svc, 2),
                     "rtt_ms": round(res.rtt_ms, 2), "servidor_ms": round(res.servidor_ms, 2),
                     "red_ms": round(res.rtt_ms - res.servidor_ms, 2) if res.servidor_ms >= 0 and not res.degradado else -1,
                     "ok_servicio": aciertos["servicio"], "ok_laya": aciertos["laya"], "ok_kw": aciertos["kw"]})
        salida.append(fila)
        print(f"[{i:02d}] {t_svc:7.1f} ms deg={int(res.degradado)} {dec}  <- {r['frase']}")
        if a.pausa:
            time.sleep(a.pausa)

    campos_csv = []
    for f in salida:
        for k in f:
            if k not in campos_csv:
                campos_csv.append(k)
    with open(a.salida, "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=campos_csv)
        w.writeheader()
        w.writerows(salida)

    n = len(salida)
    print(f"\n=== LATENCIA [{a.etiqueta}]  (n={n}, degradadas={n_deg}) ===")
    print("| Medida | Mediana (ms) | P95 (ms) | n |\n|---|---|---|---|")
    for nom, v in (("Servicio completo (cliente ROS)", svc), ("RTT HTTP a LAYA", rtt),
                   ("Calculo en servidor (X-Inference-Time-Ms)", srv), ("Red + cola (RTT - servidor)", red)):
        if v:
            print(f"| {nom} | {st.median(v):.1f} | {p95(v):.1f} | {len(v)} |")
    if esp_campos and n:
        print(f"\n=== EXACTITUD [{a.etiqueta}] (todos los campos correctos) ===")
        print("| Metodo | Aciertos | Exactitud | " + " | ".join(esp_campos) + " |")
        print("|---|---|---|" + "---|" * len(esp_campos))
        for m, nombre, den in (("laya", "LAYA (solo respuestas no degradadas)", n_laya),
                               ("kw", "Palabras clave", n), ("servicio", "Servicio (LAYA + respaldo)", n)):
            if den:
                por_campo = " | ".join(f"{100 * ok_campo[m][c] / den:.0f}%" for c in esp_campos)
                print(f"| {nombre} | {ok[m]}/{den} | {100 * ok[m] / den:.0f}% | {por_campo} |")
    print(f"\nCSV guardado en {a.salida}")
    nodo.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main_cli()
