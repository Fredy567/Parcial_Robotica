#!/usr/bin/env python3
"""Tabla de los intentos de agarre (Pregunta 2) a partir de intentos.csv del broker.

  ros2 run examen_nodos resumen_p2 ~/examen_ws/p2/intentos.csv > tabla_p2.md

Exito: si llenaron la columna `exito_visual` (si/no, mirando el video) se usa esa;
si no, se usa `success` del broker (el broker no puede ver si el objeto quedo en la zona).
"""
import csv
import statistics as st
import sys


def main():
    ruta = sys.argv[1] if len(sys.argv) > 1 else "intentos.csv"
    filas = list(csv.DictReader(open(ruta, encoding="utf-8")))
    intentos = [f for f in filas if not f["mensaje"].startswith("RECHAZADA")]
    rech = [f for f in filas if f["mensaje"].startswith("RECHAZADA")]
    print("## Intentos de agarre\n")
    print("| # | Cliente | Frase | Color | Prioridad | Espera (s) | Objetivo (mm) | Alcanzado FK (mm) | Error (mm) | Planificador | Exito |")
    print("|---|---|---|---|---|---|---|---|---|---|---|")
    exitos, errores = 0, []
    for i, f in enumerate(intentos, 1):
        ev = f.get("exito_visual", "").strip().lower()
        ok = ev in ("si", "sí", "1", "true") if ev else f["success"] == "True"
        exitos += ok
        obj = f"({float(f['obj_x']):.0f}, {float(f['obj_y']):.0f}, {float(f['obj_z']):.0f})" if f["obj_x"] else "-"
        alc = f"({float(f['alc_x']):.0f}, {float(f['alc_y']):.0f}, {float(f['alc_z']):.0f})" if f["alc_x"] else "-"
        if ok and f["error_mm"] and float(f["error_mm"]) >= 0:
            errores.append(float(f["error_mm"]))
        print(f"| {i} | {f['client_id']} | {f['frase']} | {f['color']} | {f['prioridad']} | {f['espera_s']} | "
              f"{obj} | {alc} | {f['error_mm'] or '-'} | {f['planificador']} | {'SI' if ok else 'NO: ' + f['mensaje']} |")
    n = len(intentos)
    if n:
        print(f"\n**Tasa de exito: {exitos}/{n} = {100 * exitos / n:.0f}%**")
    if errores:
        print(f"\nError en intentos exitosos: media {st.mean(errores):.1f} mm, "
              f"mediana {st.median(errores):.1f} mm, maximo {max(errores):.1f} mm (n={len(errores)})")
    print(f"\n## Ordenes rechazadas antes de encolar ({len(rech)})\n")
    for f in rech:
        print(f"- [{f['client_id']}] \"{f['frase']}\" -> {f['mensaje'][len('RECHAZADA: '):]}")


if __name__ == "__main__":
    main()
