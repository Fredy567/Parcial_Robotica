#!/usr/bin/env python3
"""Calibracion de la mesa ANTES de la demostracion (no se usa durante la demo).

Usa pymycobot directo, por eso el driver debe estar APAGADO (puerto serie libre).
Ustedes mueven el brazo CON LA MANO y el programa guarda los angulos:

  1. pose de camara (desde donde la camara ve los 4 cubos)  -> tambien es la pose de reposo
  2. cada cubo: pinza abierta rodeando el cubo, a la altura de agarre
  3. zona de deposito: pinza donde debe soltar el objeto

Luego lleva el brazo a la pose de camara, toma una foto, detecta los 4 colores y
calcula la homografia pixel -> mesa (x, y en mm).

Uso:
  ros2 run examen_nodos calibrar_mesa                      # todo
  ros2 run examen_nodos calibrar_mesa --solo-camara        # rehace solo la foto/homografia
  ros2 run examen_nodos calibrar_mesa --colores rojo azul  # si hay otros colores
"""
import argparse
import math
import os
import sys
import time

import cv2 as cv
import numpy as np

from arm_broker import fk, mesa
from examen_nodos import vision

try:
    from pymycobot.mycobot import MyCobot
except ImportError:
    from pymycobot import MyCobot


def leer_angulos(mc, intentos=10):
    for _ in range(intentos):
        a = mc.get_angles()
        if isinstance(a, list) and len(a) == 6:
            return a
        time.sleep(0.2)
    raise RuntimeError("el brazo no devolvio sus angulos; revisen el cable y que el driver este apagado")


def ensenar(mc, titulo, instrucciones):
    print("\n" + "=" * 70)
    print(f">>> {titulo}")
    print(instrucciones)
    input("    SUJETEN el brazo con la mano y presionen ENTER para LIBERAR los motores...")
    mc.release_all_servos()
    time.sleep(0.5)
    input("    Muevan el brazo a la posicion y presionen ENTER para GUARDAR...")
    a = leer_angulos(mc)
    mc.send_angles(a, 20)            # vuelve a dar torque en esa misma pose
    time.sleep(1.0)
    q = [math.radians(v) for v in a]
    x, y, z = fk.fk(q)
    c = mc.get_coords()
    print(f"    angulos (grados): {[round(v, 1) for v in a]}")
    print(f"    FK RB-2 (mm):     ({x:.1f}, {y:.1f}, {z:.1f})")
    if isinstance(c, list) and len(c) >= 3:
        err = math.dist((x, y, z), c[:3])
        print(f"    robot get_coords: ({c[0]:.1f}, {c[1]:.1f}, {c[2]:.1f})  -> diferencia FK {err:.1f} mm")
    return {"q": [float(v) for v in q], "xyz": [float(x), float(y), float(z)]}


def calibrar_camara(mc, m, args):
    print("\n" + "=" * 70)
    print(">>> CAMARA: pongan los cubos en sus lugares ensenados. El brazo ira a la pose de camara.")
    input("    ENTER para mover el brazo a la pose de camara...")
    mc.send_angles(mesa.grados(m["watch_q"]), 30)
    time.sleep(4.0)
    hsv = vision.leer_hsv(args.hsv)
    cam = vision.Camara(args.camara)
    if not cam.ok:
        print("ERROR: no se pudo abrir la camara. ¿Otro programa la esta usando?")
        return
    frame = cam.cuadro_despues_de(time.time() + 0.5, timeout=5.0)
    cam.cerrar()
    if frame is None:
        print("ERROR: la camara no entrego imagen")
        return
    px, mm = [], []
    for color, obj in m["objetos"].items():
        det = vision.detectar(frame, color, hsv, args.area_min)
        if det is None:
            print(f"    {color}: NO detectado (revisen luz o HSV_config.txt)")
            continue
        obj["pixel"] = [float(det[0]), float(det[1])]
        vision.dibujar(frame, color, det)
        px.append(det[:2])
        mm.append(obj["xyz"][:2])
        print(f"    {color}: pixel ({det[0]:.0f}, {det[1]:.0f})  area {det[2]:.0f}  -> mesa ({obj['xyz'][0]:.0f}, {obj['xyz'][1]:.0f}) mm")
    m["homografia"] = None
    if len(px) >= 4:
        P, Q = np.float32(px), np.float32(mm)
        # area del cuadrilatero en mm^2: si es casi 0 los cubos estan en linea
        area = cv.contourArea(cv.convexHull(Q))
        if area > 2000:
            H, _ = cv.findHomography(P, Q)
            if H is not None:
                m["homografia"] = H.tolist()
                print(f"    Homografia calculada (area cubierta {area:.0f} mm2). La camara localizara en x, y.")
        else:
            print("    Los cubos estan casi en linea: no hay homografia; se usara el lugar mas cercano.")
    else:
        print("    Menos de 4 colores detectados: se usara el lugar mas cercano en pixeles.")
    os.makedirs(os.path.dirname(os.path.expanduser(args.salida)), exist_ok=True)
    foto = os.path.join(os.path.dirname(os.path.expanduser(args.salida)), "calibracion_camara.jpg")
    cv.imwrite(foto, frame)
    print(f"    Foto con las detecciones: {foto}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--puerto", default="/dev/ttyUSB0")
    ap.add_argument("--baud", type=int, default=1000000)
    ap.add_argument("--salida", default=mesa.RUTA_DEFECTO)
    ap.add_argument("--colores", nargs="+", default=mesa.COLORES)
    ap.add_argument("--camara", type=int, default=0)
    ap.add_argument("--hsv", default=vision.HSV_YAHBOOM)
    ap.add_argument("--area-min", type=float, default=800)
    ap.add_argument("--solo-camara", action="store_true")
    a = ap.parse_args()

    mc = MyCobot(a.puerto, a.baud)
    time.sleep(0.5)
    leer_angulos(mc)
    print("Conectado al brazo. Si el driver_jetcobot o sync_plan_nx estan corriendo, CIERRENLOS primero.")

    if a.solo_camara:
        m = mesa.cargar(a.salida)
    else:
        m = mesa.cargar(a.salida) if os.path.exists(os.path.expanduser(a.salida)) else {}
        m.setdefault("altura_aproximacion_mm", 60.0)
        m.setdefault("pinza", {"abierta": 100, "cerrada": 20})
        mc.set_gripper_value(m["pinza"]["abierta"], 50)
        w = ensenar(mc, "POSE DE CAMARA (y de reposo)",
                    "    Pongan el brazo arriba, con la camara mirando la mesa y viendo LOS 4 cubos.")
        m["watch_q"] = w["q"]
        m["objetos"] = {}
        for color in a.colores:
            m["objetos"][color] = ensenar(
                mc, f"CUBO {color.upper()}",
                f"    Lleven la pinza ABIERTA alrededor del cubo {color}, vertical, a la altura donde lo agarraria.")
        m["zona"] = ensenar(mc, "ZONA DE DEPOSITO",
                            "    Lleven la pinza donde debe SOLTAR el objeto (a la altura de soltarlo).")
    calibrar_camara(mc, m, a)
    ruta = mesa.guardar(m, a.salida)
    mc.send_angles(mesa.grados(m["watch_q"]), 30)
    print(f"\nListo. Configuracion guardada en {ruta}")


if __name__ == "__main__":
    sys.exit(main())
