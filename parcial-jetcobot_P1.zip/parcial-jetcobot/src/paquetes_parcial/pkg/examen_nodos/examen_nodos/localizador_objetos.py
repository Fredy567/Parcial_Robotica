#!/usr/bin/env python3
"""Nodo localizador_objetos: servicio /localizar_objeto (percepcion de la Pregunta 2).

NO mueve el brazo: solo mira. El worker del broker deja el brazo en la pose de
camara y llama a este servicio con un color; el nodo toma un cuadro NUEVO,
detecta el cubo y devuelve su posicion en la mesa (mm, marco de la base):

  - con homografia (calibrar_mesa): x, y = H * pixel; si cae a menos de
    `ajuste_slot_mm` de un lugar ensenado, usa ese lugar (mas preciso).
  - sin homografia: el lugar ensenado cuyo pixel de calibracion esta mas cerca.

Parametros: mesa (ruta yaml), camara (indice), hsv (archivo HSV de Yahboom),
            area_min, espera_estable_s, carpeta_capturas (guarda cada foto como evidencia).
"""
import math
import os
import time

import cv2 as cv
import numpy as np
import rclpy
from rclpy.node import Node

from interfaces_examen.srv import LocalizarObjeto
from arm_broker import mesa
from examen_nodos import vision


class Localizador(Node):
    def __init__(self):
        super().__init__("localizador_objetos")
        self.declare_parameter("mesa", mesa.RUTA_DEFECTO)
        self.declare_parameter("camara", 0)
        self.declare_parameter("hsv", vision.HSV_YAHBOOM)
        self.declare_parameter("area_min", 800.0)
        self.declare_parameter("espera_estable_s", 0.4)
        self.declare_parameter("carpeta_capturas", os.path.expanduser("~/examen_ws/p2/capturas"))
        self.m = mesa.cargar(self.get_parameter("mesa").value)
        self.hsv = vision.leer_hsv(self.get_parameter("hsv").value)
        self.cam = vision.Camara(int(self.get_parameter("camara").value))
        self.capturas = self.get_parameter("carpeta_capturas").value
        os.makedirs(self.capturas, exist_ok=True)
        self.n = 0
        self.create_service(LocalizarObjeto, "/localizar_objeto", self.cb)
        estado = "OK" if self.cam.ok else "NO SE PUDO ABRIR"
        modo = "homografia" if self.m.get("homografia") else "lugar mas cercano"
        self.get_logger().info(f"localizador listo · camara {estado} · modo {modo} · "
                               f"objetos {list(self.m['objetos'])}")

    def cb(self, req, res):
        t0 = time.perf_counter()
        color = req.color.strip().lower()
        res.encontrado, res.metodo, res.mensaje = False, "", ""
        obj = self.m["objetos"].get(color)
        if not self.cam.ok:
            res.metodo, res.mensaje = "sin_camara", "la camara no esta disponible"
            res.tiempo_ms = (time.perf_counter() - t0) * 1000
            return res
        frame = self.cam.cuadro_despues_de(time.time() + float(self.get_parameter("espera_estable_s").value))
        if frame is None:
            res.metodo, res.mensaje = "sin_camara", "la camara no entrego imagen"
            res.tiempo_ms = (time.perf_counter() - t0) * 1000
            return res
        det = vision.detectar(frame, color, self.hsv, float(self.get_parameter("area_min").value))
        if det is None:
            res.mensaje = f"no se ve ningun objeto {color} en la mesa"
        else:
            u, v, area = det
            res.u_px, res.v_px, res.area_px = float(u), float(v), float(area)
            H = self.m.get("homografia")
            lugares = self.m["objetos"]
            if H is not None:
                p = np.array(H) @ np.array([u, v, 1.0])
                x, y = p[0] / p[2], p[1] / p[2]
                cerca = min(lugares.items(), key=lambda kv: math.dist((x, y), kv[1]["xyz"][:2]))
                if math.dist((x, y), cerca[1]["xyz"][:2]) <= float(self.m["ajuste_slot_mm"]):
                    x, y, z = cerca[1]["xyz"]
                    res.metodo = f"homografia+lugar_{cerca[0]}"
                else:
                    z = (obj or cerca[1])["xyz"][2]
                    res.metodo = "homografia"
            else:
                con_px = {k: o for k, o in lugares.items() if "pixel" in o}
                if not con_px:
                    res.mensaje = "falta calibrar la camara (calibrar_mesa --solo-camara)"
                    res.tiempo_ms = (time.perf_counter() - t0) * 1000
                    return res
                cerca = min(con_px.items(), key=lambda kv: math.dist((u, v), kv[1]["pixel"]))
                x, y, z = cerca[1]["xyz"]
                res.metodo = f"lugar_{cerca[0]}"
            res.x_mm, res.y_mm, res.z_mm = float(x), float(y), float(z)
            res.encontrado = True
            res.mensaje = f"{color} en ({x:.0f}, {y:.0f}, {z:.0f}) mm"
        res.tiempo_ms = (time.perf_counter() - t0) * 1000
        self.n += 1
        vision.dibujar(frame, color, det, res.metodo)
        cv.imwrite(os.path.join(self.capturas, f"{self.n:03d}_{color}.jpg"), frame)
        self.get_logger().info(f"localizar {color}: {res.mensaje} [{res.metodo}] ({res.tiempo_ms:.0f} ms)")
        return res


def main():
    rclpy.init()
    n = Localizador()
    try:
        rclpy.spin(n)
    except KeyboardInterrupt:
        pass
    finally:
        n.cam.cerrar()
        n.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
