"""Deteccion de cubos por color con OpenCV (sin ROS).

Reutiliza la calibracion HSV que ya tienen en el robot (formato de Yahboom):
    /home/jetson/jetcobot_ws/src/jetcobot_color_identify/scripts/HSV_config.txt
    "red": [h1, s1, v1, h2, s2, v2],
"""
import os
import threading
import time

import cv2 as cv
import numpy as np

HSV_YAHBOOM = "/home/jetson/jetcobot_ws/src/jetcobot_color_identify/scripts/HSV_config.txt"
ES_A_EN = {"rojo": "red", "verde": "green", "azul": "blue", "amarillo": "yellow"}
# Valores por defecto de Yahboom (se reemplazan por los del archivo si existe)
HSV_DEFECTO = {"red": ((0, 103, 172), (2, 255, 255)),
               "green": ((54, 109, 78), (77, 255, 255)),
               "blue": ((92, 100, 62), (121, 251, 255)),
               "yellow": ((26, 100, 91), (32, 255, 255))}


def leer_hsv(ruta=HSV_YAHBOOM):
    hsv = dict(HSV_DEFECTO)
    if ruta and os.path.exists(ruta):
        with open(ruta) as fh:
            for linea in fh:
                a, b = linea.find('"'), linea.rfind('"')
                c, d = linea.find('['), linea.rfind(']')
                if a >= 0 and b > a and c >= 0 and d > c:
                    v = [int(x) for x in linea[c + 1:d].split(',')]
                    nombre = linea[a + 1:b]
                    # Proteccion: el tono (H) en OpenCV va de 0 a 179. Un rango de mas de
                    # 50 de ancho atrapa otros colores (p.ej. amarillo con H hasta 255).
                    if v[3] > 179 or v[3] - v[0] > 50:
                        print(f"[vision] AVISO: rango HSV de '{nombre}' invalido {v}; "
                              f"se usa el de fabrica {HSV_DEFECTO.get(nombre)}")
                        continue
                    hsv[nombre] = ((v[0], v[1], v[2]), (v[3], v[4], v[5]))
    return hsv


def detectar(frame, color_es, hsv, area_min=800):
    """Devuelve (u, v, area) del blob mas grande del color, o None."""
    clave = ES_A_EN.get(color_es, color_es)
    if clave not in hsv:
        return None
    lo, hi = hsv[clave]
    img = cv.cvtColor(frame, cv.COLOR_BGR2HSV)
    mask = cv.inRange(img, np.array(lo), np.array(hi))
    mask = cv.morphologyEx(mask, cv.MORPH_OPEN, np.ones((3, 3), np.uint8))
    mask = cv.morphologyEx(mask, cv.MORPH_CLOSE, np.ones((5, 5), np.uint8))
    cs = cv.findContours(mask, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE)
    cs = cs[0] if len(cs) == 2 else cs[1]
    if not cs:
        return None
    c = max(cs, key=cv.contourArea)
    area = cv.contourArea(c)
    if area < area_min:
        return None
    m = cv.moments(c)
    if m["m00"] == 0:
        return None
    return (m["m10"] / m["m00"], m["m01"] / m["m00"], area)


def dibujar(frame, color_es, det, texto=""):
    if det:
        u, v, _ = det
        cv.circle(frame, (int(u), int(v)), 6, (0, 0, 255), -1)
        cv.putText(frame, f"{color_es} {texto}", (int(u) + 8, int(v) - 8),
                   cv.FONT_HERSHEY_SIMPLEX, 0.6, (255, 0, 255), 2)
    return frame


class Camara:
    """Lee la camara en un hilo y guarda siempre el ultimo cuadro (sin buffer viejo)."""

    def __init__(self, indice=0, ancho=640, alto=480):
        self.cap = cv.VideoCapture(indice)
        self.cap.set(cv.CAP_PROP_FOURCC, cv.VideoWriter.fourcc('M', 'J', 'P', 'G'))
        self.cap.set(cv.CAP_PROP_FRAME_WIDTH, ancho)
        self.cap.set(cv.CAP_PROP_FRAME_HEIGHT, alto)
        self.ok = self.cap.isOpened()
        self._frame, self._t = None, 0.0
        self._lock = threading.Lock()
        self._parar = False
        if self.ok:
            threading.Thread(target=self._bucle, daemon=True).start()

    def _bucle(self):
        while not self._parar:
            ok, f = self.cap.read()
            if ok:
                with self._lock:
                    self._frame, self._t = f, time.time()
            else:
                time.sleep(0.05)

    def cuadro_despues_de(self, t_min, timeout=2.0):
        """Primer cuadro capturado despues de t_min (para no usar uno de antes de llegar)."""
        fin = time.time() + timeout
        while time.time() < fin:
            with self._lock:
                if self._frame is not None and self._t >= t_min:
                    return self._frame.copy()
            time.sleep(0.01)
        return None

    def cerrar(self):
        self._parar = True
        time.sleep(0.1)
        self.cap.release()
