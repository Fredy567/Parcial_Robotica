from glob import glob
from setuptools import setup

package_name = 'examen_nodos'

setup(
    name=package_name,
    version='0.3.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', glob('launch/*.launch.py')),
    ],
    install_requires=['setuptools', 'requests'],
    zip_safe=True,
    entry_points={'console_scripts': [
        # Pregunta 1
        'interprete_ordenes = examen_nodos.interprete_ordenes:main',
        'medir_latencia = examen_nodos.medir_latencia:main_cli',
        'resumen_p1 = examen_nodos.resumen_p1:main_cli',
        'laya_simulado = examen_nodos.laya_simulado:main',
        # Pregunta 2
        'driver_jetcobot = examen_nodos.driver_jetcobot:main',
        'localizador_objetos = examen_nodos.localizador_objetos:main',
        'calibrar_mesa = examen_nodos.calibrar_mesa:main',
        'enviar_orden = examen_nodos.enviar_orden:main',
        'resumen_p2 = examen_nodos.resumen_p2:main',
        'afinar_laya = examen_nodos.afinar_laya:main_cli',
    ]},
)
