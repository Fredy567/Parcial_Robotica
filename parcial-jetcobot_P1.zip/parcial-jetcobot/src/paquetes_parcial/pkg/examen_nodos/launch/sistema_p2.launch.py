"""Levanta TODO el sistema de la Pregunta 2 en el Jetson.

  ros2 launch examen_nodos sistema_p2.launch.py                 # con MoveIt2
  ros2 launch examen_nodos sistema_p2.launch.py moveit:=false   # sin MoveIt2 (interpola)
  ros2 launch examen_nodos sistema_p2.launch.py timeout_s:=1.5 politica:=prioridad
"""
from ament_index_python.packages import get_package_share_directory, PackageNotFoundError
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, LogInfo
from launch.conditions import IfCondition
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def generate_launch_description():
    moveit = LaunchConfiguration('moveit')
    ld = [
        DeclareLaunchArgument('moveit', default_value='true'),
        DeclareLaunchArgument('timeout_s', default_value='1.5'),
        DeclareLaunchArgument('politica', default_value='prioridad'),
        Node(package='examen_nodos', executable='driver_jetcobot', output='screen'),
        Node(package='examen_nodos', executable='localizador_objetos', output='screen'),
        Node(package='examen_nodos', executable='interprete_ordenes', output='screen',
             parameters=[{'timeout_s': ParameterValue(LaunchConfiguration('timeout_s'), value_type=float)}]),
        Node(package='arm_broker', executable='broker', output='screen',
             parameters=[{'politica': LaunchConfiguration('politica'),
                          'usar_moveit': ParameterValue(moveit, value_type=bool)}]),
    ]
    try:
        d = get_package_share_directory('jetcobot_moveit') + '/launch/'
        for f in ('rsp.launch.py', 'move_group.launch.py'):
            ld.append(IncludeLaunchDescription(PythonLaunchDescriptionSource(d + f),
                                               condition=IfCondition(moveit)))
    except PackageNotFoundError:
        ld.append(LogInfo(msg='jetcobot_moveit no encontrado: source ~/jetcobot_colcon_ws/install/setup.bash'))
    return LaunchDescription(ld)
