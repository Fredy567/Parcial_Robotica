#!/bin/bash
# Instala la Pregunta 3 en una Raspberry que YA tiene el cliente de la P2 (~/examen_rpi).
# Uso:  bash ~/p3_entrega/instalar_p3_raspberry.sh
set -e
D="$(cd "$(dirname "$0")" && pwd)"
[ -d ~/examen_rpi/src ] || { echo "Falta ~/examen_rpi: primero instalar_raspberry.sh de la P2"; exit 1; }
rm -rf ~/examen_rpi/src/examen_nodos
cp -r "$D"/../src/paquetes_parcial/pkg/examen_nodos ~/examen_rpi/src/
source /opt/ros/humble/setup.bash
python3 -c "import requests" 2>/dev/null || pip3 install --user requests
which ffmpeg >/dev/null || echo "AVISO: sin ffmpeg. Usen audios .mp3/.wav/.ogg (o: sudo apt install ffmpeg)"
cd ~/examen_rpi && colcon build --packages-select arm_broker_interfaces interfaces_examen examen_nodos 2>&1 | tail -2
# Clave de Google AI Studio: FUERA de cualquier repositorio, solo lectura del usuario
mkdir -p ~/.config/examen && chmod 700 ~/.config/examen
if [ ! -s ~/.config/examen/gemini.env ]; then
  read -s -p "Peguen la clave de Google AI Studio (no se vera) y ENTER: " K; echo
  printf 'export GEMINI_API_KEY=%q\n' "$K" > ~/.config/examen/gemini.env
  chmod 600 ~/.config/examen/gemini.env
fi
grep -q gemini.env ~/env_rpi.sh || echo '[ -f ~/.config/examen/gemini.env ] && source ~/.config/examen/gemini.env' >> ~/env_rpi.sh
mkdir -p ~/examen_ws/p3/audios
source ~/env_rpi.sh
[ -n "$GEMINI_API_KEY" ] && echo "clave cargada (largo ${#GEMINI_API_KEY})" || echo "AVISO: clave vacia"
curl -s -o /dev/null -w "Google AI Studio responde: HTTP %{http_code}\n" -H "x-goog-api-key: $GEMINI_API_KEY" \
  https://generativelanguage.googleapis.com/v1beta/models || true
echo "LISTO.  source ~/env_rpi.sh && ros2 run examen_nodos transcriptor_voz --id voz"
