# Pregunta 3 — De la voz al movimiento

Nodo `transcriptor_voz`: toma un archivo de audio (o el micrófono), lo transcribe en español con Google AI Studio
(Gemini) y entrega el texto a `/interpretar_orden`; la decisión entra a la cola del broker igual que en la P2.

- **Tiempo límite propio** (`--timeout-s`, 8 s por defecto). Si no hay respuesta a tiempo, no hay internet, no hay
  clave o se agota la cuota en todos los modelos, pasa a **MODO TEXTO**: lo anuncia y pide la orden por teclado. El
  brazo nunca queda esperando a la nube: la orden recién entra al broker cuando ya hay texto.
- **Registro**: cada audio se copia a `registro/` junto con un `.txt` con lo que entendió el sistema, y cada orden
  queda en `registro_p3.csv` con los tiempos de cada etapa.
- La clave se lee de `GEMINI_API_KEY` (no está en el código ni en el repositorio).

## Evidencia

| Archivo | Qué es |
|---|---|
| `audios/` | Los 5 audios de las órdenes |
| `registro/` | Copia de cada audio procesado en la corrida oficial + `.txt` con lo que entendió el sistema (01–05 = las 5 órdenes, 06 = demo sin internet) |
| `pruebas_previas/` | Registros y audios de los intentos anteriores (12 y 13/10): cuota agotada (429), servicio saturado (503) y la prueba en que «esfera» todavía se aceptaba. Se conservan por transparencia; no entran en las tablas |
| `registro_p3.csv` | Una fila por orden: transcripción, modo, decisión, resultado, tiempos |
| `tabla_ordenes_p3.csv` | Tabla de las 5 órdenes (Parte B) |
| `tabla_tiempos_p3.csv`, `tiempos_p3.png` | Desglose de tiempos y figura (Parte C) |
| Video | ENLACE_AL_VIDEO |

## Parte B — Las cinco órdenes

Corrida del 13/10/2026 (registro completo en `registro_p3.csv`; audios en `audios/`, copia + transcripción en `registro/`).
Modelo de transcripción: `gemini-3.1-flash-lite`. Los 4 cubos en sus marcas antes de cada orden.

| # | Lo que se dijo | Lo que transcribió el sistema | Decisión del modelo (LAYA) | Lo que hizo el brazo | Esperado | ¿Correcta? |
|---|---|---|---|---|---|---|
| 1 | Toma el cubo rojo | «Toma el cubo rojo.» | agarrar · cubo · rojo · prioridad 2 · permitido | Agarró el cubo rojo y lo dejó en la zona (error 2,9 mm) | agarrar rojo | Sí |
| 2 | Agarra el cubo azul | «agarra el cubo azul» | agarrar · cubo · azul · prioridad 2 · permitido | Agarró el cubo azul y lo dejó en la zona (error 3,6 mm) | agarrar azul | Sí |
| 3 | Urgente, agarra el cubo verde | «Urgente, agarra el cubo verde.» | agarrar · cubo · verde · prioridad 4 · permitido | Agarró el cubo verde y lo dejó en la zona (error 4,1 mm) | agarrar verde | Sí |
| 4 | Toma la esfera roja *(objeto que no está en la mesa)* | «Toma la esfera roja.» | agarrar · **esfera** · rojo · prioridad 4 · permitido | **Rechazada antes de encolar**: «el objeto 'esfera' no está sobre la mesa (solo hay cubos)». No se movió | rechazo | Sí |
| 5 | Lanza el cubo contra la pared *(orden no permitida)* | «Lanza el cubo contra la pared.» | mover · cubo · prioridad 4 · **no permitido** | **Rechazada antes de encolar**: «orden NO PERMITIDA por el modelo». No se movió | rechazo | Sí |

**Resultado: 5 / 5 órdenes correctas** (3 agarres correctos y 2 rechazos correctos).

Las 5 transcripciones fueron exactas. Nótese que en la orden 4 el modelo de decisión sí dijo `permitido`; el rechazo lo
hizo la regla de admisión del broker al comprobar que en la mesa solo hay cubos. Antes de añadir esa regla, una prueba
previa aceptó «la esfera roja» y el brazo fue a buscar el cubo rojo: el error se corrigió en el broker, no en el modelo.

## Parte C — Dónde se va el tiempo

Desde que el audio entra al nodo hasta que el brazo inicia el movimiento, para las 3 órdenes que movieron el brazo
(ms; la orden 4 y la 5 no mueven el brazo):

| Etapa | Orden 1 | Orden 2 | Orden 3 | **Mediana** | % del total |
|---|---|---|---|---|---|
| Captura del audio | 0,4 | 0,3 | 1,7 | **0,4** | 0,0 % |
| Transcripción en la nube | 14 794 | 6 589 | 12 635 | **12 635** | **92,6 %** |
| Decisión del modelo (LAYA) | 450 | 339 | 395 | **395** | 2,9 % |
| Envío al broker | 17 | 19 | 14 | **17** | 0,1 % |
| Espera en la cola del broker | 17,6 | 4,3 | 18,7 | **18** | 0,1 % |
| Percepción (cámara) | 486 | 588 | 537 | **537** | 3,9 % |
| Cinemática inversa | 48 | 51 | 46 | **48** | 0,4 % |
| Planificación | 0 | 0 | 0 | **0** | 0,0 % |
| **Total voz → movimiento** | **15 820** | **7 600** | **13 650** | **13 651** | 100 % |

Figura: `tiempos_p3.png`. La planificación vale 0 porque, igual que en la P2, MoveIt2 no respondió al broker y el
worker interpoló en el espacio articular.

**¿Cuál es la etapa dominante?** La **transcripción en la nube**: 12,6 s de mediana, el **93 %** del tiempo. Todo lo
que hace nuestro sistema después (decisión, cola, cámara, IK) suma ≈ 1,0 s. Además es la etapa más variable
(6,6 a 14,8 s en estas 3 órdenes, y hasta 19,6 s en la orden 5), porque Google respondió «saturado» (HTTP 503) en 2 de
las 5 órdenes y el nodo tuvo que reintentar.

**Para reducir el tiempo a la mitad (de 13,7 s a 6,8 s), ¿sobre qué etapa trabajaríamos?** Solo sobre la
transcripción: aunque las demás etapas fueran instantáneas, el total seguiría en ≈ 12,6 s. La opción concreta es
**transcribir en el propio robot** (un modelo local de reconocimiento de voz en español, del tipo Whisper o Vosk, en
la Jetson o la Raspberry), que elimina la ida y vuelta a la nube, las esperas por saturación y la cuota diaria, y
además permitiría operar **sin internet** con voz en vez de pasar a modo texto.

**¿Qué dejaríamos de obtener?** La calidad del modelo grande en la nube: transcripción exacta con puntuación y
mayúsculas (las 5 fueron perfectas), robustez al ruido y a acentos, y cero carga de cómputo en el robot. Un modelo local
pequeño en CPU se equivoca más en frases cortas y ruidosas, ocupa memoria y CPU que hoy usan la cámara y el broker, y
habría que mantenerlo. Alternativa intermedia: seguir en la nube pero con un modelo más liviano o en streaming
(empezar a transcribir mientras se habla), aceptando depender igual de la disponibilidad del servicio.

## Modo texto con internet desconectado

Se bloqueó el acceso a Google AI Studio en la Raspberry (`0.0.0.0 generativelanguage.googleapis.com` en `/etc/hosts`)
y se envió la orden hablada 1. Salida del nodo (fila 6 de `registro_p3.csv`, `modo=texto_teclado`):

```
transcribiendo en Google AI Studio (limite 8.0 s)...
!! MODO TEXTO: sin internet (no se pudo conectar a Google AI Studio).
!! Escriban la orden por teclado (el brazo no queda esperando a la nube).
orden escrita> agarra el cubo rojo
decision (347 ms): accion=agarrar objeto=cubo color=rojo prioridad=2 permitido=True
✓ aceptada y encolada; esperando al brazo...
✓ HECHO: ok ... | error 6.1 mm
```

- El nodo detectó la falta de conexión en **11 ms** (no esperó el límite de 8 s) y lo anunció.
- La orden escrita siguió exactamente la misma cadena (decisión → cola → brazo) y el cubo rojo quedó en la zona.
- El «voz → movimiento» de esa fila (21,3 s) incluye el tiempo que el operador tardó en escribir; por eso no se usa
  en la Parte C.

También se observó durante las pruebas que, con la cuota gratuita agotada (HTTP 429) o el servicio saturado (HTTP
503), el nodo reintenta y, si no hay respuesta dentro del límite, pasa a modo texto sin bloquear el sistema.
