#!/usr/bin/env python3
"""Nodo transcriptor_voz (Pregunta 3): voz -> texto -> /interpretar_orden -> broker.

  audio (archivo o microfono) --Google AI Studio (Gemini)--> texto
        --> /interpretar_orden (Pregunta 1) --> accion recoger_objeto del broker (Pregunta 2)

Uso (siempre despues de  source ~/env_rpi.sh  o  source ~/env_examen.sh):
  ros2 run examen_nodos transcriptor_voz --id voz                      # interactivo: elige archivos
  ros2 run examen_nodos transcriptor_voz --id voz --archivo orden1.mp3
  ros2 run examen_nodos transcriptor_voz --id voz --grabar             # microfono: ENTER para terminar

La clave se lee de la variable de entorno GEMINI_API_KEY (o GOOGLE_API_KEY). NO va en el codigo.
Tiempo limite propio (--timeout-s, 8 s por defecto). Si la nube no responde a tiempo, no hay
internet o no hay clave, el nodo pasa a MODO TEXTO: lo informa y pide la orden por teclado.
El brazo nunca espera a la nube: la orden recien entra al broker cuando ya hay texto.

Registro (Parte A): cada audio se copia a ~/examen_ws/p3/registro/ junto con un .txt de lo que
entendio el sistema, y cada orden queda en ~/examen_ws/p3/registro_p3.csv con los tiempos por
etapa (Parte C). Despues:  ros2 run examen_nodos resumen_p3
"""
import argparse
import base64
import csv
import os
import shutil
import subprocess
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import TimeoutError as FutTimeout

import socket

import requests
import urllib3.util.connection as _u3conn

# La red del laboratorio tiene IPv6 roto (apt fallaba por eso): forzar IPv4 evita que cada
# llamada se quede colgada intentando IPv6 hasta agotar el tiempo limite.
_u3conn.allowed_gai_family = lambda: socket.AF_INET
import rclpy
from rclpy.action import ActionClient
from rclpy.executors import MultiThreadedExecutor
from rclpy.node import Node

from arm_broker_interfaces.action import RecogerObjeto
from interfaces_examen.srv import InterpretarOrden

BASE = os.path.expanduser("~/examen_ws/p3")
CARPETA_AUDIOS = os.path.join(BASE, "audios")
CARPETA_REG = os.path.join(BASE, "registro")
CSV_REG = os.path.join(BASE, "registro_p3.csv")
EXT_AUDIO = (".wav", ".mp3", ".mpeg", ".mpga", ".ogg", ".flac", ".aac", ".aiff", ".m4a", ".opus", ".webm", ".3gp", ".amr")
MIME = {".wav": "audio/wav", ".mp3": "audio/mp3", ".mpeg": "audio/mp3", ".mpga": "audio/mp3", ".ogg": "audio/ogg", ".flac": "audio/flac",
        ".aac": "audio/aac", ".aiff": "audio/aiff"}
MODELOS_RESPALDO = ["gemini-3.1-flash-lite", "gemini-flash-lite-latest", "gemini-3.5-flash"]
URL = "https://generativelanguage.googleapis.com/v1beta/models/{m}:generateContent"
PROMPT = ("Transcribe literalmente este audio en espanol. Es una orden para un brazo robotico. "
          "Responde SOLO con la transcripcion, sin comillas, sin explicaciones. "
          "Si no se entiende nada, responde exactamente: [inaudible]")

CAMPOS = ["n", "t_fin_habla", "audio", "dicho", "transcripcion", "modo", "motivo_modo_texto", "modelo",
          "accion", "objeto", "color", "prioridad", "permitido", "degradado",
          "aceptada", "causa_rechazo", "success", "mensaje", "planificador", "error_mm",
          "captura_ms", "transcripcion_ms", "decision_ms", "envio_ms", "espera_cola_ms",
          "percepcion_ms", "ik_ms", "planificacion_ms", "total_voz_a_movimiento_ms",
          "t_inicio_movimiento_broker"]


# --------------------------------------------------------------------------- audio
def preparar_audio(ruta):
    """Devuelve (bytes, mime, ruta_usada). Convierte con ffmpeg los formatos que Gemini no acepta."""
    ext = os.path.splitext(ruta)[1].lower()
    with open(ruta, "rb") as fh:                      # el contenido manda, no la extension
        cab = fh.read(12)
    if cab[:3] == b"ID3" or cab[:2] in (b"\xff\xfb", b"\xff\xf3", b"\xff\xf2"):
        ext = ".mp3"
    elif cab[:4] == b"OggS":
        ext = ".ogg"
    elif cab[:4] == b"RIFF":
        ext = ".wav"
    elif cab[:4] == b"fLaC":
        ext = ".flac"
    if ext in MIME:
        with open(ruta, "rb") as fh:
            return fh.read(), MIME[ext], ruta
    if shutil.which("ffmpeg"):
        destino = os.path.join(BASE, "tmp_convertido.wav")
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", ruta, "-ac", "1", "-ar", "16000", destino],
                       check=True, timeout=30)
        with open(destino, "rb") as fh:
            return fh.read(), "audio/wav", destino
    # sin ffmpeg: se intenta tal cual (m4a = contenedor mp4 con aac)
    with open(ruta, "rb") as fh:
        return fh.read(), "audio/aac" if ext == ".m4a" else "audio/" + ext.strip("."), ruta


def grabar_microfono(destino, dispositivo=None):
    """Graba con arecord hasta que presionen ENTER. Devuelve el instante en que terminaron de hablar."""
    if not shutil.which("arecord"):
        raise RuntimeError("no esta instalado arecord (sudo apt install alsa-utils)")
    cmd = ["arecord", "-q", "-f", "S16_LE", "-r", "16000", "-c", "1", destino]
    if dispositivo:
        cmd[1:1] = ["-D", dispositivo]
    p = subprocess.Popen(cmd)
    input("  >>> GRABANDO... hablen y presionen ENTER al terminar ")
    t_fin = time.time()
    p.terminate()
    p.wait(timeout=3)
    return t_fin


# --------------------------------------------------------------------------- nube
def _llamar_gemini(datos, mime, clave, modelo, timeout):
    cuerpo = {"contents": [{"parts": [{"text": PROMPT},
                                      {"inline_data": {"mime_type": mime,
                                                       "data": base64.b64encode(datos).decode()}}]}],
              "generationConfig": {"temperature": 0.0}}
    r = requests.post(URL.format(m=modelo), json=cuerpo, timeout=(min(5.0, timeout), timeout),
                      headers={"x-goog-api-key": clave, "Content-Type": "application/json"})
    if r.status_code in (404, 429, 500, 503):
        raise LookupError(f"modelo {modelo}: HTTP {r.status_code}")
    r.raise_for_status()
    partes = r.json()["candidates"][0]["content"]["parts"]
    return " ".join(p.get("text", "") for p in partes).strip().strip('"').strip()


def transcribir(datos, mime, modelo, timeout_s):
    """Devuelve (texto, modelo_usado, motivo_fallo). texto None si hay que pasar a modo texto.
    Plan de intentos: el modelo principal hasta 3 veces (Google a veces responde 503 'saturado'
    y al segundo intento contesta), luego los de respaldo una vez cada uno."""
    clave = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
    if not clave:
        return None, "", "no hay clave (export GEMINI_API_KEY=...)"
    plan = [modelo] * 3 + [m for m in MODELOS_RESPALDO if m != modelo]
    fin = time.time() + timeout_s
    ultimo, m = "", modelo
    ex = ThreadPoolExecutor(max_workers=1)
    try:
        for i, m in enumerate(plan):
            resto = fin - time.time()
            if resto <= 0.5:
                break
            fut = ex.submit(_llamar_gemini, datos, mime, clave, m, resto)
            try:
                texto = fut.result(timeout=resto + 0.5)
            except LookupError as e:
                ultimo = str(e)
                print(f"  ({e}; intento {i + 1}, reintentando)")
                time.sleep(min(1.5, max(0.0, fin - time.time() - 1)))
                continue
            except (FutTimeout, requests.exceptions.Timeout):
                return None, m, f"sin respuesta en {timeout_s:.1f} s"
            except requests.exceptions.ConnectionError:
                return None, m, "sin internet (no se pudo conectar a Google AI Studio)"
            except requests.exceptions.HTTPError as e:
                return None, m, f"error HTTP {e.response.status_code} de Google AI Studio"
            except Exception as e:
                return None, m, f"respuesta invalida: {type(e).__name__}"
            if not texto or texto == "[inaudible]":
                return None, m, "la nube no entendio el audio"
            return texto, m, ""
        return None, m, f"Google no atendio a tiempo ({ultimo})"
    finally:
        ex.shutdown(wait=False)


# --------------------------------------------------------------------------- ROS
class Transcriptor(Node):
    def __init__(self, cid):
        super().__init__(f"transcriptor_voz_{cid}".replace("-", "_"))
        self.cid = cid
        self.srv = self.create_client(InterpretarOrden, "/interpretar_orden")
        self.act = ActionClient(self, RecogerObjeto, "recoger_objeto")
        self.rechazos = []
        from std_msgs.msg import String
        import json
        self._json = json
        self.create_subscription(String, "/arm/rechazos", self._cb_rechazo, 10)

    def _cb_rechazo(self, msg):
        try:
            d = self._json.loads(msg.data)
        except Exception:
            return
        if d.get("client_id") == self.cid:
            self.rechazos.append(d)

    @staticmethod
    def esperar(fut, timeout):
        fin = time.time() + timeout
        while not fut.done() and time.time() < fin:
            time.sleep(0.005)
        return fut.result() if fut.done() else None

    def ejecutar(self, frase, fila):
        """Decision + broker. Rellena fila con decision, resultado y tiempos."""
        if not self.srv.wait_for_service(timeout_sec=5.0):
            fila["mensaje"] = "/interpretar_orden no disponible"
            print("  !! /interpretar_orden no esta disponible")
            return
        req = InterpretarOrden.Request()
        req.frase = frase
        t0 = time.perf_counter()
        d = self.esperar(self.srv.call_async(req), 10.0)
        fila["decision_ms"] = round((time.perf_counter() - t0) * 1000, 1)
        if d is None:
            fila["mensaje"] = "el interprete no respondio"
            print("  !! el interprete no respondio")
            return
        fila.update({"accion": d.accion, "objeto": d.objeto, "color": d.color, "prioridad": d.prioridad,
                     "permitido": d.permitido, "degradado": d.degradado})
        print(f"  decision ({fila['decision_ms']:.0f} ms{' DEGRADADA' if d.degradado else ''}): "
              f"accion={d.accion} objeto={d.objeto} color={d.color} prioridad={d.prioridad} permitido={d.permitido}")
        if not self.act.wait_for_server(timeout_sec=5.0):
            fila["mensaje"] = "broker no disponible"
            print("  !! el broker (recoger_objeto) no esta disponible")
            return
        g = RecogerObjeto.Goal()
        g.client_id, g.frase = self.cid, frase
        g.accion, g.objeto, g.color = d.accion, d.objeto, d.color
        g.priority = max(0, min(255, int(d.prioridad)))         # prioridad del modelo
        g.permitido, g.degradado, g.decision_ms = d.permitido, d.degradado, float(fila["decision_ms"])
        n_rech = len(self.rechazos)
        t_envio = time.perf_counter()
        h = self.esperar(self.act.send_goal_async(g), 10.0)
        fila["envio_ms"] = round((time.perf_counter() - t_envio) * 1000, 1)
        t_aceptada = time.time()
        if h is None or not h.accepted:
            time.sleep(0.5)
            causa = self.rechazos[-1]["causa"] if len(self.rechazos) > n_rech else "rechazada por el broker"
            fila.update({"aceptada": False, "causa_rechazo": causa, "success": False,
                         "mensaje": "rechazada antes de encolar"})
            print(f"  ✗ RECHAZADA antes de encolar: {causa}  (el brazo no se mueve)")
            return
        fila["aceptada"] = True
        print("  ✓ aceptada y encolada; esperando al brazo...")
        r = self.esperar(h.get_result_async(), 600.0)
        if r is None:
            fila["mensaje"] = "sin resultado"
            return
        r = r.result
        fila.update({"success": r.success, "mensaje": r.message, "planificador": r.planificador,
                     "error_mm": round(r.error_mm, 1),
                     "espera_cola_ms": round(r.wait_time_s * 1000, 1),
                     "percepcion_ms": round(r.percepcion_ms, 1), "ik_ms": round(r.ik_ms, 1),
                     "planificacion_ms": round(r.planificacion_ms, 1),
                     "t_inicio_movimiento_broker": f"{r.t_inicio_movimiento:.3f}"})
        if r.t_inicio_movimiento > 0:
            # inicio del movimiento en el reloj de ESTA maquina (las duraciones no dependen del reloj
            # del broker, asi no importa si los relojes de las maquinas difieren)
            t_mov = t_aceptada + r.wait_time_s + (r.percepcion_ms + r.ik_ms + r.planificacion_ms) / 1000
            fila["total_voz_a_movimiento_ms"] = round((t_mov - fila["t_fin_habla"]) * 1000, 1)
        print(f"  {'✓ HECHO' if r.success else '✗ FALLO'}: {r.message} | error {r.error_mm:.1f} mm "
              f"[{r.planificador}]")


def registrar(fila):
    os.makedirs(BASE, exist_ok=True)
    nuevo = not os.path.exists(CSV_REG)
    with open(CSV_REG, "a", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=CAMPOS, extrasaction="ignore")
        if nuevo:
            w.writeheader()
        w.writerow(fila)


def siguiente_numero():
    if not os.path.exists(CSV_REG):
        return 1
    with open(CSV_REG, encoding="utf-8") as fh:
        return sum(1 for _ in csv.DictReader(fh)) + 1


def procesar(nodo, a, ruta_audio=None, grabar=False):
    n = siguiente_numero()
    fila = {k: "" for k in CAMPOS}
    fila["n"] = n
    sello = time.strftime("%H%M%S")
    # ---- captura (t_fin_habla = instante en que el operador termino de hablar)
    if grabar:
        ruta_audio = os.path.join(CARPETA_REG, f"{n:02d}_{sello}_mic.wav")
        t_fin_habla = grabar_microfono(ruta_audio, a.dispositivo)
    else:
        t_fin_habla = time.time()       # con archivo: cuando se entrega el audio al nodo
    fila["t_fin_habla"] = t_fin_habla
    datos, mime, usado = preparar_audio(ruta_audio)
    fila["captura_ms"] = round((time.time() - t_fin_habla) * 1000, 1)   # cerrar grabacion + leer/convertir
    # copia del audio original al registro
    destino = ruta_audio
    if not grabar:
        destino = os.path.join(CARPETA_REG, f"{n:02d}_{sello}_{os.path.basename(ruta_audio)}")
        shutil.copy2(ruta_audio, destino)
    fila["audio"] = os.path.basename(destino)
    # ---- transcripcion en la nube con tiempo limite propio
    print(f"  transcribiendo en Google AI Studio (limite {a.timeout_s:.1f} s)...")
    t_tr = time.perf_counter()
    texto, modelo, motivo = transcribir(datos, mime, a.modelo, a.timeout_s)
    fila["transcripcion_ms"] = round((time.perf_counter() - t_tr) * 1000, 1)
    fila["modelo"] = modelo
    if texto is not None:
        fila["modo"] = "voz"
        print(f"  transcripcion ({fila['transcripcion_ms']:.0f} ms): \"{texto}\"")
    else:
        fila["modo"] = "texto_teclado"
        fila["motivo_modo_texto"] = motivo
        print("\n  " + "!" * 66)
        print(f"  !! MODO TEXTO: {motivo}.")
        print("  !! Escriban la orden por teclado (el brazo no queda esperando a la nube).")
        print("  " + "!" * 66)
        try:
            texto = input("  orden escrita> ").strip()
        except EOFError:
            texto = ""
        if not texto:
            print("  (orden vacia: no se envia nada)")
            fila["mensaje"] = "orden vacia"
            registrar(fila)
            return
    fila["transcripcion"] = texto
    with open(os.path.splitext(destino)[0] + ".txt", "w", encoding="utf-8") as fh:
        fh.write(f"audio: {os.path.basename(destino)}\nmodo: {fila['modo']}\n"
                 f"motivo_modo_texto: {fila['motivo_modo_texto']}\ntranscripcion: {texto}\n")
    # ---- decision + cola + brazo
    nodo.ejecutar(texto, fila)
    registrar(fila)
    tot = fila["total_voz_a_movimiento_ms"]
    if tot != "":
        print(f"  voz -> movimiento: {tot / 1000:.2f} s  (captura {fila['captura_ms']} ms, nube "
              f"{fila['transcripcion_ms']} ms, decision {fila['decision_ms']} ms, cola {fila['espera_cola_ms']} ms, "
              f"percepcion {fila['percepcion_ms']} ms, IK {fila['ik_ms']} ms, plan {fila['planificacion_ms']} ms)")
    print(f"  registrado en {CSV_REG} (orden #{n})\n")


def listar_audios(carpetas):
    vistos = []
    for c in carpetas:
        c = os.path.expanduser(c)
        if os.path.isdir(c):
            for f in sorted(os.listdir(c), key=lambda x: (os.path.getmtime(os.path.join(c, x)), x)):
                if f.lower().endswith(EXT_AUDIO):
                    vistos.append(os.path.join(c, f))
    return vistos


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--id", default="voz", help="nombre del cliente (aparece en la cola del broker)")
    ap.add_argument("--archivo", default="")
    ap.add_argument("--grabar", action="store_true", help="usar el microfono (arecord)")
    ap.add_argument("--dispositivo", default="", help="dispositivo ALSA para arecord, ej. plughw:1,0")
    ap.add_argument("--timeout-s", type=float, default=8.0, help="tiempo limite de la transcripcion")
    ap.add_argument("--modelo", default=os.environ.get("GEMINI_MODEL", "gemini-3.1-flash-lite"))
    ap.add_argument("--carpetas", nargs="+", default=[CARPETA_AUDIOS, "~/Downloads", "~/Descargas"])
    a = ap.parse_args(rclpy.utilities.remove_ros_args(sys.argv)[1:])
    for c in (BASE, CARPETA_AUDIOS, CARPETA_REG):
        os.makedirs(c, exist_ok=True)
    clave = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
    print(f"Transcriptor '{a.id}' · modelo {a.modelo} · limite {a.timeout_s:.1f} s · clave "
          f"{'cargada desde el entorno' if clave else 'NO CARGADA (ira directo a modo texto)'}")

    rclpy.init()
    nodo = Transcriptor(a.id)
    ex = MultiThreadedExecutor(num_threads=4)
    ex.add_node(nodo)
    hilo = threading.Thread(target=ex.spin, daemon=True)
    hilo.start()
    try:
        if a.archivo:
            procesar(nodo, a, os.path.expanduser(a.archivo))
        elif a.grabar:
            while True:
                input("ENTER para empezar a grabar (Ctrl+C para salir) ")
                procesar(nodo, a, grabar=True)
        else:
            while True:
                audios = listar_audios(a.carpetas)
                print("Audios disponibles (los mas nuevos al final):")
                for i, f in enumerate(audios[-12:], start=max(1, len(audios) - 11)):
                    print(f"  {i:2d}. {f}")
                elec = input("numero o ruta del audio (ENTER = el mas nuevo, t = escribir orden, Ctrl+C sale)> ").strip()
                if elec.lower() == "t":
                    texto = input("  orden escrita> ").strip()
                    if texto:
                        fila = {k: "" for k in CAMPOS}
                        fila.update({"n": siguiente_numero(), "t_fin_habla": time.time(), "modo": "texto_teclado",
                                     "motivo_modo_texto": "elegido por el operador", "transcripcion": texto})
                        nodo.ejecutar(texto, fila)
                        registrar(fila)
                    continue
                if not elec:
                    if not audios:
                        print("  no hay audios; copien uno a", CARPETA_AUDIOS)
                        continue
                    ruta = audios[-1]
                elif elec.isdigit() and 1 <= int(elec) <= len(audios):
                    ruta = audios[int(elec) - 1]
                else:
                    ruta = os.path.expanduser(elec)
                if not os.path.isfile(ruta):
                    print("  no existe:", ruta)
                    continue
                print(f"  audio: {ruta}")
                procesar(nodo, a, ruta)
    except (KeyboardInterrupt, EOFError):
        pass
    finally:
        try:
            rclpy.try_shutdown()
        except Exception:
            pass
        hilo.join(timeout=2.0)
        try:
            ex.shutdown(timeout_sec=1.0)
            nodo.destroy_node()
        except Exception:
            pass


if __name__ == "__main__":
    main()
