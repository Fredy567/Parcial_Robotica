#!/usr/bin/env python3
"""Resumen de la Pregunta 3 a partir de ~/examen_ws/p3/registro_p3.csv.

  ros2 run examen_nodos resumen_p3                  # todas las ordenes
  ros2 run examen_nodos resumen_p3 --desde 3        # solo desde la orden #3 (p.ej. las 5 del docente)

Genera en ~/examen_ws/p3/:
  tabla_ordenes_p3.csv   lo dicho, lo transcrito, la decision y lo que hizo el brazo (Parte B)
  tabla_tiempos_p3.csv   desglose por etapa de cada orden que movio el brazo + mediana (Parte C)
  tiempos_p3.png         figura: mediana de cada etapa, ordenada de mayor a menor
La columna 'dicho' (lo que se dijo de verdad) se llena a mano en registro_p3.csv.
"""
import argparse
import csv
import os
import statistics

BASE = os.path.expanduser("~/examen_ws/p3")
ETAPAS = [("captura_ms", "Captura del audio"), ("transcripcion_ms", "Transcripcion (nube)"),
          ("decision_ms", "Decision (LAYA)"), ("envio_ms", "Envio al broker"),
          ("espera_cola_ms", "Espera en la cola"), ("percepcion_ms", "Percepcion (camara)"),
          ("ik_ms", "Cinematica inversa"), ("planificacion_ms", "Planificacion (MoveIt)")]


def num(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", default=os.path.join(BASE, "registro_p3.csv"))
    ap.add_argument("--desde", type=int, default=1)
    a, _ = ap.parse_known_args()
    filas = [f for f in csv.DictReader(open(a.csv, encoding="utf-8")) if int(f["n"]) >= a.desde]
    if not filas:
        print("no hay ordenes en", a.csv)
        return

    # ---------------- Parte B: tabla de ordenes
    ruta_b = os.path.join(BASE, "tabla_ordenes_p3.csv")
    with open(ruta_b, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["n", "lo_que_se_dijo", "transcripcion", "modo", "decision", "resultado_brazo", "error_mm"])
        for f in filas:
            dec = (f"{f['accion']} {f['objeto']} {f['color']} prio={f['prioridad']} "
                   f"permitido={f['permitido']}" if f["accion"] else "")
            if f["aceptada"] == "False":
                res = f"rechazada antes de encolar: {f['causa_rechazo']} (no se movio)"
            elif f["success"] == "True":
                res = f"objeto depositado en la zona ({f['planificador']})"
            else:
                res = f["mensaje"] or "sin resultado"
            w.writerow([f["n"], f["dicho"], f["transcripcion"], f["modo"], dec, res, f["error_mm"]])
    print(f"Parte B -> {ruta_b}")
    for f in filas:
        print(f"  #{f['n']} [{f['modo']}] \"{f['transcripcion']}\" -> {f['accion']} {f['color']} "
              f"permitido={f['permitido']} | {'RECHAZADA: ' + f['causa_rechazo'] if f['aceptada'] == 'False' else f['mensaje']}")

    # ---------------- Parte C: tiempos
    movidas = [f for f in filas if num(f["total_voz_a_movimiento_ms"])]
    if not movidas:
        print("ninguna orden llego a mover el brazo: no hay desglose de tiempos")
        return
    ruta_c = os.path.join(BASE, "tabla_tiempos_p3.csv")
    medianas = {}
    with open(ruta_c, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["n"] + [e for _, e in ETAPAS] + ["Otros (red, registro)", "TOTAL voz->movimiento"])
        for f in movidas:
            vals = [num(f[k]) or 0.0 for k, _ in ETAPAS]
            tot = num(f["total_voz_a_movimiento_ms"])
            w.writerow([f["n"]] + [f"{v:.0f}" for v in vals] + [f"{max(0.0, tot - sum(vals)):.0f}", f"{tot:.0f}"])
        for k, e in ETAPAS:
            medianas[e] = statistics.median(num(f[k]) or 0.0 for f in movidas)
        tot_med = statistics.median(num(f["total_voz_a_movimiento_ms"]) for f in movidas)
        otros = max(0.0, tot_med - sum(medianas.values()))
        w.writerow(["mediana"] + [f"{medianas[e]:.0f}" for _, e in ETAPAS] + [f"{otros:.0f}", f"{tot_med:.0f}"])
    print(f"\nParte C -> {ruta_c}   ({len(movidas)} ordenes que movieron el brazo)")
    orden = sorted(medianas.items(), key=lambda kv: kv[1], reverse=True)
    for e, v in orden:
        print(f"  {e:26s} {v:8.0f} ms  {100 * v / tot_med:5.1f} %")
    print(f"  {'TOTAL (mediana)':26s} {tot_med:8.0f} ms")
    dom, vdom = orden[0]
    print(f"\n  Etapa dominante: {dom} ({100 * vdom / tot_med:.0f} % del total).")
    print(f"  Para bajar el total a la mitad ({tot_med / 2:.0f} ms) hay que quitar {tot_med / 2:.0f} ms: "
          f"{'basta con atacar ' + dom if vdom >= tot_med / 2 else 'no basta con una sola etapa'}.")

    # figura: una sola magnitud por etapa -> barras horizontales de un solo tono, ordenadas
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    etiquetas = [e for e, _ in orden][::-1] + []
    valores = [v / 1000 for _, v in orden][::-1]
    if otros > 0:
        etiquetas = ["Otros (red, registro)"] + etiquetas
        valores = [otros / 1000] + valores
    fig, ax = plt.subplots(figsize=(8, 4.2), dpi=150)
    fig.patch.set_facecolor("#fcfcfb")
    ax.set_facecolor("#fcfcfb")
    barras = ax.barh(etiquetas, valores, color="#2a78d6", height=0.6, edgecolor="#fcfcfb", linewidth=2)
    for b, v in zip(barras, valores):
        ax.text(b.get_width() + max(valores) * 0.01, b.get_y() + b.get_height() / 2,
                f"{v:.2f} s ({100 * v * 1000 / tot_med:.0f} %)", va="center", fontsize=8, color="#52514e")
    ax.set_xlabel("segundos (mediana)", color="#52514e", fontsize=9)
    ax.set_title(f"De la voz al movimiento: {tot_med / 1000:.1f} s en mediana ({len(movidas)} ordenes)",
                 loc="left", fontsize=11, color="#0b0b0b")
    ax.tick_params(colors="#52514e", labelsize=8)
    for lado in ("top", "right"):
        ax.spines[lado].set_visible(False)
    for lado in ("left", "bottom"):
        ax.spines[lado].set_color("#c3c2b7")
    ax.xaxis.grid(True, color="#e6e5e0", linewidth=0.8)
    ax.set_axisbelow(True)
    ax.set_xlim(0, max(valores) * 1.25)
    fig.tight_layout()
    ruta_f = os.path.join(BASE, "tiempos_p3.png")
    fig.savefig(ruta_f, facecolor=fig.get_facecolor())
    print(f"\nFigura -> {ruta_f}")


if __name__ == "__main__":
    main()
